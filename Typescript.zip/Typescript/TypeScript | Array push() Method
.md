---
title: "TypeScript | Array push() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array push() Method
"
parent: "Typescript"
weight: 43
---

TypeScript \| Array push() Method
---------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.push() is an inbuilt TypeScript function which is used to append the given element(s) in the last of the array and returns the length of the new array. Syntax:

     array.push(element1, ..., elementN)

Parameter: This method accept a single parameter as mentioned above and described below:

element1, ..., elementN : This parameter is the elements to add to the end of the array.

Return Value: This method returns the length of the new array. Below examples illustrate Array push() method in TypeScript:

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of push() method 
        var val = arr.push(8)
           
        // printing element
        console.log( arr );
    </script>

Output: 

    [11,89,23,7,98,8]

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [2, 5, 6, 3, 8, 9]; 
        var val,j=0;
       
        // use of push() method    
        for(j=0; j<4 ; j++){
          var y = arr[j];
          var x = y * j;
          val = arr.push(x);
        }
        // printing element
        console.log( arr );
    </script>

Output: 

    [2,5,6,3,8,9,0,5,12,9]
