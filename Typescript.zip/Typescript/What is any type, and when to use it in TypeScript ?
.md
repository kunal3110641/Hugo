---
title: "What is any type, and when to use it in TypeScript ?
"
draft: false
menu:
sidebar:
name: "What is any type, and when to use it in TypeScript ?
"
parent: "Typescript"
weight: 18
---

What is any type, and when to use it in TypeScript ?
----------------------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



Any is a data type in TypeScript. Any type is used when we deal with third-party programs and expect any variable but we don't know the exact type of variable. Any data type is used because it helps in opt-in and opt-out of type checking during compilation. 

In this article, we will see what is any Type and when to use it in TypeScript.

Syntax:

    let temp: any;

    temp = "string";
    temp = 2;
    temp = true;

Since we typed any data type to temp it expects all types of data-type and doesn't give any error. It provided such flexibility that it also makes the compiler not generate an error at compile time if we call any method to an unknown type which is assigned with any type.

And we had convinced the compiler that it is any type and has some function on it so but we don't know what is it exactly. We have seen any data type now but since TypeScript is a Type checking language so we are giving variable flexibility but it causes some problems such as security issues so let's discourse when to use any data type. 

Any type is used only when we don't have any knowledge of the data type of variable and we want dynamic content from the source. Let's see some situations where we have to use any data type. 

Example 1: Suppose we want to store the third party data in an array but we don't know the exact data type of array so we initialize the array of any in TypeScript which will not make any error and we can handle all types of data types. 

Typescript
----------

    var New_Array : any[]=[1,"data1"];
    New_Array.push("data2");
    New_Array.push(2)
    New_Array.push("data3");
    New_Array.push(3)
    console.log(New_Array)

Run this file with the following command in cmd :

    tsc any_type.ts
    node any_type.js

Output:

    [1, "data1", "data2", 2, "data3", 3]

Example 2: In case you are using a third party function that is written in JavaScript and as a result, it gives you some data but you don't know the type of data in such case if we define some other type but it returns other types our code not run properly in such case we give third party function some flexibility and define with any type. 

JavaScript file :

Javascript
----------

    function Sumyy(a) {
        var sum = 0;
     
        for (var i = 0; i < a.length; i++) {
     
            if (/[0-9]/.test(a[i]))
                sum += parseInt(a[i])
        }
        return sum;
    }

  

Suppose we have this JavaScript function that is not visible to us and we don't know the return type. In such a case, we use any type.

 

TypeScript file:

 

Typescript
----------

    declare var Sumyy: any;
     
    var ans = Sumyy("geeksfor47geeks93820geeky");
    console.log("Sum of numbers : ", ans);

  

HTML file:

 

HTML
----

    <!DOCTYPE html>
    <html lang="en">
     
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>
     
    <body>
     
        <!-- Javascript Library -->
        <script src=
    "C:\Users\computers\Desktop\typescript\first1.js"></script>
        <script src=
    "C:\Users\computers\Desktop\typescript\second.js"></script>
    </body>
     
    </html>

  

Output:

 

![targets](/images/typescriptimg/wp-content/uploads/20220123224347/newwww-200x107.PNG)

OUTPUT IN CONSOLE

 
