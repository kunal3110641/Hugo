---
title: "TypeScript Array concat() Method
"
draft: false
menu:
sidebar:
name: "TypeScript Array concat() Method
"
parent: "Typescript"
weight: 48
---

TypeScript Array concat() Method
--------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.concat() is an inbuilt TypeScript function which is used to merge two or more arrays together. Syntax:

    array.concat(value1, value2, ..., valueN)

Parameter: This method accepts a single parameter multiple time as mentioned above and described below: 

valueN : These parameters are arrays and/or values to concatenate.

Return Value: This method returns the new array. Below examples illustrate the Array concat() method in TypeScriptExample 1: 

JavaScript
----------

    <script>
        // Driver code
        var num1 = [11, 12, 13];
        var num2 = [14, 15, 16];
        var num3 = [17, 18, 19]; 
      
        // use of String concat() Method
        console.log(num1.concat(num2, num3)); 
    </script>

Output: 

    [ 11, 12, 13, 14, 15, 16, 17, 18, 19 ]

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var num1 = ['a', 'b', 'c'];
      
        // use of String concat() Method
        console.log(num1.concat(1, [2, 3])); 
    </script>

Output: 

    [ 'a', 'b', 'c', '1,2,3' ]
