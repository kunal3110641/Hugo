---
title: "TypeScript String Prototype Property
"
draft: false
menu:
sidebar:
name: "TypeScript String Prototype Property
"
parent: "Typescript"
weight: 80
---

TypeScript String Prototype Property
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Prototype Property in TypeScript which is used to add properties and methods to an object. Syntax:

    string.prototype 

Return Value: This method does not returns any value. Below examples illustrate the String Prototype property in TypeScriptExample 1: 

JavaScript
----------

    function Person(name:string, job:string, yearOfBirth:number)
        {    
            this.name= name; 
            this.job= job; 
            this.yearOfBirth= yearOfBirth; 
        } 
          
            
        // Driver code
        var emp = new Person("Smith", "ABC",12214) 
          
        // This will show Person's prototype property.  
        console.log(emp.prototype);

Output: 

![targets](/images/typescriptimg/wp-content/uploads/20200603152631/prot1.jpg)

Example \#2:  

JavaScript
----------

    function Person(name:string, job:string, yearOfBirth:number)
        {    
            this.name= name; 
            this.job= job; 
            this.yearOfBirth= yearOfBirth; 
        } 
          
        // Driver code
        var emp = new Person("Smith", "ABC",12214) 
      
        // This will show Person's prototype property. 
        Person.prototype.email = "abc@123.com"; 
           
        console.log("Person's name: " + emp.name); 
        console.log("Person's Email ID: " + emp.email);

Output: 

![targets](/images/typescriptimg/wp-content/uploads/20200603152633/prot2.jpg)
