---
title: "TypeScript | Array lastIndexOf() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array lastIndexOf() Method
"
parent: "Typescript"
weight: 58
---

TypeScript \| Array lastIndexOf() Method
----------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.lastIndexOf() is an inbuilt TypeScript function which is used to get the last index at which a given element can be found in the array.  Syntax:

    array.lastIndexOf(searchElement[, fromIndex])

Parameter: This method accepts two parameter as mentioned above and described below: 

searchElement : This parameter is the element to locate in the array.

fromIndex : This parameter is the index at which to start searching backwards.

Return Value: This method returns the index of the found element from the last. Below examples illustrate the Array lastIndexOf() method in TypeScript.Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of lastIndexOf() method 
        var val = arr.lastIndexOf(7)
           
        // printing element
        console.log( val );
    </script>

Output: 

    3

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 'a','b','c','a','e' ]; 
      
        // use of lastIndexOf() method 
        var val = arr.lastIndexOf("a")
        var val1 = arr.lastIndexOf("c")
           
        // printing element
        console.log(val);
        console.log(val1);
    </script>

Output: 

    3
    2
