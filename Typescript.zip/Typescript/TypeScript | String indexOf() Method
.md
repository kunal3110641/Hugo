---
title: "TypeScript | String indexOf() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String indexOf() Method
"
parent: "Typescript"
weight: 77
---

TypeScript \| String indexOf() Method
-------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The indexOf() is an inbuilt function in TypeScript which is used to get the index within the calling String object of the first occurrence of the specified value. Syntax:

    string.indexOf(searchValue[, fromIndex]) 

Parameter: This method accepts two parameter as mentioned above and described below . 

searchValue: This parameter is a string representing the value to search for.

fromIndex: This parameter is a location within the calling string to start the search from.

Return Value: This method returns the index of the found occurrence, otherwise -1 if not found.

Below example illustrate the  String indexOf() method in TypeScriptJS:Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str1 = new String('TypeScript | \
    String indexOf() Method with example'); 
      
        // use of String indexOf() Method
        console.log(str1.indexOf("String"));
    </script>

Output: 

    13

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str1 = new String('TypeScript | \
        String indexOf() Method with example'); 
      
        // use of String indexOf() Method
        console.log(str1.indexOf("Geeks"));
    </script>

Output: 

    -1
