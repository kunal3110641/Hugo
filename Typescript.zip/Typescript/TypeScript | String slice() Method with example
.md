---
title: "TypeScript | String slice() Method with example
"
draft: false
menu:
sidebar:
name: "TypeScript | String slice() Method with example
"
parent: "Typescript"
weight: 75
---

TypeScript \| String slice() Method with example
------------------------------------------------



The slice() is an inbuilt function in TypeScript which is used to extracts a section of a string and returns a new string. Syntax: 

    string.slice( beginslice [, endSlice] )

Parameter: This method accept two parameter as mentioned above and described below: 

beginSlice -- This parameter is the zero-based index at which to begin extraction.

endSlice -- This parameter is the zero-based index at which to end extraction.

Return Value: This method returns the index of the regular expression inside the string. Otherwise, it returns -1. 

Below example illustrate the  String slice() method in TypeScriptJS:

Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String slice() Method
        var newstr = str.slice(0,14); 
      
        console.log(newstr);
    </script>

Output: 

    Geeksforgeeks

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String slice() Method
        var newstr = str.slice(16); 
      
        console.log(newstr);
    </script>

Output: 

    Best Platform
