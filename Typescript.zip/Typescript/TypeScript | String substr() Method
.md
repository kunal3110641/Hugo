---
title: "TypeScript | String substr() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String substr() Method
"
parent: "Typescript"
weight: 69
---

TypeScript \| String substr() Method
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The split() is an inbuilt function in TypeScript which is used to returns the characters in a string beginning at the specified location through the specified number of characters.

Syntax: 

    string.substr(start[, length])

Parameter: This method accepts two parameter as mentioned above and described below.: 

start -- This parameter is the location at which to start extracting characters.

length -- This parameter is the number of characters to extract.

Return Value: This method returns the new sub-string. Below examples illustrate the String substr() method in TypeScript.

Example 1: 

Javascript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String substr() Method
        var newstr = str.substr(0,5) 
      
        console.log(newstr);
    </script>

Output: 

    Geeks

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String substr() Method
        var newstr = str.substr(0,5) 
        console.log(newstr);
      
        newstr = str.substr(-2,5) 
        console.log(newstr);
      
        newstr = str.substr(12,22) 
        console.log(newstr);
      
        newstr = str.substr(0,1) 
        console.log(newstr);
    </script>

Output: 

    Geeks
    rm
    s - Best Platform
    G
