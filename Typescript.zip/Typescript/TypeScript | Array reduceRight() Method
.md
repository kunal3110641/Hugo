---
title: "TypeScript | Array reduceRight() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array reduceRight() Method
"
parent: "Typescript"
weight: 54
---

TypeScript \| Array reduceRight() Method
----------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.reduceRight() is an inbuilt TypeScript function which is used to apply a function against two values of the array as to reduce it to a single value in a right to left manner. Syntax:

    array.reduceRight(callback[, initialValue])

Parameter: This method accept two parameter as mentioned above and described below:

callback : This parameter is the Function to execute on each value in the array.

initialValue : This parameter is the Object to use as the first argument to the first call of the callback.

Return Value: This method returns the reduced right single value of the array. Below examples illustrate the Array reduceRight() method in TypeScript

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of reduceRight() method 
        var val = arr.reduceRight(function(a, b)
        { 
            return a - b; 
        });
           
        // printing element
        console.log( val );
    </script>

Output: 

    -32

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [2, 5, 6, 3, 8, 9]; 
        var val;
       
        // use of reduceRight() method 
        val = arr.reduceRight(function(a, b)
        { 
            return a/b; 
        });
           
        // printing element
        console.log( val );
    </script>

Output: 

    0.00625
