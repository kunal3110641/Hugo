---
title: "TypeScript Array some() Method
"
draft: false
menu:
sidebar:
name: "TypeScript Array some() Method
"
parent: "Typescript"
weight: 49
---

TypeScript Array some() Method
------------------------------



The Array.some() is an inbuilt TypeScript function which is used to check for some element in the array passes the test implemented by the provided function.Syntax:

    array.some(callback[, thisObject])

Parameter: This method accept two parameter as mentioned above and described below:

callback : This parameter is the Function to test for each element.

thisObject : This parameter is the Object to use as this when executing callback.

Return Value: This method returns true if some element in this array satisfies the provided testing function. Below example illustrate the  Array  some() method in TypeScriptJS:Example 1: 

TypeScript
----------

    // check for positive number 
    function ispositive(element, index, array)
    { 
       return element > 0;
    } 
     
    // Driver code
    var arr = [ 11, 89, 23, 7, 98 ]; 
      
    // check for positive number 
    var value = arr.some(ispositive); 
    console.log( value );

Output: 

    true

Example 2: 

TypeScript
----------

    // check for even number 
    function iseven(element, index, array) 
    {  
       return (element % 2 == 0);  
    }   
    // Driver code
    var arr = [ 11, 89, 23, 7, 91 ]; 
      
    // check for positive number 
    var value = arr.some(iseven); 
    console.log( value );

Output: 

 

    false

 
