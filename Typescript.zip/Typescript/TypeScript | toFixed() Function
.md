---
title: "TypeScript | toFixed() Function
"
draft: false
menu:
sidebar:
name: "TypeScript | toFixed() Function
"
parent: "Typescript"
weight: 29
---

TypeScript \| toFixed() Function
--------------------------------



The toFixed() function in TypeScript is used to format a number using fixed-point notation. It can be used to format a number with a specific number of digits to the right of the decimal.

Syntax: 

    number.toFixed( [digits] );

Parameters: This function accepts a parameter value- digits-- The number of digits to appear after the decimal point.

Return Value: The toFixed() method in TypeScript returns a string representation of number that does not use exponential notation and has the exact number of digits after the decimal place.

Below examples illustrates the working of toFixed() function in TypeScript :Example 1:

Javascript
----------

    var num = 358.429 
    console.log("num.toFixed() is "+num.toFixed()) 
    console.log("num.toFixed(2) is "+num.toFixed(2))

Output: 

    num.toFixed() is 358 
    num.toFixed(2) is 358.42

Example 2: 

Javascript
----------

    var num1 = 526.123 
    console.log("num1.toFixed() is "+num1.toFixed()) 
    console.log("num1.toFixed(4) is "+num1.toFixed(4)) 
    console.log("num1.toFixed(7) is "+num1.toFixed(7))

Output: 

    num1.toFixed() is 526 
    num1.toFixed(4) is 526.1230
    num1.toFixed(7) is 526.1230000
