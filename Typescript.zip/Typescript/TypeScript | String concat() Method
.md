---
title: "TypeScript | String concat() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String concat() Method
"
parent: "Typescript"
weight: 76
---

TypeScript \| String concat() Method
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The concat() is an inbuilt function in TypeScript which is used to add two or more strings and returns a new single string. 

Syntax:

    string.concat(string2, string3[, ..., stringN]); 

Parameter: This method accept a single parameter as mentioned above and described below.

string2...stringN: This parameter holds the strings which will be concatenate.

Return Value: This method returns the concatenated string.

Below example illustrate the  String concat() method in TypeScriptJS:

Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str1 = new String('Renewbuy'); 
        var str2 = new String(' - Best Platform'); 
      
        // Combines the text of two strings and 
        // returns a new string.
        console.log("Concatenated String : " 
                + str1.concat(str2.toString()));
    </script>

Output: 

    Concatenated String : Renewbuy - Best Platform

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str1 = new String('Geeks'); 
        var str2 = new String('for'); 
        var str3 = new String('Geeks'); 
      
        // Combines the text of two strings and 
        // returns a new string.
        var str = str2.concat(str3.toString())
        str = str1.concat(str.toString())
        console.log("Concatenated String : " + str);
    </script>

Output: 

    Concatenated String : Renewbuy
