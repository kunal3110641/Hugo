---
title: "TypeScript | String toLocaleLowerCase() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String toLocaleLowerCase() Method
"
parent: "Typescript"
weight: 73
---

TypeScript \| String toLocaleLowerCase() Method
-----------------------------------------------



The toLocaleLowerCase() is an inbuilt function in TypeScript which is used to convert the characters within a string to lowercase while respecting the current locale.

Syntax: 

    string.toLocaleLowerCase( ) 

Parameter: This methods does not accepts any parameter. Return Value: This method returns the string in lowercase with the current locale. Below examples illustrate the String toLocaleLowerCase() method  in TypeScriptExample 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String toLocaleLowerCase() Method
        var newstr = str.toLocaleLowerCase() 
        console.log(newstr);
    </script>

Output: 

    Renewbuy - best platform

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "TypeScript - String toLocaleLowerCase()"; 
      
        // use of String toLocaleLowerCase() Method
        var newstr = str.toLocaleLowerCase() 
        console.log(newstr);
    </script>

Output: 

    typescript - string tolocalelowercase()
