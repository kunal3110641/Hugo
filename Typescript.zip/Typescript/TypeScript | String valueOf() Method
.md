---
title: "TypeScript | String valueOf() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String valueOf() Method
"
parent: "Typescript"
weight: 71
---

TypeScript \| String valueOf() Method
-------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The valueOf() is an inbuilt function in TypeScript that is used to return the primitive value of a String object.

Syntax: 

    string.valueOf( ) 

Parameter: This method does not accept any parameter. Return Value: This method returns the primitive value of a String object. Below examples illustrate the String valueOf() method in TypeScript

Example 1: 

JavaScript
----------

    //language is TypeScript
     
        // Original strings
        var str = "Geeksforgeeks - Best Platform";
     
        // use of String valueOf() Method
        var newstr = str.valueOf()
        console.log(newstr);

Output:  

    Geeksforgeeks - Best Platform

Example 2:  

JavaScript
----------

    // Language is TypeScript
     
        // Original strings
        var str = new String("TypeScript - String valueOf()");
     
        // use of String valueOf() Method
        var newstr = str.valueOf()
        console.log(newstr);

Output: 

    TypeScript - String valueOf()
