---
title: "TypeScript | Array sort() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array sort() Method
"
parent: "Typescript"
weight: 57
---

TypeScript \| Array sort() Method
---------------------------------



The Array.sort() is an inbuilt TypeScript function which is used to sort the elements of an array. Syntax:

    array.sort( compareFunction )

Parameter: This method accept a single parameter as mentioned above and described below: 

compareFunction : This parameter is the function that defines the sort order

Return Value: This method returns the sorted array. 

Below example illustrate the  Array sort() method in TypeScriptJS:Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of sort() method 
        var val = arr.sort();
           
        // printing
        console.log( val );
    </script>

Output: 

    [ 11, 23, 7, 89, 98 ]

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = ["G", "e", "e", "k", "s", "f", "o", "r", 
                   "g", "e", "e", "k", "s"]; 
        var val;
       
        // use of sort() method 
        val = arr.sort();
        console.log( val );
    </script>

Output: 

    [ 'G', 'e', 'e', 'e', 'e', 'f', 'g', 'k', 'k', 'o', 'r', 's', 's' ]
