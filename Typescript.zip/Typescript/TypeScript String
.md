---
title: "TypeScript String
"
draft: false
menu:
sidebar:
name: "TypeScript String
"
parent: "Typescript"
weight: 63
---

TypeScript String
-----------------

![targets](/images/typescriptimg/auth/avatar.png)



In TypeScript, the string is sequence of char values and also considered as an object. It is a type of primitive data type that is used to store text data. The string values are used between single quotation marks or double quotation marks, and also array of characters works same as a string. TypeScript string work with the series of character.

Syntax

    var var_name = new String(string); 

Property:

Constructor: It will return a reference to the string function.

Length: This property will return the length of the string.

Prototype: This property let you add the property and methods.

Methods:

charAt(): This method will return character at the specified index.

charCodeAt(): This method will return returns a number indicating the Unicode value of the character at the specified index.

concat(): This method will combine the two separate string and return that combined string.

indexOf(): It will return the index. Fast occurrence of specified value else -1 if not found.

lastIndexOf(): It will return index, last occurrence of specified value else -1 if not found.

localeCompare(): This method will return a number which indicate that the reference string comes before or after or the same as the given string in sort order.

match(): This method is used to match regular expression with the specified string.

replace(): This method is use to replace the match string by regular expression.

search(): This method is used to search for matching the regular expression with the specified string.

slice(): Extract the specified string and return a new string.

split(): Splits the specified String object into an array of strings.

substr(): Return the character from start to define index.

substring(): Returns character of string between two define indexes.

toLocaleLowerCase(): This method convert the string into lowercase while respecting the current locale.

toLocaleUpperCase(): This method convert the string into Uppercase while respecting the current locale.

toLowerCase(): This method convert the string into lowercase.

toString(): This method returns a string representing the specified object.

toUpperCase(): This method convert the string into uppercase.

valueOf(): This method returns the primitive value of specified string.

Example:

    let uname = new String("Hello Renewbuy");  
    console.log("Message: " + uname);  
    console.log("Length: " + uname.length);

Output:

    Message: Hello Renewbuy
    Length: 19

Template String: Template string support in TypeScript from ES6 version. Template strings are used to fixed the expressions into strings.

Example:

    let emplName:string =  "Mohit Jain";   
    let compName:string = "Renewbuy";   
    // Pre-ES6  
    let emplDetail1: string = emplName + " works in the " + compName + " company.";   
    // Post-ES6  
    let emplDetail2: string = `${emplName} works in the ${compName} company.`;   
    console.log("Before ES6: " +emplDetail1);  
    console.log("After ES6: " +emplDetail2);

Output:

    Before ES6: Mohit Jain works in the Renewbuy company.
    After ES6:  Mohit Jain works in the Renewbuy company.

Multi-Line String: ES6 provides us to write the multi-line string. This can be shown in the below example.We have to add "\\n" at the end of each string for containing a new line in the string. This represents the clear cut statement.Example:

    let multi = ' hello\n ' +  
        'Geeksforgeeks\n ' +  
        'my\n ' +  
        'name\n ' +  
        'is\n ' +  
        'Mohit Jain';  
    console.log(multi);  

Output:

    hello
    Geeksforgeeks
    my
    name
    is
    Mohit Jain

String Literal Type: It is also a type of string and strings literal is a sequence of characters enclosed in double quotation marks (" ") and terminated with a null value. In a string literal type is a type whose expected value is a string with textual contents equal to that of the string literal type. In other words, we can say a string literal allow us to specify the exact string value specified in the string literal type. While a string literal type uses different allowed string value then use "pipe" or " \| " symbol between them.

Syntax:

    Type variableName = "value1" | "value2" | "value3"; // upto N number of values  

String literal can be used in two ways:

Variable Assignment: Whatever the values will be allowed for literal type variable then We can assign. Otherwise, it will give the compile-time error.Example:type Pet = \'mouse\' \| \'dog\' \| \'Rabbit\';  let pet: Pet;  if(pet = \'mouse\'){      console.log(\"Correct\");  };  if(pet = \'Deer\')  {      console.log(\" we got compilation error type!\");  }; Output:
Correct
we got compilation error type!

    type Pet = 'mouse' | 'dog' | 'Rabbit';  
    let pet: Pet;  
    if(pet = 'mouse'){  
        console.log("Correct");  
    };  
    if(pet = 'Deer')  
    {  
        console.log(" we got compilation error type!");  
    }; 

Output:

    Correct
    we got compilation error type!

Function Parameter: For literal type argument we can pass only defined values. Otherwise, it will give the compile-time error.Example:type FruitsName = \"Apple\" \| \"Mango\" \| \"Orange\";  function showFruitName(fruitsName: FruitsName): void {      console.log(fruitsName);  }  showFruitName(\'Mango\');   //OK - Print \'Mango\'  //Compile Time Error  showFruitName(\'Banana\');Output:
Mango
Banana

    type FruitsName = "Apple" | "Mango" | "Orange";  
    function showFruitName(fruitsName: FruitsName): void {  
        console.log(fruitsName);  
    }  
    showFruitName('Mango');   //OK - Print 'Mango'  
    //Compile Time Error  
    showFruitName('Banana');

Output:

    Mango
    Banana
