---
title: "TypeScript | Array shift() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array shift() Method
"
parent: "Typescript"
weight: 50
---

TypeScript \| Array shift() Method
----------------------------------



The Array.shift() is an inbuilt TypeScript function which is used to remove the first element from an array and returns that element. Syntax:

    array.shift(); 

Parameter: This methods does not accept any  parameter. Return Value: This method returns the removed single value of the array. Below example illustrate the  Array shift() method in TypeScriptJS:

Example 1: 

JavaScript
----------

    <script>
       // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of shift() method 
        var val = arr.shift();
           
        // printing
        console.log( val );
        console.log( arr );
    </script>

Output: 

    11
    [ 89, 23, 7, 98 ]

Example 2: 

JavaScript
----------

    <script>
       // Driver code
        var arr = [2, 5, 6, 3, 8, 9]; 
        var val;
       
        // use of reverse() method 
        val = arr.shift();
        console.log( val );
        val = arr.shift();
        console.log( val );
           
        // printing
        console.log( arr );
    </script>

Output: 

    2
    5
    [ 6, 3, 8, 9 ]
