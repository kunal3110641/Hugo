---
title: "TypeScript | Array unshift() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array unshift() Method
"
parent: "Typescript"
weight: 60
---

TypeScript \| Array unshift() Method
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.unshift() is an inbuilt TypeScript function that is used to add one or more elements to the beginning of an array and returns the new length of the array. 

Syntax:

    array.unshift( element1, ..., elementN )

Parameter: This method accepts n number of similar elements.

element1, ..., elementN : This parameter is the elements to add to the front of the array.

Return Value: This method returns the length of the new array. Below example illustrate the  String unshift() method in TypeScriptJS:

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ];
     
        // use of unshift() method
        var string= arr.unshift(11);
          
        // printing
        console.log( string);
    </script>

 Output:  

    6

Example 2:  

JavaScript
----------

    <script>
        // Driver code
        var arr = ["G", "e", "e", "k", "s", "f", "o",
                   "r", "g", "e", "e", "k", "s"];
        var val;
      
        // use of unshift() method
        val = arr.unshift("f");
        console.log( val );
        console.log( arr );
    </script>

 Output:  

    14
    ["f","G","e","e","k","s","f","o","r","g","e","e","k","s"]

 
