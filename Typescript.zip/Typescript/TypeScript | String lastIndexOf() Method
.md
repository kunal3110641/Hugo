---
title: "TypeScript | String lastIndexOf() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String lastIndexOf() Method
"
parent: "Typescript"
weight: 74
---

TypeScript \| String lastIndexOf() Method
-----------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The lastIndexOf() is an inbuilt function in TypeScript which is used to get the index within the calling String object of the last occurrence of the specified value. Syntax:

    string.lastIndexOf(searchValue[, fromIndex]) 

Parameter: This method accepts two parameter as mentioned above and described below:

searchValue: This parameter is a string representing the value to search for.

fromIndex: This parameter is a location within the calling string to start the search from.

Return Value: This method returns the index of the last found occurrence, otherwise -1 if not found.

Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str1 = new String('TypeScript | \
        String lastIndexOf() Method with example'); 
      
        // use of String lastIndexOf() Method
        console.log(str1.lastIndexOf("String"));
    </script>

Output: 

    17

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str1 = new String('TypeScript | \
        String lastIndexOf() Method with example'); 
      
        // use of String lastIndexOf() Method
        console.log(str1.lastIndexOf("Geeks"));
    </script>

Output: 

    -1
