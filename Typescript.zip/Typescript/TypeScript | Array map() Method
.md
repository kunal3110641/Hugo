---
title: "TypeScript | Array map() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array map() Method
"
parent: "Typescript"
weight: 51
---

TypeScript \| Array map() Method
--------------------------------



The Array.map() is an inbuilt TypeScript function that is used to create a new array with the results of calling a provided function on every element in this array.

Syntax: 

    array.map(callback[, thisObject])

Parameter: This method accepts two parameters as mentioned above and described below: 

callback : This parameter is the function that produces an element of the new Array from an element of the current one.

thisObject : This parameter is the Object to use as this when executing callback.

Return Value: This method returns the created array. 

Below examples illustrate the Array map() method in TypeScript.Example 1: 

JavaScript
----------

    // language is TypeScript
     
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ];
     
        // use of map() method
        var val = arr.map(Math.log)
          
        // printing element
        console.log( val );

Output: 

    [ 2.3978952727983707,
      4.48863636973214,
      3.1354942159291497,
      1.9459101490553132,
      4.584967478670572 ]

Example 2: 

JavaScript
----------

    // language is TypeScript
     
        // Driver code
        var arr = [2, 5, 6, 3, 8, 9];
     
        // use of map() method   
     
        var newArr = arr.map(function(val, index){
     
          // printing element
          console.log("key : ",index, "value : ",val*val);
        })

Output: 

    key :  0 value :  4
    key :  1 value :  25
    key :  2 value :  36
    key :  3 value :  9
    key :  4 value :  64
    key :  5 value :  81
