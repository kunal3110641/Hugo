---
title: "TypeScript | String toLocaleUpperCase() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String toLocaleUpperCase() Method
"
parent: "Typescript"
weight: 67
---

TypeScript \| String toLocaleUpperCase() Method
-----------------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The toLocaleLowerCase() is an inbuilt function in TypeScript which is used to convert the characters within a string to uppercase while respecting the current locale.

Syntax: 

    string.toLocaleUpperCase( ) 

Parameter: This methods does not accept any parameter. Return Value: This method returns the string in uppercase with the current locale. Below examples illustrate the String toLocaleUpperCase() method in TypeScriptExample 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String toLocaleUpperCase() Method
        var newstr = str.toLocaleUpperCase() 
        console.log(newstr);erCase() 
        console.log(newstr);
    </script>

Output: 

    GEEKSFORGEEKS - BEST PLATFORM

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "TypeScript - String toLocaleUpperCase()"; 
      
        // use of String toLocaleUpperCase() Method
        var newstr = str.toLocaleUpperCase() 
        console.log(newstr);
    </script>

Output: 

    TYPESCRIPT - STRING TOLOCALEUPPERCASE()
