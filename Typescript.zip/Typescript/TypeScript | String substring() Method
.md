---
title: "TypeScript | String substring() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String substring() Method
"
parent: "Typescript"
weight: 68
---

TypeScript \| String substring() Method
---------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The substring() is an inbuilt function in TypeScript which is used to return the subset of a String object.

 Syntax: 

    string.substring(indexA, [indexB]) 

Parameter: This method accepts two parameter as mentioned above and described below: 

indexA : This parameter is the integer between 0 and one less than the length of the string.

indexB : This parameter is the integer between 0 and length of the string.

Return Value: This method returns the subset of a String object. Below example illustrate the String substring() method in TypeScript.

Example 1:  

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform";
      
        // use of String substring() Method
        var newstr = str.substring(0,5)
      
        console.log(newstr);
    </script>

Output: 

    Geeks

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform";
      
        // use of String substring() Method
        var newstr = str.substring(0,5)
        console.log(newstr);
      
        newstr = str.substring(-2,5)
        console.log(newstr);
      
        newstr = str.substring(12,22)
        console.log(newstr);
      
        newstr = str.substring(0,1)
        console.log(newstr);
    </script>

Output: 

    Geeks
    Geeks
    s - Best P
    G
