---
title: "TypeScript | Array filter() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array filter() Method
"
parent: "Typescript"
weight: 53
---

TypeScript \| Array filter() Method
-----------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.filter() is an inbuilt TypeScript function which is used to creates a new array with all elements that pass the test implemented by the provided function. Syntax:

    array.filter(callback[, thisObject])

Parameter: This methods accepts two parameter as mentioned and described below:

callback : This parameter is the Function to test for each element.

thisObject : This parameter is the Object to use as this when executing callback.

Return Value: This method returns created array. Below examples illustrate the Array filter() method in TypeScriptExample 1: 

JavaScript
----------

    <script>
        // check for positive number 
        function ispositive(element, index, array)
        { 
           return element > 0;
        } 
            
        // Driver code
        var arr = [ 11, 89, -23, 7, 98 ]; 
          
        // check for positive number 
        var value = arr.filter(ispositive); 
        console.log( value );
    </script>

Output: 

    [11,89,7,98]

Example 2: 

JavaScript
----------

    <script>
        // check for odd number 
        function isodd(element, index, array) 
        {  
           return (element % 2 == 1);  
        }   
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
           
        // check for odd number 
        var value = arr.filter(isodd); 
        console.log( value );
    </script>

Output: 

    [11,89,23,7]
