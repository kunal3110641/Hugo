---
title: "How to install TypeScript ?
"
draft: false
menu:
sidebar:
name: "How to install TypeScript ?
"
parent: "Typescript"
weight: 4
---

How to install TypeScript ?
---------------------------

![targets](/images/typescriptimg/auth/avatar.png)



Typescript validates your JavaScript ahead of time with static type checking. The code is interpreted by a browser, but if your code is broken you won't catch it until runtime when the browser rows an error. The language is a strict superset of JavaScript, which means when you open up a ts file you can write plain JavaScript with all of its extra features being completely optional.

We can run the typescript compiler using the tsc command, it will take the typescript file and transpile it into vanilla JavaScript. A typescript project always has a ts config file, which helps us to customize the behavior of the compiler. The primary goal of typescript is to enable static typing, which is achieved by allowing the user to annotate code with types.

Prerequisite:

Download and install the NodeJS framework onto your computer system.

Following is the step-by-step guide to install TypeScript on:

Step 1: Go to the start menu and click on the command prompt.

Step 2: To install typescript we have to use NPM, NPM is called a node package manager. As its name suggests, it is used to install NodeJS packages onto our system.

Run the following command in the same NodeJS command prompt to install the typescript:

    npm install --global typescript

![targets](/images/typescriptimg/wp-content/uploads/20220120092230/Screenshot20220120092231.png)

The above command will install the typescript onto our local system. To verify the installation, run the following command:

    tsc -v

Here tsc is a typescript compiler and the -v flag indicates that we are displaying the version of the typescript as shown in the image below:

![targets](/images/typescriptimg/wp-content/uploads/20220120092252/Screenshot20220120092248.png)

At this point, typescript is successfully installed onto your system.

Step 3: To install a specific version of a typescript, use the following command with '@' followed by version.

    npm install --global typescript@4.x.x

Here, 'x' can be changed with the version that we want to install, as shown in the image below:

![targets](/images/typescriptimg/wp-content/uploads/20220120092333/Screenshot20220120092359.png)

Step 4: To uninstall typescript, use the same command that is used to install the typescript and replace the installation with uninstall. Here is the command:

    npm uninstall --global typescript

![targets](/images/typescriptimg/wp-content/uploads/20220120092405/Screenshot20220120092433.png)

Now, let's create a simple hello world project through typescript:

Step 1: Create a folder onto your desktop and create a file named "main.ts". You can write whatever name you want for this file and folder.

Step 2: Open up the NodeJS command prompt and navigate to the folder path that we created in step 1.

    cd path/to/the/folder

![targets](/images/typescriptimg/wp-content/uploads/20220120092440/Screenshot20220120092509.png)

Step 3: Run the Initialization command in that command prompt to create the necessary configuration file for our simple project.

    tsc --init

![targets](/images/typescriptimg/wp-content/uploads/20220120092509/Screenshot20220120092536.png)

This tsc --init command will create a configuration file for the typescript compiler called tsconfig.json. This file contains all the configurations for the typescript compiler that we will be going to use while executing the program.

Step 4: Open up the main.ts that we created in the step1. Below is the hello world code in the typescript. It will display the string in the console that will confirm the working of the typescript compiler.

Typescript main.ts Code:

main.ts
-------

    /**  Hello world program using Typescript  */
      
    let helloTypescript: string;
        
    helloTypescript = 
      "Typescript is successfully installed"+
      " onto this system. -Renewbuy";
        
    console.log(helloTypescript);

The above code should be pasted and saved in the main.ts file before executing the typescript compiler.

Step 5: Run the typescript compiler with the file name as an argument to see results.

    tsc

This will create a compiled JS file from that typescript file. And now to run the JS file we will be using the NodeJS as below.

    node main.js

Output:

![targets](/images/typescriptimg/wp-content/uploads/20220114215614/apple.png)

Typescript hello world 
