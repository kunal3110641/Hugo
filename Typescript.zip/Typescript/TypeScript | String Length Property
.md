---
title: "TypeScript | String Length Property
"
draft: false
menu:
sidebar:
name: "TypeScript | String Length Property
"
parent: "Typescript"
weight: 78
---

TypeScript \| String Length Property
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Length Property() in TypeScript which is used to get the length of the string Syntax:

    string.length 

Return Value: This method returns the length to the String function that created the object. Below examples illustrate the String Length Property in TypeScript

Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
           
        // use of length Property
        var newstr = str.length
        console.log("Return Value of Length property:", newstr);
    </script>

Output: 

    Return Value of Length property: 
    29

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = new String("TypeScript - String length Property"); 
       
        // use of length Property
        var newstr = str.length 
        console.log("Length:", newstr);
    </script>

Output: 

    Length: 
    35
