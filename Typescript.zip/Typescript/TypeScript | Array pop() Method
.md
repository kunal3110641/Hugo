---
title: "TypeScript | Array pop() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array pop() Method
"
parent: "Typescript"
weight: 59
---

TypeScript \| Array pop() Method
--------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.pop() is an inbuilt TypeScript function which is used to removes the last element from an array and returns that element. Syntax:

    array.pop(); 

Parameter: This methods does not accept any parameter. Return Value: This method returns the removed element from the array. Below examples illustrate Array pop() method in TypeScript.

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of pop() method 
        var val = arr.pop()
           
        // printing element
        console.log( val );
    </script>

Output: 

    98

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [2, 5, 6, 3, 8, 9]; 
        var val,j=0;
       
        // use of pop() method    
        for(j=0; j<4 ; j++){
          val = arr.pop()
           
          // printing element
          console.log(val);
        }
    </script>

Output: 

    9
    8
    3
    6
