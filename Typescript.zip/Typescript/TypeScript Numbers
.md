---
title: "TypeScript Numbers
"
draft: false
menu:
sidebar:
name: "TypeScript Numbers
"
parent: "Typescript"
weight: 11
---

TypeScript Numbers
------------------



TypeScript is like JavaScript which supports numerical values as Number objects. The numbers in typescript are used as both integers as well as floating-point values. The number class acts as wrapper and manipulates the numeric literals as they were objects.

Syntax:

    var var_name = new Number(value)

Property:

MAX\_VALUE: It has the largest possible value 1.7976931348623157E+308 in JavaScript.

MIN\_VALUE: It has the smallest possible value 5E-324 in JavaScript.

NaN: This property has Equal to a value that is not a number.

NEGATIVE\_INFINITY: This has a value that is less than MIN\_VALUE.

POSITIVE\_INFINITY: This has a value that is greater than MAX\_VALUE.

prototype: This property is used to assign new properties and methods to the Number object.

constructor: This property will return the function that created this object's instance

Example:

    console.log(" Number Properties in TypeScript: "); 
    console.log("Maximum value of a number variable has : " 
                                       + Number.MAX_VALUE); 
    console.log("The least value of a number variable has: " 
                                        + Number.MIN_VALUE); 
    console.log("Value of Negative Infinity: " 
                                 + Number.NEGATIVE_INFINITY); 
    console.log("Value of Negative Infinity:" 
                                 + Number.POSITIVE_INFINITY);

Output:

    Number Properties in TypeScript:  
    Maximum value of a number variable has: 1.7976931348623157e+308 
    The least value of a number variable has: 5e-324 
    Value of Negative Infinity: -Infinity 
    Value of Negative Infinity:Infinity

Example of NaN:

    var day = 0 
    if( day<=0 || v >7) { 
       day = Number.NaN 
       console.log("Day is "+ day) 
    } else { 
       console.log("Value Accepted..") 
    }

Output:

    Month is NaN

Methods:

toExponential(): This method will return a number to display in exponential notation.

toFixed(): This method will stable the number to the right of the decimal with a specific number of digits.

toLocaleString(): This method is used to convert the number into a local specific representation of the number.

toPrecision(): It will define total digits to the left and right of the decimal to display of a number. It will also show an error when there is negative precision.

toString(): Used to return the string representation of the number in the specified base.

valueOf(): This method will return number's primitive value.

Example 1:

    // The toExponential() 
    var num1 = 2525.30 
    var val = num1.toExponential(); 
    console.log(val)

Output:

    2.5253e+3

Example 2:

    // The toFixed()
    var num3 = 237.134 
    console.log("num3.toFixed() is "+num3.toFixed()) 
    console.log("num3.toFixed(2) is "+num3.toFixed(3)) 
    console.log("num3.toFixed(6) is "+num3.toFixed(5))

Output:

    num3.toFixed() is 237 
    num3.toFixed(2) is 237.134 
    num3.toFixed(6) is 237.13400

Example 3:

    // The toLocaleString()
    var num = new Number( 237.1346); 
    console.log( num.toLocaleString());

Output:

    237.1346

Example 4:

    // The toPrecision()
    var num = new Number(5.7645326); 
    console.log(num.toPrecision()); 
    console.log(num.toPrecision(1)); 
    console.log(num.toPrecision(2));

Output:

    5.7645326 
    5 
    5.7

Example 5:

    // The toString()
    var num = new Number(10); 
    console.log(num.toString()); 
    console.log(num.toString(2)); 
    console.log(num.toString(8));

Output:

    10 
    1010 
    12

Example 6:

    // The valueOf()
    var num = new Number(20); 
    console.log(num.valueOf());

Output:

    20
