---
title: "How to execute TypeScript file using command line?
"
draft: false
menu:
sidebar:
name: "How to execute TypeScript file using command line?
"
parent: "Typescript"
weight: 6
---

How to execute TypeScript file using command line?
--------------------------------------------------



![targets](/images/typescriptimg/wp-content/uploads/20200203122925/Untitled-Diagram-1211.png)

TypeScript is an open-source programming language. It is developed and maintained by Microsoft. TypeScript follows JavaScript syntactically but adds more features to it. It is a superset of JavaScript. In order to execute or run any typescript file, first you need to install node and using it install typescript globally in your local system.

To check node is installed, run command if not you have to installed it first:node -v

    node -v

Now to install typescript, use:npm install -g typescript

    npm install -g typescript

After installing typescript, create a .ts file, for example, greet.ts as given below:

Example:var greet: string = \"Greetings\"; var geeks: string = \"Renewbuy\"; console.log(greet + \" from \" + geeks); // save the file as hello.ts 

    var greet: string = "Greetings"; 
    var geeks: string = "Renewbuy"; 
    console.log(greet + " from " + geeks); 
    // save the file as hello.ts 

Output:Greetings from Renewbuy

    Greetings from Renewbuy

Procedure 1: This typescript file greet.ts will create a javascript file at runtime with the same name. To run any typescript file there are a few ways:Syntax:

Step 1: First, run the typescript file with the following command. This will create a javascript file from typescript automatically with the same name.tsc helloWorld.ts

    tsc helloWorld.ts

Step 2:Now run the javascript file, the greet.ts file will get executed:node helloWorld.js

    node helloWorld.js

Procedure 2: You can merge both the commands by using a pole \| and && like below :Syntax:

In Windows:tsc greet.ts \| node greet.js

    tsc greet.ts | node greet.js

In Linux or MacOS:tsc helloWorld.ts && node helloWorld.js

    tsc helloWorld.ts && node helloWorld.js

Procedure 3: You can also install ts-node along with typescript using the following command:

Syntax:

To install:npm install -g ts-node

    npm install -g ts-node

To run:ts-node helloWorld.ts

    ts-node helloWorld.ts

Output: Using any of the three ways, the output will remain the same.

    Greetings from Renewbuy
