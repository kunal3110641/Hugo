---
title: "TypeScript
"
draft: false
menu:
sidebar:
name: "TypeScript
"
parent: "Typescript"
weight: 1
---

TypeScript
==========

TypeScript is a strict superset of JavaScript, which means anything that is implemented in JavaScript can be implemented using TypeScript along with the choice of adding enhanced features. It is an Open Source Object Oriented programming language and strongly typed language. As TS code is converted to JS code it makes it easier to integrate into JavaScript projects.

 

![targets](/images/typescriptimg/wp-content/cdn-uploads/20211217100853/TypeScript-Tutorial.png)

For a large-scale project adopting It might result in more robust software, while still being deployable where a regular JavaScript application would run. It won't make your software bug-free. But it can prevent a lot of type-related errors. Along with the Clever IntelliSense. A simple code example will help you to understand the need for this strongly typed programming language.Note: Reasons to pick TypeScript over JavaScript.

 

Reason to learn TypeScript?JavaScript was initially developed to be a lightweight easy-to-learn language mainly focusing on simple DOM manipulations but the standards changed with time and that is where TypeScript came into the picture as it adds enhanced features to JavaScript.The use of TypeScript in popular JavaScript Frameworks and Libraries.It adopts the basic building blocks of your program from JavaScript. All TS code is converted into its JS equivalent for the purpose of execution.The support for Classes and Objects is also one of the main reasons for its increasing popularity as it makes it easier to understand and implement OOPS concepts as compared to the standard prototype-based implementation provided by native JavaScript.TypeScript Installation: Browsers natively do not understand typescript, but they understand javascript. So in order to run the codes, first it is transpiled to javascript.You can install it by running the following command.npm install -g typescriptLet's understand the working of the code using an example.Example: In this example, we are creating a basic example that will print "Greetings from Renewbuy".typescript

Reason to learn TypeScript?
---------------------------

JavaScript was initially developed to be a lightweight easy-to-learn language mainly focusing on simple DOM manipulations but the standards changed with time and that is where TypeScript came into the picture as it adds enhanced features to JavaScript.

The use of TypeScript in popular JavaScript Frameworks and Libraries.

It adopts the basic building blocks of your program from JavaScript. All TS code is converted into its JS equivalent for the purpose of execution.

The support for Classes and Objects is also one of the main reasons for its increasing popularity as it makes it easier to understand and implement OOPS concepts as compared to the standard prototype-based implementation provided by native JavaScript.

TypeScript Installation: Browsers natively do not understand typescript, but they understand javascript. So in order to run the codes, first it is transpiled to javascript.

You can install it by running the following command.

Let's understand the working of the code using an example.

Example: In this example, we are creating a basic example that will print "Greetings from Renewbuy".

typescript
----------
