---
title: "TypeScript | Array indexOf() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array indexOf() Method
"
parent: "Typescript"
weight: 52
---

TypeScript \| Array indexOf() Method
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.indexOf() is an inbuilt TypeScript function which is used to find the index of the first occurrence of the search element provided as the argument to the function.  Syntax:

    array.indexOf(searchElement[, fromIndex])

Parameter: This method accepts two parameter as mentioned above and described below: 

searchElement : This parameter is the Element to locate in the array.

fromIndex : This parameter is the index at which to begin the search.

Return Value: This method returns the index of the found element. Below examples illustrate the Array indexOf() method in TypeScript.

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of indexOf() method 
        var val = arr.indexOf(7)
           
        // printing element
        console.log(val);
    </script>

Output: 

    3

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 'a','b','c','a','e' ]; 
      
        // use of indexOf() method 
        var val = arr.indexOf('a',4)
           
        // printing element
        console.log(val);
    </script>

Output: 

    -1
