---
title: "Data types in TypeScript
"
draft: false
menu:
sidebar:
name: "Data types in TypeScript
"
parent: "Typescript"
weight: 10
---

Data types in TypeScript
------------------------



Whenever a variable is created, the intention is to assign some value to that variable but what type of value can be assigned to that variable is dependent upon the datatype of that Variable. In typeScript, type System represents different types of datatypes which are supported by TypeScript. The data type classification is as given below:

Built-in Datatypes: TypeScript has some pre-defined data-types-

Examples:

let a: null = null;

let b: number = 123;

let c: number = 123.456;

let d: string = 'Geeks';

let e: undefined = undefined;

let f: boolean = true;

let g: number = 0b111001; // Binary

let h: number = 0o436; // Octal

let i: number = 0xadf0d; // Hexa-Decimal

User-defined Data Types: Apart from built-in data types, user can also define its own data type. User-defined types include Enumerations (enums), classes, interfaces, arrays, and tuple.

NOTE: In built-in data types, any is a special data-type, also the super data-type of all data types. If a variable is declared with any data type then we can assign any type value to that variable.

Examples:

let a: any = null;

let b: any =123;

let c: any = 123.456;

let d: any = 'Geeks';

let e: any = undefined;

let f: any = true;
