---
title: "TypeScript | toPrecision() Function
"
draft: false
menu:
sidebar:
name: "TypeScript | toPrecision() Function
"
parent: "Typescript"
weight: 28
---

TypeScript \| toPrecision() Function
------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The toPrecision() method in TypeScript is used to return the string representation in exponential or fixed-point to the specified precision.

Syntax:

    number.toPrecision( [ precision ] )

Parameter: It represents an integer value specifying the number of significant digits.

Return Value: The toPrecision() method in TypeScript returns a string representing a Number in fixed-point or exponential notation round to precision significant digits.

Below examples illustrate the working of toPrecision() function in TypeScript:

Example 1:

    <script>
      
    // toPrecision() method
    var num = new Number(6.218956); 
    console.log(num.toPrecision()); 
    console.log(num.toPrecision(4)); 
    console.log(num.toPrecision(3));
    </script>

Output:

    6.218956 
    6.2189 
    6.21

Example 2:

    <script>
      
    // toPrecision() method
    let myNumber: number = 32.5779; 
    console.log("Number Method: toPrecision()");  
    console.log(myNumber.toPrecision(1));   
    console.log(myNumber.toPrecision(3));  
    </script>

Output:

    Number Method: toPrecision()
    3e+1
    32.6
