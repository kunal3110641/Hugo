---
title: "TypeScript Array reverse() Method
"
draft: false
menu:
sidebar:
name: "TypeScript Array reverse() Method
"
parent: "Typescript"
weight: 46
---

TypeScript Array reverse() Method
---------------------------------



The Array.reverse() is an inbuilt TypeScript function which is used to reverses the element of an array.  Syntax:

    array.reverse(); 

Parameter: This methods does not accept any parameter. Return Value: This method returns the reversed single value of the array. Below examples illustrate the Array reverse() Method in TypeScript.

Example 1: 

TypeScript
----------

    // Driver code
    var arr = [ 11, 89, 23, 7, 98 ]; 
     
    // use of reverse() method 
    var val = arr.reverse();
       
    // printing
    console.log( val );

Output: 

    [ 98, 7, 23, 89, 11 ]

Example 2: 

TypeScript
----------

    // Driver code
    var arr = [2, 5, 6, 3, 8, 9]; 
    var val;
       
    // use of reverse() method 
    val = arr.reverse();
    val = val.reverse();
       
    // printing
    console.log( val );

Output: 

    [ 2, 5, 6, 3, 8, 9 ]

 
