---
title: "TypeScript | String search() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String search() Method
"
parent: "Typescript"
weight: 79
---

TypeScript \| String search() Method
------------------------------------



The search() is an inbuilt function in TypeScript that is used to search for a match between a regular expression and this String object. Syntax:

    string.search(regexp);

Parameter: This methods accept a single parameter as mentioned above and described below: 

regexp: This parameter is a RegExp object.

Return Value: This method returns the index of the regular expression inside the string. Otherwise, it returns -1. Below example illustrate the  String search() method in TypeScriptJS:

Example 1:

Javascript
----------

    // This is TypeScript
    // Original strings
    var str = "Geeksforgeeks - Best Platform";
     
    var re = /Best/gi;
     
    // use of String search() Method
    if (str.search(re) == -1 ) {
      console.log("Not Found" );
    } else {
      console.log("Found" );
    }

Output: 

    Found

Example 2:

JavaScript
----------

    // This is TypeScript
    // Original strings
    var str = "Geeksforgeeks - Best Platform";
     
    var re = /geeek/gi;
     
    // use of String search() Method
    if (str.search(re) == -1 ) {
        console.log("Not Found" );
    } else {
        console.log("Found" );
    }

Output:

    Not Found 
