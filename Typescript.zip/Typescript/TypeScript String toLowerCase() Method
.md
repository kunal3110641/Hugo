---
title: "TypeScript String toLowerCase() Method
"
draft: false
menu:
sidebar:
name: "TypeScript String toLowerCase() Method
"
parent: "Typescript"
weight: 65
---

TypeScript String toLowerCase() Method
--------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The toLowerCase() is an inbuilt function in TypeScript which is used to convert the characters within a string to lowercase.

Syntax:

    string.toLowerCase( ) 

Parameter: This methods does not accepts any parameter. Return Value: This method returns the string in lowercase. Below examples illustrate the String toLowerCase() Method in TypeScript.

Example : 

TypeScript
----------

    // Original strings
    var str = "Geeksforgeeks - Best Platform"; 
     
    // use of String toLowerCase() Method
    var newstr = str.toLowerCase() 
    console.log(newstr);

Output: 

    Renewbuy - best platform

Example 2: 

TypeScript
----------

    // Original strings
    var str = "TypeScript - String toLowerCase()"; 
     
    // use of String toLowerCase() Method
    var newstr = str.toLowerCase() 
    console.log(newstr);

Output: 

    typescript - string tolowercase()

 

 

 
