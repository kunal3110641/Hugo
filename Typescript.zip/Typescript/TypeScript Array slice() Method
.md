---
title: "TypeScript Array slice() Method
"
draft: false
menu:
sidebar:
name: "TypeScript Array slice() Method
"
parent: "Typescript"
weight: 44
---

TypeScript Array slice() Method
-------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.slice() is an inbuilt TypeScript function which is used to extract a section of an array and returns a new array.Syntax:

     array.slice( begin [,end] ); 

Parameter: This method accepts two parameter as mentioned above and described below:

begin : This parameter is the Zero-based index at which to begin extraction.

end : This parameter is the Zero-based index at which to end extraction.

Return Value: This method returns the extracted array . Below example illustrate the  Array slice() method in TypeScriptJS:Example 1: 

TypeScript
----------

    // Driver code
    var arr = [ 11, 89, 23, 7, 98 ]; 
     
    // use of slice() method 
    var val = arr.slice(2, 4);
          
    // printing
    console.log( val );

Output: 

    [ 23, 7 ]

Example 2: 

TypeScript
----------

    // Driver code
     var arr = ["G", "e", "e", "k", "s", "f", "o", "r", 
                "g", "e", "e", "k", "s"]; 
     var val;
     
     // use of slice() method 
     val = arr.slice(2, 6);
     console.log( val );
     val = arr.slice(5, 8);
     console.log( val );

Output: 

    [ 'e', 'k', 's', 'f' ]
    [ 'f', 'o', 'r' ]
