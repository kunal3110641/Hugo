---
title: "TypeScript | Array forEach() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array forEach() Method
"
parent: "Typescript"
weight: 61
---

TypeScript \| Array forEach() Method
------------------------------------



The Array.forEach() is an inbuilt TypeScript function which is used to calls a function for each element in the array. Syntax: 

    array.forEach(callback[, thisObject])

Parameter: This method accepts two parameter as mentioned above and described below: 

callback : This parameter is the Function to test for each element.

thisObject : This parameter is the Object to use as this when executing callback.

Return Value: This method returns created array. Below example illustrate the Array forEach() Method in TypeScript.

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ];
          
        // printing each element
        arr.forEach(function (value) {
            console.log(value);
        });
    </script>

Output: 

    11
    89
    23
    7
    98

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 1, 2, 3, 4, 5 ];
          
        // printing square of  element
        arr.forEach(function (value) {
            console.log(value * value);
        });
    </script>

Output: 

    1
    4
    9
    16
    25
