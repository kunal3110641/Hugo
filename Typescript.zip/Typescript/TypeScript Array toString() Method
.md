---
title: "TypeScript Array toString() Method
"
draft: false
menu:
sidebar:
name: "TypeScript Array toString() Method
"
parent: "Typescript"
weight: 62
---

TypeScript Array toString() Method
----------------------------------



The Array.toString() is an inbuilt TypeScript function that is used to get a string representing the source code of the specified array and its elements. 

Syntax:

    array.toString()

Parameter: This method does not accept any parameter. 

Return Value: This method returns the string representing the array. 

Below example illustrate the  String toString() method in TypeScriptJS:

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ];
     
        // use of toString() method
        var string= arr.toString();
              
        // printing
        console.log(string);
    </script>

Output:  

    11,89,23,7,98

Example 2:  

JavaScript
----------

    <script>
        // Driver code
        var arr = ["G", "e", "e", "k", "s", "f", "o",
                   "r", "g", "e", "e", "k", "s"];
        var val;
      
        // use of toString() method
        val = arr.toString();
        console.log( val );
    </script>

Output:  

    G,e,e,k,s,f,o,r,g,e,e,k,s

 
