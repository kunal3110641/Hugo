---
title: "What are type aliases and how to create it in Typescript ?
"
draft: false
menu:
sidebar:
name: "What are type aliases and how to create it in Typescript ?
"
parent: "Typescript"
weight: 33
---

What are type aliases and how to create it in Typescript ?
----------------------------------------------------------



In Typescript, Type aliases give a type a new name. They are similar to interfaces in that they can be used to name primitives and any other kinds that you'd have to define by hand otherwise. Aliasing doesn't truly create a new type; instead, it gives that type a new name. Aliasing a primitive isn't very practical as it's easy using primitive types, however, it can be used for documentation purposes. Type aliasing is just giving another name for a type. let's demonstrate a few examples on type Aliasing.

Example 1: Creating a type alias

In this example we create a type alias named type\_alias. The new type is a union of number, string, and boolean. if a new variable is declared with that type, the new variable can be given values that are only of types number, string, or boolean.

Javascript
----------

    // A new type is created
    type type_alias = number | string | boolean;
     
    // Variable is declared of the new type created
    let variable: type_alias;
    variable = 1;
    console.log(variable);
    variable = "Renewbuy";
    console.log(variable);
    variable = true;
    console.log(variable);

Output:
-------

    1
    Renewbuy
    true

Here we try to give a variable of type function, typescript compiler raises an error.

Javascript
----------

    // A new type is created
    type type_alias = number | string | boolean;
     
    // Variable is declared of the new type created
    let variable: type_alias;
    variable = function () {};

Output:
-------

    error TS2322: Type '() => void' is not assignable to type 'type_alias'.
      Type '() => void' is not assignable to type 'true'.

        variable = function () {};

Example 2: Implementing type alias in a function.

In this example, we will try implementing type alias in a function. We create a type alias called anotherType which is a union of number and string type. The function DisplayId can take arguments that are of type number or string. If any other type is given error is raised. 

Javascript
----------

    // A new type is created
    type anotherType = number | string;
    let variable: string;
    function displayId(id: anotherType) {
      if (typeof id === typeof variable) {
        return "my id is : " + id;
      }
      return "my id is : " + `${id.toString()}`;
    }
     
    // Argument of type string is passed into the function
    console.log(displayId("AF565"));
     
    // Argument of type number is passed into the function
    console.log(displayId(565));

Output:
-------

    my id is : AF565
    my id is : 565

Example 3: String literals as type alias.

Instead of specifying types in union, we can use strings instead. A new type is created which is type alias of "yes"\|"no". only "yes" or "no " strings can be given as values for the variables declared with otherType. when some other value is given as input typescript compiler raises error.

Javascript
----------

    // A new type is created
    type otherType = "yes" | "no";
    let variable: otherType;
    variable = "yes"; // no error
    console.log(variable);
    variable = "neither"; // error
    console.log(variable);

Output:
-------

typescript compiler raises error:

    error TS2322: Type '"neither"' is not assignable to type 'anotherType'.

        variable = "neither"; // error
        ~~~~~~~~

After executing JavaScript file:

    yes
    neither
