---
title: "TypeScript | String charCodeAt() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String charCodeAt() Method
"
parent: "Typescript"
weight: 81
---

TypeScript \| String charCodeAt() Method
----------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The charCodeAt() is an inbuilt function in TypeScript which is used to return the number indicating the Unicode value of the character at the specified index. Syntax:

    string.charCodeAt(index);

Parameter: This method accept a single parameter as mentioned above and described below.

index This parameter is an integer between 0 and 1 less than the length of the string.

Return Value: This method returns number indicating the Unicode value of the character at the given index.

Below example illustrate the  String charCodeAt() method in TypeScriptJS:

Example 1: 

JavaScript
----------

    var str = new String("JavaScript is object oriented language");
      
    // Finding number indicating the Unicode value
    // of the character at the given index
    var value = str.charCodeAt(14);
    console.log(value);

Output: 

    111

Example 2: 

JavaScript
----------

    var str = new String('JavaScript is object oriented language'); 
      
    // Finding number indicating the Unicode value
    // of the character at the given index
    console.log("Character at 0 is : " + str.charCodeAt(0)); 
    console.log("Character at 1 is : " + str.charCodeAt(1));

Output: 

    Character at 0 is : 74
    Character at 1 is : 97
