---
title: "TypeScript | toString() Function
"
draft: false
menu:
sidebar:
name: "TypeScript | toString() Function
"
parent: "Typescript"
weight: 31
---

TypeScript \| toString() Function
---------------------------------



The toString() method in TypeScript is used to returns a string representing the specified object radix (base).

Syntax:

    number.toString( [radix] )

Parameter: This function accept asingle parameter as mentioned above and described below:

radix: This parameter represents an integer between 2 and 36 specifying the base to use for representing numeric values.

Return Value: Returns a string representing the specified Number object.

Below examples illustrates the toString() function in TypeScript

Example 1:

javascript
----------

    // The toString()function
    let Num1: number = 123;
    Num1.toString(); 
    Num1.toString(16); 
    Num1.toString(8); 
    Num1.toString(4);

Output:

    123 
    7b
    173
    1323

Example 2:

javascript
----------

    // The toString() function
    let Num2: number = 12345;   
    console.log("Number Method: toString()");  
    console.log(Num2.toString());  
    console.log(Num2.toString(4));

Output:

    Number Method: toString()
    12345
    3000321
