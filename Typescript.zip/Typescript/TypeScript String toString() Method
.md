---
title: "TypeScript String toString() Method
"
draft: false
menu:
sidebar:
name: "TypeScript String toString() Method
"
parent: "Typescript"
weight: 66
---

TypeScript String toString() Method
-----------------------------------



The toString() is an inbuilt function in TypeScript which is used to return a string representing the specified object.

Syntax: 

    string.toString( ) 

Parameter: This methods does not accept any parameter. Return Value: This method returns the string representing the specified object. Below examples illustrate the String toString() method in TypeScript

Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
      
        // use of String toString() Method
        var newstr = str.toString() 
        console.log(newstr);
    </script>

Output: 

    Geeksforgeeks - Best Platform

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "TypeScript - String toString()"; 
      
        // use of String toString() Method
        var newstr = str.toString() 
        console.log(newstr);
    </script>

Output: 

    TypeScript - String toString()
