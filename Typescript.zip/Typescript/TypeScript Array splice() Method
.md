---
title: "TypeScript Array splice() Method
"
draft: false
menu:
sidebar:
name: "TypeScript Array splice() Method
"
parent: "Typescript"
weight: 45
---

TypeScript Array splice() Method
--------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The Array.splice() is an inbuilt TypeScript function which is used to change the content of an array, adding new elements while removing old elements.Syntax: 

    array.splice(index, howMany, [element1][, ..., elementN]); 

Parameter: This method accept three parameter as mentioned above and described below: 

index : This parameter is the index at which to start changing the array.

howMany : This parameter is the integer indicating the number of old array elements to remove.

element1, ..., elementN : This parameter is the elements to add to the array.

Return Value: This method returns the extracted array. Below example illustrate the  Array splice() method in TypeScriptJS:Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of splice() method 
        var removed = arr.splice(2, 0, 11);
           
        // printing
        console.log(removed);
    </script>

Output: 

    []

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = ["G", "e", "e", "k", "s", "f", "o", 
                   "r", "g", "e", "e", "k", "s"]; 
        var val;
       
        // use of splice() method 
        val = arr.splice(0,5);
        console.log( val );
        console.log( arr );
    </script>

Output: 

    [ 'G', 'e', 'e', 'k', 's' ]
    [ 'f', 'o', 'r', 'g', 'e', 'e', 'k', 's' ]

 
