---
title: "Identifiers and Keywords in TypeScript
"
draft: false
menu:
sidebar:
name: "Identifiers and Keywords in TypeScript
"
parent: "Typescript"
weight: 9
---

Identifiers and Keywords in TypeScript
--------------------------------------



Identifiers: Identifiers are nothing but the names which is given to the members of any class like a variable, method name, class name, array name etc. Certain rules to be followed while declaring Identifiers:

Identifier name can start with both upper-case as well as lower case letter but can't start with numbers.

Only \_ and \$ symbols can be used for giving name to Identifiers, apart from these symbols, no other special symbol can be used.

Keywords are different from Identifiers.

Identifier are case sensitive and doesn't contain spaces.

Examples of Valid and Invalid Identifiers:

Keywords: Keywords are words which are responsible to perform some specific task or the words which represent some specific functionality. The following table lists some keywords:

Comments: Comments are a way to improve the readability of a program. While coding we use comments for a better understanding of code for other users. While execution of the code, compiler ignore the comments and compile the rest of the code. There are two ways to use comments :

Single-line comments ( // )

Multi-line comments (/\* \*/)

Examples:

Hello World in TypeScript
