---
title: "TypeScript | toLocaleString() Function
"
draft: false
menu:
sidebar:
name: "TypeScript | toLocaleString() Function
"
parent: "Typescript"
weight: 30
---

TypeScript \| toLocaleString() Function
---------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The toLocaleString() method in TypeScript is to convert the number into a local specific representation of the number using the locale of the environment.

Syntax:

    number.toLocaleString()

Return Value: The toLocaleString() method in TypeScript returns a human readable string representing the number using the locale of the environment.

Below examples illustrate the working of toLocaleString() function in TypeScript:

Example 1:

    <script>
      
    // toLocaleString() method
    var num = new Number(432.3456);
    console.log(num.toLocaleString());
    </script>

Output:

    432.3456

Example 2:

    <script>
      
    // toLocaleString() method
    let Number_1 : number = 23415.456;
    console.log("Number Method: toLocaleString()");
      
    // returns in US English
    console.log(Number_1.toLocaleString()); 
    </script>

Output:

    Number Method: toLocaleString()
    23, 415.456
