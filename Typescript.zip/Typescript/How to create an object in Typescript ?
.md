---
title: "How to create an object in Typescript ?
"
draft: false
menu:
sidebar:
name: "How to create an object in Typescript ?
"
parent: "Typescript"
weight: 35
---

How to create an object in Typescript ?
---------------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



Typescript is an Object-Oriented Programming Language Created by Microsoft Corporation which is mainly designed for larger-scale projects, Typescript is Javascript code with Strictly Typed Language. We can say anything that is implemented with Javascript runs in TypeScript Syntax with some extra added features like Static Type Checking, Modularity, Class-Based Objects, Modularity, ES6 Features, Also a Syntax that is similar to High-Level Languages like Java. 

Creating Objects in typescript: Now, let us see multiple ways in which objects can be created using typescript. 

Creating standalone objects in typescript: As Fundamentally, Javascript runs with Template-based code snippets, we can create objects directly without creating classes, with taking help of Object Literals and constructor method. 

what are Object Literals? 

Object Literals are typically defined as a set of name-value pairs stored in comma-separated lists. 

Syntax:

    var Name_of_object = { 
        object_property : value, 
        object_property : value 
    }  

Example:

Javascript
----------

    var Employee_details = {
        Empname: "John",
        EmpSection: "field"
     
    }
    console.log("Employee Name is:" +
        Employee_details.Empname +
        " Employee's section is:"
        + Employee_details.EmpSection
    );

Output: 

![targets](/images/typescriptimg/wp-content/uploads/20220205115148/JSoutput1-300x64.png)

What is a Constructor Method: A Constructor method is intended mainly for initializing an Object which is created with a class, and please note that only one special method can enjoy the "constructor" status in a defined class, and a SyntaxError will be thrown if more than one constructor method will be added in a class. 

Syntax:

    function Name_Of_Constructor( property1, property2, ...) {} 

Inside this Constructor method, we can initiate parameter values to properties of objects using the "this" keyword. 

    function Name_Of_Constructor( property1, property2, ...) { 
        this.property1 = parameter_value; 
        this.property2 = parameter_value; 
    }

or 

We can declare both properties of object and parameter with the same name. 

    function Name_Of_Constructor( property1, property2, ...) {
        this.property1 = property1;
        this.property2 = property2;
    }

"this" Keyword references object property with the required parameters, to simply say "this" keyword represents the object to which we are initiating parameters with help of the constructor method. 

Example:

Javascript
----------

    function Employee(Employee_fn, Employee_ln, Employee_age) {
       this.fn = Employee_fn;
       this.ln = Employee_ln;
       this.age = Employee_age;
    }
     
    var p1 = new Employee("Raviteja", "Velamuri", 24);
    console.log("Name: " + p1.fn + " " + p1.ln);
    console.log("Age: " + p1.age);

Output: 

![targets](/images/typescriptimg/wp-content/uploads/20220205134709/JSoutput-300x168.png)

Passing Objects as Parameters to Functions: Now, let us explore how we can pass an object as a parameter value to a Function. Generally, In Typescript objects can be passed as arguments to functions but we should add the properties that an object must contain in that function. 

Syntax:

    var Name_Of_Object {
        property = property.value ; 
    } 
    function function_name( 
        obj : { property_name : property_type } 
    ) : return_type { 
        obj_param.property 
    }

Example: 

Javascript
----------

    var employee = {
        firstname: " Raviteja ",
        lastname: " Velamuri ", 
    }
    function display( obj: {
        firstname:String,lastname:String
    }) : void { 
        console.log("Name is"+obj.firstname+" "+
            "lastname is"+" "+obj.lastname);
    } 
     
    display(employee);

Output: 

![targets](/images/typescriptimg/wp-content/uploads/20220206054422/JSoutput1-300x129.png)
