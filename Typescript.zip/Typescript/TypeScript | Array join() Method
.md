---
title: "TypeScript | Array join() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | Array join() Method
"
parent: "Typescript"
weight: 55
---

TypeScript \| Array join() Method
---------------------------------



The Array.join() is an inbuilt TypeScript function which is used to joins all the elements of an array into a string. Syntax:

    array.join(separator)

Parameter: This method accept a single parameter as mentioned above and described below:

separator : This parameter is the a string to separate each element of the array.

Return Value: This method returns the string after joining all the array elements. Below examples illustrate the Array join() method in TypeScript.

Example 1: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 11, 89, 23, 7, 98 ]; 
      
        // use of join() method 
        var str = arr.join(", ")
           
        // printing element
        console.log("String : " + str);
    </script>

Output: 

    String : 11, 89, 23, 7, 98

Example 2: 

JavaScript
----------

    <script>
        // Driver code
        var arr = [ 'a','b','c','a','e' ]; 
      
        // use of join() method 
        var val = arr.join(" ")
        var val1 = arr.join(" + ")
           
        // printing element
        console.log(val);
        console.log(val1);
    </script>

Output: 

    a b c a e
    a + b + c + a + e
