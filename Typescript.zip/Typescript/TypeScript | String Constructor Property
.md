---
title: "TypeScript | String Constructor Property
"
draft: false
menu:
sidebar:
name: "TypeScript | String Constructor Property
"
parent: "Typescript"
weight: 64
---

TypeScript \| String Constructor Property
-----------------------------------------



The Constructor Property() in TypeScript which is used to returns a reference to the String function that created the object. Syntax:

    string.constructor 

Return Value: This method returns the reference to the String function that created the object. Below example illustrate the  String Constructor Property in TypeScript

 Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform"; 
       
        // use of Constructor Property
        var newstr = str.constructor 
        console.log("Return Value of constructor property:", newstr);
    </script>

Output: 

    Return Value of constructor property: function String() { [native code] }

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = new String("TypeScript - String Constructor Property"); 
       
        // use of Constructor Property
        var newstr = str.constructor 
        console.log(newstr);
    </script>

Output: 

    function String() { [native code] }
