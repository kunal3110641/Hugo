---
title: "TypeScript | String split() Method
"
draft: false
menu:
sidebar:
name: "TypeScript | String split() Method
"
parent: "Typescript"
weight: 70
---

TypeScript \| String split() Method
-----------------------------------

![targets](/images/typescriptimg/auth/avatar.png)



The split() is an inbuilt function in TypeScript which is used to splits a String object into an array of strings by separating the string into sub-strings.

Syntax:

    string.split([separator][, limit])

Parameter: This method accepts two parameter as mentioned above and described below: 

separator -- This parameter is  the character to use for separating the string.

limit -- This parameter is the Integer specifying a limit on the number of splits to be found.

Return Value: This method returns the new array. Below examples illustrate the String split() method in TypeScript.Example 1: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform";
     
        // use of String split() Method
        var newarr = str.split(" ");
     
        console.log(newarr);
    </script>

Output: 

    [ 'Geeksforgeeks', '-', 'Best', 'Platform' ]

Example 2: 

JavaScript
----------

    <script>
        // Original strings
        var str = "Geeksforgeeks - Best Platform";
     
        // use of String split() Method
        var newarr = str.split("",14);
     
        console.log(newarr);
    </script>

Output: 

    [ 'G', 'e', 'e', 'k', 's', 'f', 'o', 'r', 'g', 'e', 'e', 'k', 's', ' ' ]
