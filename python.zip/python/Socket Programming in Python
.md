---
title: "Socket Programming in Python
"
draft: false
menu:
sidebar:
name: "Socket Programming in Python
"
parent: "Python"
weight: 93
---

Socket Programming in Python
----------------------------



Socket programming is a way of connecting two nodes on a network to
communicate with each other. One socket(node) listens on a particular
port at an IP, while the other socket reaches out to the other to form a
connection. The server forms the listener socket while the client
reaches out to the server. 

They are the real backbones behind web browsing. In simpler terms, there
is a server and a client. Socket programming is started by importing the
socket library and making a simple socket. 

    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

Here we made a socket instance and passed it two parameters. The first
parameter is AF\_INET and the second one is SOCK\_STREAM. AF\_INET
refers to the address-family ipv4. The SOCK\_STREAM means
connection-oriented TCP protocol. Now we can connect to a server using
this socket.

Connecting to a server: 

Note that if any error occurs during the creation of a socket then a
socket. error is thrown and we can only connect to a server by knowing
its IP. You can find the IP of the server by using this : 

    $ ping www.google.com

You can also find the IP using python: 

    import socket 

    ip = socket.gethostbyname('www.google.com')
    print ip

Here is an example of a script for connecting to Google.

Python3
-------

\# An example script to connect to Google using socket\# programming in
Pythonimport socket \# for socketimport sys try:    s =
socket.socket(socket.AF\_INET, socket.SOCK\_STREAM)    print (\"Socket
successfully created\")except socket.error as err:    print (\"socket
creation failed with error %s\" %(err)) \# default port for socketport =
80 try:    host\_ip = socket.gethostbyname(\'www.google.com\')except
socket.gaierror:     \# this means could not resolve the host    print
(\"there was an error resolving the host\")    sys.exit() \# connecting
to the servers.connect((host\_ip, port)) print (\"the socket has
successfully connected to google\")

Output : 

    Socket successfully created
    there was an error resolving the host

Here when we will be successfully connected the output will be:

    Socket successfully created
    the socket has successfully connected to google

First of all, we made a socket.

Then we resolved google's IP and lastly, we connected to google.

Now we need to know how can we send some data through a socket.

For sending data the socket library has a sendall function. This
function allows you to send data to a server to which the socket is
connected and the server can also send data to the client using this
function.

A simple server-client program: 
--------------------------------

Server: 

A server has a bind() method which binds it to a specific IP and port so
that it can listen to incoming requests on that IP and port. A server
has a listen() method which puts the server into listening mode. This
allows the server to listen to incoming connections. And last a server
has an accept() and close() method. The accept method initiates a
connection with the client and the close method closes the connection
with the client. 

Python3
-------

\# first of all import the socket libraryimport socket             \#
next create a socket objects = socket.socket()        print (\"Socket
successfully created\") \# reserve a port on your computer in our\# case
it is 12345 but it can be anythingport = 12345                \# Next
bind to the port\# we have not typed any ip in the ip field\# instead we
have inputted an empty string\# this makes the server listen to
requests\# coming from other computers on the networks.bind((\'\',
port))        print (\"socket binded to %s\" %(port)) \# put the socket
into listening modes.listen(5)    print (\"socket is
listening\")            \# a forever loop until we interrupt it or\# an
error occurswhile True: \# Establish connection with client.  c, addr =
s.accept()      print (\'Got connection from\', addr )   \# send a thank
you message to the client. encoding to send byte type.  c.send(\'Thank
you for connecting\'.encode())   \# Close the connection with the
client  c.close()     \# Breaking once connection closed  break

First of all, we import socket which is necessary.

Then we made a socket object and reserved a port on our pc.

After that, we bound our server to the specified port. Passing an empty
string means that the server can listen to incoming connections from
other computers as well. If we would have passed 127.0.0.1 then it would
have listened to only those calls made within the local computer.

After that we put the server into listening mode.5 here means that 5
connections are kept waiting if the server is busy and if a 6th socket
tries to connect then the connection is refused.

At last, we make a while loop and start to accept all incoming
connections and close those connections after a thank you message to all
connected sockets.

Client : Now we need something with which a server can interact. We
could telnet to the server like this just to know that our server is
working. Type these commands in the terminal: 

    # start the server
    $ python server.py

    # keep the above terminal open 
    # now open another terminal and type: 
     
    $ telnet localhost 12345

If 'telnet' is not recognized. On windows search windows features and
turn on the "telnet client" feature.

Output : 

    # in the server.py terminal you will see
    # this output:
    Socket successfully created
    socket binded to 12345
    socket is listening
    Got connection from ('127.0.0.1', 52617)

    # In the telnet terminal you will get this:
    Trying ::1...
    Trying 127.0.0.1...
    Connected to localhost.
    Escape character is '^]'.
    Thank you for connectingConnection closed by foreign host.

This output shows that our server is working.Now for the client-side: 

Python3
-------

\# Import socket moduleimport socket             \# Create a socket
objects = socket.socket()         \# Define the port on which you want
to connectport = 12345                \# connect to the server on local
computers.connect((\'127.0.0.1\', port)) \# receive data from the server
and decoding to get the string.print (s.recv(1024).decode())\# close the
connections.close()         

First of all, we make a socket object.

Then we connect to localhost on port 12345 (the port on which our server
runs) and lastly, we receive data from the server and close the
connection.

Now save this file as client.py and run it from the terminal after
starting the server script.

    # start the server:
    $ python server.py
    Socket successfully created
    socket binded to 12345
    socket is listening
    Got connection from ('127.0.0.1', 52617)

    # start the client:
    $ python client.py
    Thank you for connecting

