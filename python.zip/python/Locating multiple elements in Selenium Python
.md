---
title: "Locating multiple elements in Selenium Python
"
draft: false
menu:
sidebar:
name: "Locating multiple elements in Selenium Python
"
parent: "Python"
weight: 139
---

Locating multiple elements in Selenium Python
---------------------------------------------



Locators Strategies in Selenium Python are methods that are used to
locate single or multiple elements from the page and perform operations
on the same. Selenium's Python Module is built to perform automated
testing with Python. Selenium Python bindings provide a simple API to
write functional/acceptance tests using Selenium WebDriver. After one
has installed selenium and checked out -- Navigating links using get
method, one might want to play more with Selenium Python. After opening
page using selenium such as geeksforgeeks, one might want to click some
buttons automatically or fill a form automatically or any such automated
task. This article revolves around Locating multiple elements in
Selenium Python.

Locator Strategies to locate multiple elements
----------------------------------------------

Selenium Python follows different locating strategies for elements. One
can locate multiple elements in 7 different ways. Here is a list of
locating strategies for Selenium in python -- 

LocatorsDescriptionfind\_elements(By.NAME, "name")All elements with name
attribute value matching the location will be
returned.find\_elements(By.XPATH, "xpath")All elements with xpath syntax
matching the location will be returned.find\_elements(By.LINK\_TEXT,
"link text")All elements with link text value matching the location will
be returned.find\_elements(By.PARTIAL\_LINK\_TEXT, "partial link
text")All elements with partial link text value matching the location
will be returned.find\_elements(By.TAG\_NAME, "tag name")All elements
with given tag name will be returned.find\_elements(By.CLASS\_NAME,
"class name")All elements with matching class attribute name will be
returned.find\_elements(By.CSS\_SELECTOR, "css selector")All elements
with matching CSS selector will be returned.

find\_elements(By.NAME)
-----------------------

With this strategy, all elements with the name attribute value matching
the location will be returned. If no element has a matching name
attribute, a NoSuchElementException will be raised. 

Syntax:

    driver.find_elements(By.NAME, "name_of_element")

Example: For instance, consider this page source: 

html
----

 

  

           

 

Now after you have created a driver, you can grab elements using --

    elements = driver.find_elements(By.NAME,'username')

To check practical Implementation, visit -- find\_elements\_by\_name()
driver method -- Selenium Python

Note: command find\_elements\_by\_name() is deprecated 

find\_elements(By.XPATH)
------------------------

With this strategy, all elements with pattern of xpath matching the
location will be returned. If no element has a matching element
attribute, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_elements(By.XPATH, "xpath")

Example -- For instance, consider this page source: 

html
----

 

  

           

 

Now after you have created a driver, you can grab elements using --

    login_form = driver.find_elements(By.XPATH, "/html/body/form[1]")
    login_form = driver.find_elements(By.XPATH, "//form[1]")

To check Practical Implementation, visit -- find\_elements\_by\_xpath()
driver method -- Selenium Python

Note: command find\_elements\_by\_xpath() is deprecated

find\_elements(By.LINK\_TEXT)
-----------------------------

With this strategy, all elements with the link text value matching the
location will be returned. If no element has a matching link text
attribute, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_elements(By.LINK_TEXT, "Text of Link")

Example -- For instance, consider this page source: 

html
----

 

  

Are you sure you want to do this?

  [Continue](continue.html)  [Cancel](cancel.html)

Now after you have created a driver, you can grab elements using --

    login_form = driver.find_elements(By.LINK_TEXT, 'Continue')

To check practical Implementation, visit --
find\_elements\_by\_link\_text() driver method -- Selenium Python

Note- command find\_elements\_by\_link\_text() is deprecated

find\_elements(By.PARTIAL\_LINK\_TEXT)
--------------------------------------

With this strategy, all elements with the partial link text value
matching the location will be returned. If no element has a matching
partial link text attribute, a NoSuchElementException will be raised.
Syntax -- 

    driver.find_elements(By.PARTIAL_LINK_TEXT, "Text of Link")

Example -- For instance, consider this page source: 

html
----

 

  

Are you sure you want to do this?

  [Continue](continue.html)  [Cancel](cancel.html)

Now after you have created a driver, you can grab all elements using --

    login_form = driver.find_elements(By.PARTIAL_LINK_TEXT , 'Conti')

To check practical implementation, visit --
find\_elements\_by\_partial\_link\_text() driver method -- Selenium
Python

Note: command find\_elements\_by\_partial\_link\_text() is deprecated

find\_elements(By.TAG\_NAME)
----------------------------

With this strategy, all elements with the given tag name will be
returned. If no element has a matching tag name, a
NoSuchElementException will be raised. Syntax -- 

    driver.find_elements(By.TAG_NAME, "Tag name")

Example: For instance, consider this page source: 

html
----

 

  

Welcome
=======

  

Site content goes here.

Now after you have created a driver, you can grab all elements using --

    login_form = driver.find_elements(By.TAG_NAME, 'h1')

To check practical Implementation, visit --
find\_elements\_by\_tag\_name() driver method -- Selenium Python

Note: command find\_elements\_by\_partial\_tag\_name() is deprecated

find\_elements(By.CLASS\_NAME)
------------------------------

With this strategy, the first element with the matching class attribute
name will be returned. If no element has a matching class attribute
name, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_elements(By.CLASS_NAME,"class_of_element")

Example -- For instance, consider this page source: 

html
----

 

  

Site content goes here.

Now after you have created a driver, you can grab all elements using --

    content = driver.find_elements(By.CLASS_NAME, 'content')

To check practical Implementation, visit --
find\_elements\_by\_class\_name() driver method -- Selenium Python

Note: command find\_elements\_by\_class\_name() is deprecated

find\_elements(By.CSS\_SELECTOR)
--------------------------------

With this strategy, all elements with the matching CSS selector will be
returned. If no element has a matching CSS selector, a
NoSuchElementException will be raised. 

Syntax: 

    driver.find_elements(By.CSS_SELECTOR, "CSS Selectors")

Example -- For instance, consider this page source: 

html
----

 

  

Site content goes here.

Now after you have created a driver, you can grab all elements using --

    content = driver.find_elements(By.CSS_SELECTOR, 'p.content')

To check practical implementation, visit --
find\_elements\_by\_css\_selector() driver method -- Selenium Python

Note: command find\_elements\_by\_css\_selector() is deprecated
