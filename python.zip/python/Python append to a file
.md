---
title: "Python append to a file
"
draft: false
menu:
sidebar:
name: "Python append to a file
"
parent: "Python"
weight: 72
---

Python append to a file
-----------------------



While reading or writing to a file, access mode governs the type of
operations possible in the opened file. It refers to how the file will
be used once it's opened. These modes also define the location of the
File Handle in the file. The definition of these access modes is as
follows:

Append Only ('a'): Open the file for writing.

Append and Read ('a+'): Open the file for reading and writing.

When the file is opened in append mode in Python, the handle is
positioned at the end of the file. The data being written will be
inserted at the end, after the existing data. 

Example 1: Python program to illustrate Append vs write mode.
-------------------------------------------------------------

Python3
-------

file1 = open(\"myfile.txt\", \"w\")L = \[\"This is Delhi \\n\", \"This
is Paris \\n\", \"This is London\"\]file1.writelines(L)file1.close() \#
Append-adds at lastfile1 = open(\"myfile.txt\", \"a\")  \# append
modefile1.write(\"Today \\n\")file1.close() file1 = open(\"myfile.txt\",
\"r\")print(\"Output of Readlines after
appending\")print(file1.read())print()file1.close() \#
Write-Overwritesfile1 = open(\"myfile.txt\", \"w\")  \# write
modefile1.write(\"Tomorrow \\n\")file1.close() file1 =
open(\"myfile.txt\", \"r\")print(\"Output of Readlines after
writing\")print(file1.read())print()file1.close()

Output:

    Output of Readlines after appending
    This is Delhi
    This is Paris
    This is LondonToday


    Output of Readlines after writing
    Tomorrow

Example 2:  Append data from a new line
---------------------------------------

In the above example of file handling, it can be seen that the data is
not appended from the new line. This can be done by writing the newline
'\\n' character to the file. 

Python3
-------

\# Python program to illustrate\# append from new line file1 =
open(\"myfile.txt\", \"w\")L = \[\"This is Delhi \\n\", \"This is Paris
\\n\", \"This is London\"\]file1.writelines(L)file1.close() \#
Append-adds at last\# append modefile1 = open(\"myfile.txt\", \"a\") \#
writing newline characterfile1.write(\"\\n\")file1.write(\"Today\") \#
without newline characterfile1.write(\"Tomorrow\")  file1 =
open(\"myfile.txt\", \"r\")print(\"Output of Readlines after
appending\")print(file1.read())print()file1.close()

Output:

    Output of Readlines after appending
    This is Delhi
    This is Paris
    This is London
    TodayTomorrow

Note: '\\n' is treated as a special character of two bytes.

Example 3:  Using With statement  in Python
-------------------------------------------

with statement is used in exception handling to make the code cleaner
and much more readable. It simplifies the management of common resources
like file streams. Unlike the above implementations, there is no need to
call file.close() when using with statement. The with statement itself
ensures proper acquisition and release of resources. 

Python3
-------

\# Program to show various ways to\# append data to a file using\# with
statement L = \[\"This is Delhi \\n\", \"This is Paris \\n\", \"This is
London \\n\"\] \# Writing to filewith open(\"myfile.txt\", \"w\") as
file1:    \# Writing data to a file    file1.write(\"Hello
\\n\")    file1.writelines(L) \# Appending to filewith
open(\"myfile.txt\", \'a\') as file1:    file1.write(\"Today\")  \#
Reading from filewith open(\"myfile.txt\", \"r+\") as file1:    \#
Reading form a file    print(file1.read())

Output:

    Hello
    This is Delhi
    This is Paris
    This is London
    Today

Note: To know more about with statement click here.

Using the shutil module:
------------------------

This approach uses the shutil.copyfileobj() method to append the
contents of another file (source\_file) to 'file.txt'. This can be
useful if you want to append the contents of one file to another without
having to read the contents into memory first.

Approach:The code uses the shutil.copyfileobj() function to copy the
contents of the source\_file object to a new file called file.txt. The
with statement is used to open and automatically close the file, using
the file object f.

Time Complexity:The time complexity of shutil.copyfileobj() function is
proportional to the size of the file being copied, as it needs to read
and write every byte of the file. Therefore, the time complexity of the
code is O(n), where n is the size of the source\_file.

Space Complexity:The space complexity of the code is O(1), as it does
not allocate any additional memory beyond what is required for the file
objects source\_file and f. The shutil.copyfileobj() function copies the
file contents in chunks, so it does not need to load the entire file
into memory at once.

Overall, the code has a linear time complexity and constant space
complexity, where the time complexity is proportional to the size of the
file being copied. 

Python3
-------

import shutil with open(\'file.txt\', \'a\') as
f:    shutil.copyfileobj(source\_file, f)
