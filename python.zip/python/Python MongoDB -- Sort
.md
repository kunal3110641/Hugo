---
title: "Python MongoDB -- Sort
"
draft: false
menu:
sidebar:
name: "Python MongoDB -- Sort
"
parent: "Python"
weight: 130
---

Python MongoDB -- Sort
----------------------



MongoDB is a cross-platform document-oriented database program and the
most popular NoSQL database program. The term NoSQL means
non-relational. MongoDB stores the data in the form of key-value pairs.
It is an Open Source, Document Database which provides high performance
and scalability along with data modeling and data management of huge
sets of data in an enterprise application. MongoDB also provides the
feature of Auto-Scaling. It uses JSON-like documents, which makes the
database very flexible and scalable. Note: For more information, refer
to MongoDB and Python

Sorting the MongoDB documents
-----------------------------

sort() method is used for sorting the database in some order. This
method accepts two parameters first is the fieldname and the second one
is for the direction to sort. (By default it sorts in ascending order) 

Syntax:

    sort(key_or_list, direction)

    key_or_list: a single key or a list of (key, direction) pairs specifying the keys to sort on
    direction (optional): only used if key_or_list is a single key, if not given ASCENDING is assumed

Note: 1 as the direction is used for ascending order and -1 as the
direction is used for descending order 

Example 1: Using sort() function to sort the result alphabetically by
name. Let's suppose the database looks like this:

 

![python-mongodb-db](https://media.geeksforgeeks.org/wp-content/uploads/20200226130803/python-mongodb-db.png)

Python3
-------

\# python code to sort elements\# alphabetically in ascending
order import pymongo  \# establishing connection\# to the
databasemy\_client = pymongo.MongoClient(\'localhost\', 27017) \# Name
of the databasemydb = my\_client\[& quot                  gfg &
quot                  \] \# Name of the collectionmynew = mydb\[&
quot              names & quot              \] \# sorting functionmydoc
= mynew.find().sort(& quot                           name &
quot                           ) for x in mydoc:    print(x)

Output : Example 2: Sorting in descending order 

![python-mongodb-sort-1](https://media.geeksforgeeks.org/wp-content/uploads/20200226131211/python-mongodb-sort-1.png)

Python3
-------

import pymongo  \# establishing connection\# to the databasemy\_client =
pymongo.MongoClient(\'localhost\', 27017) \# Name of the databasemydb =
my\_client\[& quot                  gfg & quot                  \] \#
Name of the collectionmynew = mydb\[& quot              names &
quot              \] \# sorting function with -1\# as directionmydoc =
mynew.find().sort(&
quot                           name\"                           ,
-1) for x in mydoc:    print(x)

Output :

![python-mongodb-sort-2](https://media.geeksforgeeks.org/wp-content/uploads/20200226131623/python-mongodb-sort-2.png)
