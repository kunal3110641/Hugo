---
title: "Python pass Statement
"
draft: false
menu:
sidebar:
name: "Python pass Statement
"
parent: "Python"
weight: 39
---

Python pass Statement
---------------------



The Python pass statement is a null statement. But the difference
between pass and comment is that comment is ignored by the interpreter
whereas pass is not ignored. 

The Syntax of the pass statement
--------------------------------

    pass

What is pass statement in Python?
---------------------------------

When the user does not know what code to write, So user simply places a
pass at that line. Sometimes, the pass is used when the user doesn't
want any code to execute. So users can simply place a pass where empty
code is not allowed, like in loops, function definitions, class
definitions, or in if statements. So using a pass statement user avoids
this error.

Why Python Needs "pass" Statement?
----------------------------------

If we do not use pass or simply enter a comment or a blank here, we will
receive an IndentationError error message.

Python3
-------

n = 26 if n \> 26:    \# write code your here print(\'Geeks\')

Output:

    IndentationError: expected an indented block after 'if' statement

Examples of Python pass statement
---------------------------------

Let's see some of the examples to understand pass statements in Python
more clearly.

Use of pass keyword in Function
-------------------------------

Python Pass keyword can be used in empty functions. To read more click
here

Python3
-------

def function:  pass

Use of pass keyword in Python Class
-----------------------------------

The pass keyword can also be used in an empty class in Python.

Python3
-------

class geekClass:  pass

Use of pass keyword in Python Loop 
-----------------------------------

The pass keyword can be used in Python for loop, when a user doesn't
know what to code inside the loop in Python.

Python3
-------

n = 10for i in range(n):     \# pass can be used as placeholder  \# when
code is to added later  pass

Use of pass keyword in Conditional statement
--------------------------------------------

Python pass keyword can be used with conditional statements.

Python3
-------

a = 10b = 20 if(a

Let's take another example in which the pass statement gets executed
when the condition is true.

Python3
-------

li =\[\'a\', \'b\', \'c\', \'d\'\] for i in li:    if(i
==\'a\'):        pass    else:        print(i)

Output:

    b
    c
    d

To read more on Python Continue and Python Break.

Python The pass Keyword in If
-----------------------------

In the first example, the pass statement is used as a placeholder inside
an if statement. If the condition in the if statement is true, no action
is taken, but the program will not raise a syntax error because the pass
statement is present.

In the second example, the pass statement is used inside a function
definition as a placeholder for implementation. This is useful when
defining a function that will be used later, but for which the
implementation has not yet been written.

In the third example, the pass statement is used inside a class
definition as a placeholder for implementation. This is useful when
defining a class that will be used later, but for which the
implementation has not yet been written.

Note that in all cases, the pass statement is followed by a colon (:) to
indicate the start of a code block, but there is no code inside the
block. This is what makes it a placeholder statement.

Python3
-------

\# Using pass as a placeholder inside an if statementx = 5if x \>
10:    passelse:    print(\"x is less than or equal to 10\") \# Using
pass in a function definition as a\# placeholder for implementationdef
my\_function():    pass \# Using pass in a class definition as\# a
placeholder for implementation class MyClass:    def
\_\_init\_\_(self):        pass

    x is less than or equal to 10
