---
title: "Python Plotly tutorial
"
draft: false
menu:
sidebar:
name: "Python Plotly tutorial
"
parent: "Python"
weight: 145
---

Python Plotly tutorial
----------------------



Python Plotly Library is an open-source library that can be used for
data visualization and understanding data simply and easily. Plotly
supports various types of plots like line charts, scatter plots,
histograms, cox plots, etc. So you all must be wondering why Plotly over
other visualization tools or libraries? Here's the answer --

Plotly has hover tool capabilities that allow us to detect any outliers
or anomalies in a large number of data points.

It is visually attractive that can be accepted by a wide range of
audiences.

It allows us for the endless customization of our graphs that makes our
plot more meaningful and understandable for others.

![Python Plotly
Tutorial](https://media.geeksforgeeks.org/wp-content/uploads/20210217185640/PythonPlotlyTutorialmin3.png)

This tutorial aims at providing you the insight about Plotly with the
help of the huge dataset explaining the Plotly from basics to advance
and covering all the popularly used charts.

Table Of Content 

Installation

Package Structure of Plotly

Getting Started

Creating Different Types of ChartsLine ChartBar ChartHistogramsScatter
Plot and Bubble chartsPie ChartsBox PlotsViolin plotsGantt ChartsContour
PlotsHeatmapsError Bars3D Line Plots3D Scatter Plot Plotly3D Surface
PlotsInteracting with the PlotsCreating Dropdown Menu in PlotlyAdding
Buttons to the PlotCreating Sliders and Selectors to the PlotMore Plots
using Plotly

Line Chart

Bar Chart

Histograms

Scatter Plot and Bubble charts

Pie Charts

Box Plots

Violin plots

Gantt Charts

Contour Plots

Heatmaps

Error Bars

3D Line Plots

3D Scatter Plot Plotly

3D Surface Plots

Interacting with the PlotsCreating Dropdown Menu in PlotlyAdding Buttons
to the PlotCreating Sliders and Selectors to the PlotMore Plots using
Plotly

Creating Dropdown Menu in Plotly

Adding Buttons to the Plot

Creating Sliders and Selectors to the Plot

More Plots using Plotly

Recent Articles on Plotly !!! 

Installation
------------

Plotly does not come built-in with Python. To install it type the below
command in the terminal.

    pip install plotly

![](https://media.geeksforgeeks.org/wp-content/uploads/20210201145943/plotlyinstall2.png)

This may take some time as it will install the dependencies as well.

Package Structure of Plotly
---------------------------

There are three main modules in Plotly. They are:

plotly.plotly

plotly.graph.objects

plotly.tools

plotly.plotly acts as the interface between the local machine and
Plotly. It contains functions that require a response from Plotly's
server.

plotly.graph\_objects module contains the objects (Figure, layout, data,
and the definition of the plots like scatter plot, line chart) that are
responsible for creating the plots.  The Figure can be represented
either as dict or instances of plotly.graph\_objects.Figure and these
are serialized as JSON before it gets passed to plotly.js. Consider the
below example for better understanding.

Note: plotly.express module can create the entire Figure at once. It
uses the graph\_objects internally and returns the graph\_objects.Figure
instance.

Example:

Python3
-------

import plotly.express as px     \# Creating the Figure instancefig =
px.line(x=\[1,2, 3\], y=\[1, 2, 3\])   \# printing the figure
instanceprint(fig)

Output:

![plotly tutorial package
structure](https://media.geeksforgeeks.org/wp-content/uploads/20210201161642/plotlytutorialpackagestructure.png)

Figures are represented as trees where the root node has three top layer
attributes -- data, layout, and frames and the named nodes called
'attributes'. Consider the above example, layout.legend is a nested
dictionary where the legend is the key inside the dictionary whose value
is also a dictionary.  

plotly.tools module contains various tools in the forms of the functions
that can enhance the Plotly experience. 

Getting Started
---------------

After learning the installation and basic structure of the Plotly, let's
create a simple plot using the pre-defined data sets defined by the
plotly.

Example:

Python3
-------

import plotly.express as px     \# Creating the Figure instancefig =
px.line(x=\[1, 2, 3\], y=\[1, 2, 3\])   \# showing the plotfig.show()

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/20210201163831/plotlytutorialsimplechart.png)

In the above example, the plotly.express module is imported which
returns the Figure instance. We have created a simple line chart by
passing the x, y coordinates of the points to be plotted.

Creating Different Types of Charts
----------------------------------

With plotly we can create more than 40 charts and every plot can be
created using the plotly.express and plotly.graph\_objects class. Let's
see some commonly used charts with the help of Plotly.

Line Chart
----------

Line plot in Plotly is much accessible and illustrious annexation to
plotly which manage a variety of types of data and assemble
easy-to-style statistic. With px.line each data position is represented
as a vertex  (which location is given by the x and y columns) of a
polyline mark in 2D space.

Example:

Python3
-------

import plotly.express as px   \# using the iris datasetdf =
px.data.iris()   \# plotting the line chartfig = px.line(df,
x=\"species\", y=\"petal\_width\")   \# showing the plotfig.show()

Output:

![plotly tutorial line
chart](https://media.geeksforgeeks.org/wp-content/uploads/20210201173603/plotlytutoriallinechart.png)

Refer to the below articles to get detailed information about the line
charts.

plotly.express.line() function in Python

Line Chart using Plotly in Python

Bar Chart
---------

A bar chart is a pictorial representation of data that presents
categorical data with rectangular bars with heights or lengths
proportional to the values that they represent. In other words, it is
the pictorial representation of dataset. These data sets contain the
numerical values of variables that represent the length or height.

Example:

Python3
-------

import plotly.express as px   \# using the iris datasetdf =
px.data.iris()   \# plotting the bar chartfig = px.bar(df,
x=\"sepal\_width\", y=\"sepal\_length\")   \# showing the plotfig.show()

Output:

![plotly tutorial bar
chart](https://media.geeksforgeeks.org/wp-content/uploads/20200630214054/pythonbar.png)

Refer to the below articles to get detailed information about the bar
chart.

Bar chart using Plotly in Python

How to create Stacked bar chart in Python-Plotly?

How to group Bar Charts in Python-Plotly?

Histograms
----------

A histogram contains a rectangular area to display the statistical
information which is proportional to the frequency of a variable and its
width in successive numerical intervals. A graphical representation that
manages a group of data points into different specified ranges. It has a
special feature that shows no gaps between the bars and similar to a
vertical bar graph.

Example:

Python3
-------

import plotly.express as px   \# using the iris datasetdf =
px.data.iris()   \# plotting the histogramfig = px.histogram(df,
x=\"sepal\_length\", y=\"petal\_width\")   \# showing the plotfig.show()

Output:

![plotly tutorial
histogram](https://media.geeksforgeeks.org/wp-content/uploads/20210201180633/plotlytutorialhistogram.png)

Refer to the below articles to get detailed information about the
histograms.

Histogram using Plotly in Python

Histograms in Plotly using graph\_objects class

How to create a Cumulative Histogram in Plotly?

Scatter Plot and Bubble charts
------------------------------

A scatter plot is a set of dotted points to represent individual pieces
of data in the horizontal and vertical axis. A graph in which the values
of two variables are plotted along X-axis and Y-axis, the pattern of the
resulting points reveals a correlation between them.

A bubble plot is a scatter plot with bubbles (color-filled circles).
Bubbles have various sizes dependent on another variable in the data. It
can be created using the scatter() method of plotly.express.

Example 1: Scatter Plot

Python3
-------

import plotly.express as px   \# using the iris datasetdf =
px.data.iris()   \# plotting the scatter chartfig = px.scatter(df,
x=\"species\", y=\"petal\_width\")   \# showing the plotfig.show()

Output:

![plotly tutorial scatter
plot](https://media.geeksforgeeks.org/wp-content/uploads/20210201174347/plotlytutorialscatterplot.png)

Example 2: Bubble Plot

Python3
-------

import plotly.express as px   \# using the iris datasetdf =
px.data.iris()   \# plotting the bubble chartfig = px.scatter(df,
x=\"species\",
y=\"petal\_width\",                  size=\"petal\_length\",
color=\"species\")   \# showing the plotfig.show()

Output:

![plotly tutorial bubble
chart](https://media.geeksforgeeks.org/wp-content/uploads/20210201175608/plotlytutorialbubblechart3.jpg)

Refer to the below articles to get detailed information about the
scatter plots and bubble plots.

plotly.express.scatter() function in Python

Scatter plot in Plotly using graph\_objects class

Scatter plot using Plotly in Python

Bubble chart using Plotly in Python

Pie Charts
----------

A pie chart is a circular statistical graphic, which is divided into
slices to illustrate numerical proportions. It depicts a special chart
that uses "pie slices", where each sector shows the relative sizes of
data. A circular chart cuts in a form of radii into segments describing
relative frequencies or magnitude also known as circle graph.

Example:

Python3
-------

import plotly.express as px   \# using the tips datasetdf =
px.data.tips()   \# plotting the pie chartfig = px.pie(df,
values=\"total\_bill\", names=\"day\")   \# showing the plotfig.show()

Output:

![plotly tutorial pie
chart](https://media.geeksforgeeks.org/wp-content/uploads/20210201181833/plotlytutorialpiechart.png)

Refer to the below articles to get detailed information about the pie
charts.

Pie plot using Plotly in Python

Box Plots
---------

A Box Plot is also known as Whisker plot is created to display the
summary of the set of data values having properties like minimum, first
quartile, median, third quartile and maximum. In the box plot, a box is
created from the first quartile to the third quartile, a vertical line
is also there which goes through the box at the median. Here x-axis
denotes the data to be plotted while the y-axis shows the frequency
distribution.

Example:

Python3
-------

import plotly.express as px   \# using the tips datasetdf =
px.data.tips()   \# plotting the box chartfig = px.box(df, x=\"day\",
y=\"total\_bill\")   \# showing the plotfig.show()

Output:

![plotly tutorial box
plots](https://media.geeksforgeeks.org/wp-content/uploads/20210201183133/plotlytutorialboxplots.png)

Refer to the below articles to get detailed information about box plots.

Box Plot using Plotly in Python

Box plot in Plotly using graph\_objects class

How to create Grouped box plot in Plotly?

Violin plots
------------

Violin Plot is a method to visualize the distribution of numerical data
of different variables. It is similar to Box Plot but with a rotated
plot on each side, giving more information about the density estimate on
the y-axis. The density is mirrored and flipped over and the resulting
shape is filled in, creating an image resembling a violin. The advantage
of a violin plot is that it can show nuances in the distribution that
aren't perceptible in a boxplot. On the other hand, the boxplot more
clearly shows the outliers in the data.

Example:

Python3
-------

import plotly.express as px   \# using the tips datasetdf =
px.data.tips()   \# plotting the violin chartfig = px.violin(df,
x=\"day\", y=\"total\_bill\")  \# showing the plotfig.show()

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/20210201190948/plotlytutorialviolinplot.png)

Refer to the below articles to get detailed information about the violin
plots.

Violin Plots using Plotly

Gantt Charts
------------

Generalized Activity Normalization Time Table (GANTT) chart is type of
chart in which series of horizontal lines are present that show the
amount of work done or production completed in given period of time in
relation to amount planned for those projects. 

Example:

Python3
-------

import plotly.figure\_factory as ff   \# Data to be plotteddf =
\[dict(Task=\"A\", Start=\'2020-01-01\',
Finish=\'2009-02-02\'),     dict(Task=\"Job B\", Start=\'2020-03-01\',
Finish=\'2020-11-11\'),     dict(Task=\"Job C\", Start=\'2020-08-06\',
Finish=\'2020-09-21\')\]   \# Creating the plotfig =
ff.create\_gantt(df) fig.show()

Output:

![Plotly Tutorial Gantt
chart](https://media.geeksforgeeks.org/wp-content/uploads/20200629170724/pythongantt1.png)

Refer to the below articles to get detailed information about the Gantt
Charts.

Gantt Chart in Plotly

Contour Plots
-------------

Contour plots also called level plots are a tool for doing multivariate
analysis and visualizing 3-D plots in 2-D space. If we consider X and Y
as our variables we want to plot then the response Z will be plotted as
slices on the X-Y plane due to which contours are sometimes referred as
Z-slices or iso-response.

A contour plots is used in the case where you want to see the changes in
some value (Z) as a function with respect to the two values (X, Y).
Consider the below example.

Example:

Python3
-------

import plotly.graph\_objects as go     \# Creating the X, Y value that
will\# change the values of Z as a functionfeature\_x = np.arange(0, 50,
2) feature\_y = np.arange(0, 50, 3)   \# Creating 2-D grid of
features \[X, Y\] = np.meshgrid(feature\_x, feature\_y)   Z = np.cos(X /
2) + np.sin(Y / 4)   \# plotting the figurefig = go.Figure(data
=    go.Contour(x = feature\_x, y = feature\_y, z = Z))   fig.show()

Output:

![plotly tutorial contour
plots](https://media.geeksforgeeks.org/wp-content/uploads/20200902223636/contourplotsplotly1.png)

Refer to the below articles to get detailed information about contour
plots.

Contour Plots using Plotly in Python

Heatmaps
--------

Heatmap is defined as a graphical representation of data using colors to
visualize the value of the matrix. In this, to represent more common
values or higher activities brighter colors basically reddish colors are
used and to represent less common or activity values, darker colors are
preferred. Heatmap is also defined by the name of the shading matrix. 

Example: 

Python3
-------

import plotly.graph\_objects as go     feature\_x = np.arange(0, 50,
2) feature\_y = np.arange(0, 50, 3)   \# Creating 2-D grid of
features \[X, Y\] = np.meshgrid(feature\_x, feature\_y)   Z = np.cos(X /
2) + np.sin(Y / 4)   \# plotting the figurefig = go.Figure(data
=     go.Heatmap(x = feature\_x, y = feature\_y, z = Z,))   fig.show()

Output:

![plotly tutorial
heatmap](https://media.geeksforgeeks.org/wp-content/uploads/20210202195636/plotlytutorialheatmap.png)

Refer to the below articles to get detailed information about the
heatmaps.

Create Heatmaps using graph\_objects class in Plotly

Annotated Heatmaps using Plotly in Python

Error Bars
----------

For functions representing 2D data points such as px.scatter, px.line,
px.bar, etc., error bars are given as a column name which is the value
of the error\_x (for the error on x position) and error\_y (for the
error on y position). Error bars are the graphical presentation
alternation of data and used on graphs to imply the error or uncertainty
in a reported capacity.

Example:

Python3
-------

import plotly.express as px   \# using the iris datasetdf =
px.data.iris()   \# Calculating the error fielddf\[\"error\"\] =
df\[\"petal\_length\"\]/100  \# plotting the scatter chartfig =
px.scatter(df, x=\"species\",
y=\"petal\_width\",                error\_x=\"error\",
error\_y=\"error\")   \# showing the plotfig.show()

Output:

![plotly tutorial error
bar](https://media.geeksforgeeks.org/wp-content/uploads/20210202203633/plotlytutorialerrorbar.png)

3D Line Plots
-------------

Line plot in plotly is much accessible and illustrious annexation to
plotly which manage a variety of types of data and assemble
easy-to-style statistic. With px.line\_3d each data position is
represented as a vertex  (which location is given by the x, y and z
columns) of a polyline mark in 3D space.

Example:

Python3
-------

import plotly.express as px   \# data to be plotteddf =
px.data.tips()   \# plotting the figurefig = px.line\_3d(df, x=\"sex\",
y=\"day\",                  z=\"time\", color=\"sex\")   fig.show()

Output:

![poltly tutorial 3d
line](https://media.geeksforgeeks.org/wp-content/uploads/20210202210749/poltlytutorial3dline.png)

Refer to the below articles to get detailed information about the 3D
line charts.

plotly.express.line\_3d() function in Python

3D Line Plots using Plotly in Python

3D Scatter Plot Plotly
----------------------

3D Scatter Plot can plot two-dimensional graphics that can be enhanced
by mapping up to three additional variables while using the semantics of
hue, size, and style parameters. All the parameter control visual
semantic which are used to identify the different subsets. Using
redundant semantics can be helpful for making graphics more accessible.
It can be created using the scatter\_3d function of plotly.express
class.

Example:

Python3
-------

import plotly.express as px   \# Data to be plotteddf =
px.data.iris()   \# Plotting the figurefig = px.scatter\_3d(df, x =
\'sepal\_width\',                     y =
\'sepal\_length\',                     z =
\'petal\_width\',                     color = \'species\')   fig.show()

Output:

![plotly tutorial 3d scatter
plot](https://media.geeksforgeeks.org/wp-content/uploads/20200704174415/3dscatterplotplotly.png)

Refer to the below articles to get detailed information about the 3D
scatter plot.

3D scatter plot using Plotly in Python

3D Scatter Plot using graph\_objects Class in Plotly-Python

3D Bubble chart using Plotly in Python

3D Surface Plots
----------------

Surface plot is those plot which has three-dimensions data which is X,
Y, and Z. Rather than showing individual data points, the surface plot
has a functional relationship between dependent variable Y and have two
independent variables X and Z. This plot is used to distinguish between
dependent and independent variables.

Example:

Python3
-------

import plotly.graph\_objects as go import numpy as np   \# Data to be
plottedx = np.outer(np.linspace(-2, 2, 30), np.ones(30)) y =
x.copy().T z = np.cos(x \*\* 2 + y \*\* 2)   \# plotting the figurefig =
go.Figure(data=\[go.Surface(x=x, y=y, z=z)\])   fig.show()

Output:

![plotly tutorial 3d
surface](https://media.geeksforgeeks.org/wp-content/uploads/20200824204556/surfaceplotplotly.png)

Interacting with the Plots
--------------------------

Plotly provides various tools for interacting with the plots such as
adding dropdowns, buttons, sliders, etc. These can be created using the
update menu attribute of the plot layout. Let's see how to do all such
things in detail.

Creating Dropdown Menu in Plotly
--------------------------------

A drop-down menu is a part of the menu-button which is displayed on a
screen all the time. Every menu button is associated with a Menu widget
that can display the choices for that menu button when clicked on it. In
plotly, there are 4 possible methods to modify the charts by using
update menu method.

restyle: modify data or data attributes

relayout: modify layout attributes

update: modify data and layout attributes

animate: start or pause an animation

Example:

Python3
-------

import plotly.graph\_objects as pximport numpy as np    \# creating
random data through randomint\# function of
numpy.randomnp.random.seed(42)  \# Data to be Plottedrandom\_x =
np.random.randint(1, 101, 100)random\_y = np.random.randint(1, 101,
100)  plot =
px.Figure(data=\[px.Scatter(    x=random\_x,    y=random\_y,    mode=\'markers\',)\])  \#
Add
dropdownplot.update\_layout(    updatemenus=\[        dict(            buttons=list(\[                dict(                    args=\[\"type\",
\"scatter\"\],                    label=\"Scatter
Plot\",                    method=\"restyle\"                ),                dict(                    args=\[\"type\",
\"bar\"\],                    label=\"Bar
Chart\",                    method=\"restyle\"                )            \]),            direction=\"down\",        ),    \])  plot.show()

Output:

In the above example we have created two graphs for the same data. These
plots are accessible using the dropdown menu.

Adding Buttons to the Plot
--------------------------

In plotly, actions custom Buttons are used to quickly make actions
directly from a record. Custom Buttons can be added to page layouts in
CRM, Marketing, and Custom Apps. There are also 4 possible methods that
can be applied in custom buttons:

restyle: modify data or data attributes

relayout: modify layout attributes

update: modify data and layout attributes

animate: start or pause an animation

Example:

Python3
-------

import plotly.graph\_objects as pximport pandas as pd  \# reading the
databasedata = pd.read\_csv(\"tips.csv\")    plot =
px.Figure(data=\[px.Scatter(    x=data\[\'day\'\],    y=data\[\'tip\'\],    mode=\'markers\',)\])  \#
Add
dropdownplot.update\_layout(    updatemenus=\[        dict(            type=\"buttons\",            direction=\"left\",            buttons=list(\[                dict(                    args=\[\"type\",
\"scatter\"\],                    label=\"Scatter
Plot\",                    method=\"restyle\"                ),                dict(                    args=\[\"type\",
\"bar\"\],                    label=\"Bar
Chart\",                    method=\"restyle\"                )            \]),        ),    \])  plot.show()

Output:

![button-plotly](https://media.geeksforgeeks.org/wp-content/cdn-uploads/20210604221456/button-plotly.gif)

In this example also we are creating two different plots on the same
data and both plots are accessible by the buttons.

Creating Sliders and Selectors to the Plot
------------------------------------------

In plotly, the range slider is a custom range-type input control. It
allows selecting a value or a range of values between a specified
minimum and maximum range. And the range selector is a tool for
selecting ranges to display within the chart. It provides buttons to
select pre-configured ranges in the chart. It also provides input boxes
where the minimum and maximum dates can be manually input.

Example:

Python3
-------

import plotly.graph\_objects as px import plotly.express as go import
numpy as np   df = go.data.tips()   x = df\[\'total\_bill\'\] y =
df\[\'day\'\]   plot =
px.Figure(data=\[px.Scatter(     x=x,     y=y,     mode=\'lines\',) \])   plot.update\_layout(     xaxis=dict(         rangeselector=dict(             buttons=list(\[                 dict(count=1,                     step=\"day\",                     stepmode=\"backward\"),             \])         ),         rangeslider=dict(             visible=True        ),     ) )   plot.show() 

Output:

More Plots using Plotly
-----------------------

plotly.express.scatter\_geo() function in Python

plotly.express.scatter\_polar() function in Python

plotly.express.scatter\_ternary() function in Python

plotly.express.line\_ternary() function in Python

Filled area chart using plotly in Python

How to Create Stacked area plot using Plotly in Python?

Sunburst Plot using Plotly in Python

Sunburst Plot using graph\_objects class in plotly

plotly.figure\_factory.create\_annotated\_heatmap() function in Python

plotly.figure\_factory.create\_2d\_density() function in Python

Ternary contours Plot using Plotly in Python

How to make Log Plots in Plotly -- Python?

Polar Charts using Plotly in Python

Carpet Contour Plot using Plotly in Python

Ternary Plots in Plotly

How to create a Ternary Overlay using Plotly?

Parallel Coordinates Plot using Plotly in Python

Carpet Plots using Plotly in Python

3D Cone Plots using Plotly in Python

3D Volume Plots using Plotly in Python

3D Streamtube Plots using Plotly in Python

3D Mesh Plots using Plotly in Python

How to create Tables using Plotly in Python?

plotly.figure\_factory.create\_dendrogram() function in Python

Define Node position in Sankey Diagram in plotly

Sankey Diagram using Plotly in Python

Quiver Plots using Plotly in Python

Treemap using Plotly in Python

Treemap using graph\_objects class in plotly

plotly.figure\_factory.create\_candlestick() function in Python

plotly.figure\_factory.create\_choropleth() function in Python

plotly.figure\_factory.create\_bullet() in Python

Streamline Plots in Plotly using Python

How to make Wind Rose and Polar Bar Charts in Plotly -- Python?

More Topics on Plotly
---------------------

Title alignment in Plotly

Change marker border color in Plotly -- Python

Plot Live Graphs using Python Dash and Plotly

Animated Data Visualization using Plotly Express

Introduction to Plotly-online using Python

How to display image using Plotly?
