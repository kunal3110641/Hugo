---
title: "Python MongoDB -- Query
"
draft: false
menu:
sidebar:
name: "Python MongoDB -- Query
"
parent: "Python"
weight: 129
---

Python MongoDB -- Query
-----------------------



MongoDB is a cross-platform document-oriented and a non relational (i.e
NoSQL) database program. It is an open-source document database, that
stores the data in the form of key-value pairs.

What is a MongoDB Query?
------------------------

MongoDB query is used to specify the selection filter using query
operators while retrieving the data from the collection by db.find()
method. We can easily filter the documents using the query object. To
apply the filter on the collection, we can pass the query specifying the
condition for the required documents as a parameter to this method,
which is an optional parameter for db.find() method. 

Query Selectors: Following is the list of some operators used in the
queries in MongoDB. 

OperationSyntaxDescriptionEquality{"key" : "value"}Matches values that
are equal to a specified value.Less Than{"key" :{\$lt:"value"}}Matches
values that are less than a specified value.Greater Than{"key"
:{\$gt:"value"}}Matches values that are greater than a specified
value.Less Than Equal to{"key" :{\$lte:"value"}}Matches values that are
less than or equal to a specified value.Greater Than Equal to{"key"
:{\$gte:"value"}}Matches values that are greater than or equal to a
specified value.Not Equal to{"key":{\$ne: "value"}}Matches all values
that are not equal to a specified value.Logical AND{ "\$and":\[{exp1},
{exp2}, ..., {expN}\] }Joins query clauses with a logical AND returns
all documents that match the conditions of both clauses.Logical OR{
"\$or":\[{exp1}, {The Database or Collection on which we operate:

  

![](https://media.geeksforgeeks.org/wp-content/uploads/20200604185334/Mongo15.png)

Example 1: 

Python3
-------

\# importing Mongoclient from pymongofrom pymongo import MongoClient  \#
Making Connectionmyclient =
MongoClient(\"mongodb://localhost:27017/\")  \# databasedb =
myclient\[\"mydatabase\"\]  \# Created or Switched to collection\#
names: GeeksForGeeksCollection = db\[\"GeeksForGeeks\"\] \# Filtering
the Quantities greater\# than 40 using query.cursor =
Collection.find({\"Quantity\":{\"\$gt\":40}}) \# Printing the filtered
data.print(\"The data having Quantity greater than 40 is:\")for record
in cursor:    print(record)     \# Filtering the Quantities less\# than
40 using query.cursor = Collection.find({\"Quantity\":{\"\$lt\":40}}) \#
Printing the filtered data.print(\"\\nThe data having Quantity less than
40 is:\")for record in cursor:    print(record)

Output: 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200604193256/Ex119.png)

Example 2: 

Python3
-------

\# importing Mongoclient from pymongofrom pymongo import MongoClient  \#
Making Connectionmyclient =
MongoClient(\"mongodb://localhost:27017/\")  \# databasedb =
myclient\[\"mydatabase\"\]  \# Created or Switched to collection\#
names: GeeksForGeeksCollection = db\[\"GeeksForGeeks\"\] \# Filtering
the (Quantities greater than\# 40 AND greater than 40) using AND
query.cursor =
Collection.find({\"\$and\":\[{\"Quantity\":{\"\$gt\":40}},                                  {\"Quantity\":{\"\$gt\":50}}\]}) \#
Printing the filtered data.print(\"Quantities greater than 40
AND\\Quantities greater than 40 :\")for record in
cursor:    print(record) \# Filtering the (Quantities greater than\# 40
OR greater than 40) using OR query.cursor =
Collection.find({\"\$or\":\[{\"Quantity\":{\"\$gt\":40}},                                 {\"Quantity\":{\"\$gt\":50}}\]}) \#
Printing the filtered data.print()print(\"Quantities greater than 40
OR\\Quantities greater than 40 :\")for record in
cursor:    print(record)

Output: 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200604193219/EX215.png)
