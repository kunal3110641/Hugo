---
title: "Chaining comparison operators in Python
"
draft: false
menu:
sidebar:
name: "Chaining comparison operators in Python
"
parent: "Python"
weight: 34
---

Chaining comparison operators in Python
---------------------------------------



Checking more than two conditions is very common in Programming
Languages. Let's say we want to check the below condition:

    a < b < c

The most common syntax to do it is as follows:

    if a < b and b < c :
       {...}

In Python, there is a better way to write this using the Comparison
operator Chaining. The chaining of operators can be written as follows:

    if a < b < c :
        {.....}

According to associativity and precedence in Python, all comparison
operations in Python have the same priority, which is lower than that of
any arithmetic, shifting, or bitwise operation. Also unlike C,
expressions like a \< b \< c have an interpretation that is conventional
in mathematics. List of comparison operators in Python:

    ">" | "<" | "==" | ">=" | "<=" | "!=" | "is" ["not"] | ["not"] "in"

Chaining in Comparison Operators:

Comparisons yield boolean values: True or False.

Comparisons can be chained arbitrarily. For example:

    x < y <= z is equivalent to x < y and y <= z, 

except that y is evaluated only once. (but in both cases z is not
evaluated at all when x \< y is found to be false).

Formally, if a, b, c, ..., y, z are expressions and op1, op2, ..., opN
are comparison operators, then an op1 b op2 c ... y opN z is equivalent
to a op1 b and b op2 c and ... y opN z, except that each expression is
evaluated at most once.

Also,

    a op1 b op2 c 

It doesn't imply any kind of comparison between a and c, so

     a < b > c

is perfectly legal.

Python
------

\# Python code to illustrate\# chaining comparison operatorsx = 5print(1
\< x \< 10)print(10 \< x \< 20 )print(x \< 10 \< x\*10 \< 100)print(10
\> x \<= 9)print(5 == x \> 4)

    True
    False
    True
    True
    True

Another Example:

Python
------

\# Python code to illustrate\# chaining comparison operatorsa, b, c, d,
e, f = 0, 5, 12, 0, 15, 15exp1 = a \<= b \< c \> d is not e is fexp2 = a
is d \> f is not cprint(exp1)print(exp2)

    True
    False

Explanation:
------------

In Python, chaining comparison operators is a way to simplify multiple
comparison operations by stringing them together using logical
operators. This is also known as "chained comparisons" or "chained
comparison operators".

In a chained comparison, two or more comparison operators are combined
with logical operators such as and or or. This allows you to compare
multiple values or variables with a single expression.

Here's an example of chaining comparison operators:
---------------------------------------------------

Python3
-------

x = 5y = 10z = 15 if x \< y \< z:    print(\"y is greater than x and
less than z\")

    y is greater than x and less than z

In this example, we are using the less than (\<) operator to compare x
and y, and then again to compare y and z. The logical operator and is
used to combine the two comparisons. The result is that the entire
expression evaluates to True only if x is less than y and y is less than
z. If this condition is met, the code inside the if statement will
execute.

Chaining comparison operators can make your code more concise and
readable, as it allows you to combine multiple comparisons into a single
expression. However, it's important to use parentheses to clarify the
order of operations, as the logical operators and and or have different
precedences. If parentheses are not used correctly, the expression may
not evaluate as intended. 

For example:
------------

Python3
-------

x=5y=10z=15 if x \< y or y \< z and z \< x:    print(\"This will not be
printed as expected!\")

    This will not be printed as expected!

In this case, the and operator has a higher precedence than the or
operator. Without parentheses, the expression will be evaluated as x \<
y or (y \< z and z \< x), which is not what was intended. To fix this,
we can use parentheses to clarify the order of operations:

Python3
-------

x=5y=10z=15  if (x \< y or y \< z) and z \< x:    print(\"This will be
printed as expected\")

     

Now, the expression will be evaluated as (x \< y or y \< z) and z \< x,
which correctly reflects the intended logic.

Why we use Chaining comparison operators in Python:
---------------------------------------------------

Chaining comparison operators in Python can make code more concise and
readable, as it allows you to combine multiple comparisons into a single
expression. It can also help to improve code performance by reducing the
number of separate comparisons that need to be performed.

Chained comparison operators are particularly useful when working with
numeric data or when comparing values that have a natural order, such as
dates or times. For example, when comparing two values a and b, you
might want to check whether a is less than b and b is less than c. Using
chained comparisons, you can express this as a \< b \< c instead of a \<
b and b \< c.

Chained comparison operators can also be useful when working with
boolean expressions. For example, you might want to check whether two
conditions are both true. Using chained comparisons, you can express
this as condition1 and condition2.

Overall, chaining comparison operators can make code more concise,
easier to read, and more efficient. However, it's important to use
parentheses to clarify the order of operations, as the logical operators
and and or have different precedences. If parentheses are not used
correctly, the expression may not evaluate as intended.
