---
title: "Python Tutorial
"
draft: false
menu:
sidebar:
name: "Python Tutorial
"
parent: "Python"
weight: 0
---

Python Tutorial
===============

This Python Tutorial is very well suited for Beginners, and also for
experienced programmers with other programming languages like C++ and
Java. This specially designed Python tutorial will help you learn Python
Programming Language in the most efficient way, with topics from basics
to advanced (like Web-scraping, Django, Deep-Learning, etc.) with
examples.

![Python
Tutorial](https://media.geeksforgeeks.org/wp-content/cdn-uploads/20230305181456/Python4.png){.alignnone
.size-full .wp-image-973034 width="1000" height="470"
sizes="(max-width: 1000px) 100vw, 1000px"
srcset="https://media.geeksforgeeks.org/wp-content/cdn-uploads/20230305181456/Python4.png 1000w, https://media.geeksforgeeks.org/wp-content/cdn-uploads/20230305181456/Python4-300x141.png 300w, https://media.geeksforgeeks.org/wp-content/cdn-uploads/20230305181456/Python4-768x361.png 768w, https://media.geeksforgeeks.org/wp-content/cdn-uploads/20230305181456/Python4-660x310.png 660w"}

What is Python?
---------------

Python is a high-level, general-purpose, and very popular programming
language. Python programming language (latest Python 3) is being used in
web development, Machine Learning applications, along with all
cutting-edge technology in Software Industry.

Python language is being used by almost all tech-giant companies like --
Google, Amazon, Facebook, Instagram, Dropbox, Uber... etc.

The biggest strength of Python is huge collection of standard library
which can be used for the following:

Machine Learning

GUI Applications (like Kivy, Tkinter, PyQt etc. )

Web frameworks like Django (used by YouTube, Instagram, Dropbox)

Image processing (like OpenCV, Pillow)

Web scraping (like Scrapy, BeautifulSoup, Selenium)

Test frameworks

Multimedia

Scientific computing

Text processing and many more..

Why Learn Python?
-----------------

Python is currently the most widely used multi-purpose, high-level
programming language, which allows programming in Object-Oriented and
Procedural paradigms. Python programs generally are smaller than other
programming languages like Java. Programmers have to type relatively
less and the indentation requirement of the language, makes them
readable all the time.

Basics, Input/Output, Data Types, Variables, Operators, Control Flow,
Functions, Object Oriented Concepts, Exception Handling, Python
Collections, Django Framework, Data Analysis, Numpy, Pandas, Machine
Learning with Python, Python GUI, Modules in Python, Working with
Database, Misc, Applications and Projects, Multiple Choice Questions

Getting Started with Python Tutorial
------------------------------------

Here are the important topics that come under Python. After completing
all the important topics, you'll have a basic understanding of the
Python programming language:-

Python Basics
-------------

Python language introductionPython 3 basicsPython The new generation
languageImportant difference between python 2.x and python 3.x with
exampleKeywords in Python \| Set 1, Set 2Namespaces and Scope in
PythonStatement, Indentation and Comment in PythonStructuring Python
ProgramsHow to check if a string is a valid keyword in Python?How to
assign values to variables in Python and other languagesHow to print
without newline in Python?Decision makingBasic calculator program using
PythonPython Language advantages and applications

Python 3 basicsPython The new generation languageImportant difference
between python 2.x and python 3.x with exampleKeywords in Python \| Set
1, Set 2Namespaces and Scope in PythonStatement, Indentation and Comment
in PythonStructuring Python ProgramsHow to check if a string is a valid
keyword in Python?How to assign values to variables in Python and other
languagesHow to print without newline in Python?Decision makingBasic
calculator program using PythonPython Language advantages and
applications

Python The new generation languageImportant difference between python
2.x and python 3.x with exampleKeywords in Python \| Set 1, Set
2Namespaces and Scope in PythonStatement, Indentation and Comment in
PythonStructuring Python ProgramsHow to check if a string is a valid
keyword in Python?How to assign values to variables in Python and other
languagesHow to print without newline in Python?Decision makingBasic
calculator program using PythonPython Language advantages and
applications

Important difference between python 2.x and python 3.x with
exampleKeywords in Python \| Set 1, Set 2Namespaces and Scope in
PythonStatement, Indentation and Comment in PythonStructuring Python
ProgramsHow to check if a string is a valid keyword in Python?How to
assign values to variables in Python and other languagesHow to print
without newline in Python?Decision makingBasic calculator program using
PythonPython Language advantages and applications

Keywords in Python \| Set 1, Set 2Namespaces and Scope in
PythonStatement, Indentation and Comment in PythonStructuring Python
ProgramsHow to check if a string is a valid keyword in Python?How to
assign values to variables in Python and other languagesHow to print
without newline in Python?Decision makingBasic calculator program using
PythonPython Language advantages and applications

Namespaces and Scope in Python

Statement, Indentation and Comment in Python

Structuring Python Programs

How to check if a string is a valid keyword in Python?How to assign
values to variables in Python and other languagesHow to print without
newline in Python?Decision makingBasic calculator program using
PythonPython Language advantages and applications

How to assign values to variables in Python and other languages

How to print without newline in Python?Decision makingBasic calculator
program using PythonPython Language advantages and applications

Decision makingBasic calculator program using PythonPython Language
advantages and applications

Basic calculator program using PythonPython Language advantages and
applications

Python Language advantages and applications

Input/Output
------------

Taking input in Python

Taking input from console in Python

Taking multiple inputs from user in Python

Python Input Methods for Competitive Programming

Vulnerability in input() function -- Python 2.x

Python \| Output using print() function

How to print without newline in Python?

Python \| end parameter in print()

Python \| sep parameter in print()

Python \| Output Formatting

Data Types
----------

Introduction to DataTypesStringsListTuplesSetsDictionaryArrays

Strings

List

Tuples

Sets

Dictionary

Arrays

Variables
---------

Variables, expression, condition and functionMaximum possible value of
an integer in python?Global and local variables in pythonPacking and
unpacking arguments in pythonType conversion in pythonByte objects vs
string in pythonPrint single and multiple variableSwap variablePrivate
variables\_\_name\_\_ (A Special variable) in Python

Maximum possible value of an integer in python?Global and local
variables in pythonPacking and unpacking arguments in pythonType
conversion in pythonByte objects vs string in pythonPrint single and
multiple variableSwap variablePrivate variables\_\_name\_\_ (A Special
variable) in Python

Global and local variables in pythonPacking and unpacking arguments in
pythonType conversion in pythonByte objects vs string in pythonPrint
single and multiple variableSwap variablePrivate variables\_\_name\_\_
(A Special variable) in Python

Packing and unpacking arguments in pythonType conversion in pythonByte
objects vs string in pythonPrint single and multiple variableSwap
variablePrivate variables\_\_name\_\_ (A Special variable) in Python

Type conversion in pythonByte objects vs string in pythonPrint single
and multiple variableSwap variablePrivate variables\_\_name\_\_ (A
Special variable) in Python

Byte objects vs string in pythonPrint single and multiple variableSwap
variablePrivate variables\_\_name\_\_ (A Special variable) in Python

Print single and multiple variableSwap variablePrivate
variables\_\_name\_\_ (A Special variable) in Python

Swap variablePrivate variables\_\_name\_\_ (A Special variable) in
Python

Private variables\_\_name\_\_ (A Special variable) in Python

\_\_name\_\_ (A Special variable) in Python

Operators
---------

Basic operator in pythonLogical and bitwise not operator on
booleanTernary operatorDivision operator in pythonOperator Overloading
in PythonAny & all in pythonInplace and standard operators in
pythonOperator function in python \| Set -- 1Inplace operator \| Set
-1Logic Gates in PythonPython \| a += b is not always a = a +
bDifference between == and is operator in PythonPython Membership and
Identity Operators \| in, not in, is, is not

Logical and bitwise not operator on booleanTernary operatorDivision
operator in pythonOperator Overloading in PythonAny & all in
pythonInplace and standard operators in pythonOperator function in
python \| Set -- 1Inplace operator \| Set -1Logic Gates in PythonPython
\| a += b is not always a = a + bDifference between == and is operator
in PythonPython Membership and Identity Operators \| in, not in, is, is
not

Ternary operatorDivision operator in pythonOperator Overloading in
PythonAny & all in pythonInplace and standard operators in
pythonOperator function in python \| Set -- 1Inplace operator \| Set
-1Logic Gates in PythonPython \| a += b is not always a = a +
bDifference between == and is operator in PythonPython Membership and
Identity Operators \| in, not in, is, is not

Division operator in pythonOperator Overloading in PythonAny & all in
pythonInplace and standard operators in pythonOperator function in
python \| Set -- 1Inplace operator \| Set -1Logic Gates in PythonPython
\| a += b is not always a = a + bDifference between == and is operator
in PythonPython Membership and Identity Operators \| in, not in, is, is
not

Operator Overloading in Python

Any & all in pythonInplace and standard operators in pythonOperator
function in python \| Set -- 1Inplace operator \| Set -1Logic Gates in
PythonPython \| a += b is not always a = a + bDifference between == and
is operator in PythonPython Membership and Identity Operators \| in, not
in, is, is not

Inplace and standard operators in pythonOperator function in python \|
Set -- 1Inplace operator \| Set -1Logic Gates in PythonPython \| a += b
is not always a = a + bDifference between == and is operator in
PythonPython Membership and Identity Operators \| in, not in, is, is not

Operator function in python \| Set -- 1Inplace operator \| Set -1Logic
Gates in PythonPython \| a += b is not always a = a + bDifference
between == and is operator in PythonPython Membership and Identity
Operators \| in, not in, is, is not

Inplace operator \| Set -1Logic Gates in PythonPython \| a += b is not
always a = a + bDifference between == and is operator in PythonPython
Membership and Identity Operators \| in, not in, is, is not

Logic Gates in Python

Python \| a += b is not always a = a + bDifference between == and is
operator in PythonPython Membership and Identity Operators \| in, not
in, is, is not

Difference between == and is operator in PythonPython Membership and
Identity Operators \| in, not in, is, is not

Python Membership and Identity Operators \| in, not in, is, is not

Control Flow
------------

LoopsLoops and Control Statements (continue, break and pass) in
PythonLooping technique in pythonrange vs xrange on pythonPrograms for
printing pyramid technique in pythonChaining comparison in pythonelse
with forswitch functionUsing iteration in python effectivelyPython
ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \| Converting an
object into an iteratorPython \| Difference between iterable and
iteratorGenerators in pythonGenerators expression in python

Loops and Control Statements (continue, break and pass) in PythonLooping
technique in pythonrange vs xrange on pythonPrograms for printing
pyramid technique in pythonChaining comparison in pythonelse with
forswitch functionUsing iteration in python effectivelyPython
ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \| Converting an
object into an iteratorPython \| Difference between iterable and
iteratorGenerators in pythonGenerators expression in python

Looping technique in pythonrange vs xrange on pythonPrograms for
printing pyramid technique in pythonChaining comparison in pythonelse
with forswitch functionUsing iteration in python effectivelyPython
ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \| Converting an
object into an iteratorPython \| Difference between iterable and
iteratorGenerators in pythonGenerators expression in python

range vs xrange on pythonPrograms for printing pyramid technique in
pythonChaining comparison in pythonelse with forswitch functionUsing
iteration in python effectivelyPython ItertoolsPython \_\_iter\_\_() and
\_\_next\_\_() \| Converting an object into an iteratorPython \|
Difference between iterable and iteratorGenerators in pythonGenerators
expression in python

Programs for printing pyramid technique in pythonChaining comparison in
pythonelse with forswitch functionUsing iteration in python
effectivelyPython ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \|
Converting an object into an iteratorPython \| Difference between
iterable and iteratorGenerators in pythonGenerators expression in python

Chaining comparison in pythonelse with forswitch functionUsing iteration
in python effectivelyPython ItertoolsPython \_\_iter\_\_() and
\_\_next\_\_() \| Converting an object into an iteratorPython \|
Difference between iterable and iteratorGenerators in pythonGenerators
expression in python

else with forswitch functionUsing iteration in python effectivelyPython
ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \| Converting an
object into an iteratorPython \| Difference between iterable and
iteratorGenerators in pythonGenerators expression in python

switch functionUsing iteration in python effectivelyPython
ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \| Converting an
object into an iteratorPython \| Difference between iterable and
iteratorGenerators in pythonGenerators expression in python

Using iteration in python effectivelyPython ItertoolsPython
\_\_iter\_\_() and \_\_next\_\_() \| Converting an object into an
iteratorPython \| Difference between iterable and iteratorGenerators in
pythonGenerators expression in python

Python ItertoolsPython \_\_iter\_\_() and \_\_next\_\_() \| Converting
an object into an iteratorPython \| Difference between iterable and
iteratorGenerators in pythonGenerators expression in python

Python \_\_iter\_\_() and \_\_next\_\_() \| Converting an object into an
iteratorPython \| Difference between iterable and iteratorGenerators in
pythonGenerators expression in python

Python \| Difference between iterable and iteratorGenerators in
pythonGenerators expression in python

Generators in pythonGenerators expression in python

Generators expression in python

Functions
---------

Functions in Python

class method vs static method in Python

Write an empty function in Python -- pass statement

Yield instead of Return

Return Multiple Values

Partial Functions in Python

First Class functions in Python

Precision Handling

\*args and \*\*kwargs

Python closures

Function Decorators

Decorators in Python

Decorators with parameters in Python

Memoization using decorators in Python

Help function in Python

Python \| \_\_import\_\_() function

Python \| range() does not return an iterator

Coroutine in Python

Python bit functions on int (bit\_length, to\_bytes and from\_bytes)

Object Oriented Concepts
------------------------

Python3 Intermediate Level Topics

Class, Object and MembersData Hiding and Object PrintingInheritance,
examples of object, issubclass and superPolymorphism in PythonClass and
static variable in pythonClass method and static method in
pythonChanging class membersConstructors in PythonDestructors in
PythonFirst class functionMetaprogramming with metaclassesClass and
instance attributeReflectionGarbage collection

Data Hiding and Object PrintingInheritance, examples of object,
issubclass and superPolymorphism in PythonClass and static variable in
pythonClass method and static method in pythonChanging class
membersConstructors in PythonDestructors in PythonFirst class
functionMetaprogramming with metaclassesClass and instance
attributeReflectionGarbage collection

Inheritance, examples of object, issubclass and superPolymorphism in
PythonClass and static variable in pythonClass method and static method
in pythonChanging class membersConstructors in PythonDestructors in
PythonFirst class functionMetaprogramming with metaclassesClass and
instance attributeReflectionGarbage collection

Polymorphism in Python

Class and static variable in pythonClass method and static method in
pythonChanging class membersConstructors in PythonDestructors in
PythonFirst class functionMetaprogramming with metaclassesClass and
instance attributeReflectionGarbage collection

Class method and static method in pythonChanging class
membersConstructors in PythonDestructors in PythonFirst class
functionMetaprogramming with metaclassesClass and instance
attributeReflectionGarbage collection

Changing class membersConstructors in PythonDestructors in PythonFirst
class functionMetaprogramming with metaclassesClass and instance
attributeReflectionGarbage collection

Constructors in Python

Destructors in Python

First class functionMetaprogramming with metaclassesClass and instance
attributeReflectionGarbage collection

Metaprogramming with metaclassesClass and instance
attributeReflectionGarbage collection

Class and instance attributeReflectionGarbage collection

ReflectionGarbage collection

Garbage collection

Exception Handling
------------------

Exception handlingUser defined ExceptionBuilt-in Exceptionclean up
actionNzec errortry and except in Python

User defined ExceptionBuilt-in Exceptionclean up actionNzec errortry and
except in Python

Built-in Exceptionclean up actionNzec errortry and except in Python

clean up actionNzec errortry and except in Python

Nzec errortry and except in Python

try and except in Python

Python Collections
------------------

Counters

OrderedDict

Defaultdict

ChainMap

NamedTuple

DeQue

Heap

Collections.UserDict

Collections.UserList

Collections.UserString

Django Framework
----------------

Django Tutorial

Django Basics

Django Introduction and Installation

Django Forms

Views In Django

Django Models

Django Templates

ToDo webapp using Django

Django News App

Weather app using Django

Data Analysis
-------------

Data visualization using Bokeh

Exploratory Data Analysis in Python

Data visualization with different Charts in Python

Data analysis and Visualization with Python

Data Analysis & Visualization with Python \| Set 2

Math operations for Data analysis

Getting started with Jupyter Notebook \| Python

Numpy
-----

Python Numpy

Numpy \| ndarray

Numpy \| Array Creation

Numpy \| Data Type Objects

Data type Object (dtype) in NumPy

Numpy \| Indexing

Numpy \| Basic Slicing and Advanced Indexing

Numpy \| Iterating Over Array

Numpy \| Binary Operations

Numpy \| Linear Algebra

Numpy \| Sorting, Searching and Counting

Pandas
------

Pandas Tutorial

Python \| Pandas DataFrame

Creating a Pandas DataFrame

Dealing with Rows and Columns in Pandas DataFrame

Indexing and Selecting Data with Pandas

Boolean Indexing in Pandas

Conversion Functions in Pandas DataFrame

Iterating over rows and columns in Pandas DataFrame

Working with Missing Data in Pandas

Python \| Pandas Series

Data analysis using Pandas

Read csv using pandas.read\_csv()

Machine Learning with Python
----------------------------

Machine Learning Tutorial

Linear Regression

Understanding Logistic Regression

K means Clustering

Python \| Image Classification using keras

creating a simple machine learning modelPython \| Implementation of
Movie Recommender SystemML \| Boston Housing Kaggle Challenge with
Linear RegressionCancer cell classification using Scikit-learnSaving a
machine learning ModelApplying Convolutional Neural Network on mnist
datasetPython \| NLP analysis of Restaurant reviewsLearning Model
Building in Scikit-learnImplementing Artificial Neural Network training
processA single neuron neural network in PythonPython \| How and where
to apply Feature Scaling?Identifying handwritten digits using Logistic
Regression in PyTorch

Python \| Implementation of Movie Recommender System

ML \| Boston Housing Kaggle Challenge with Linear Regression

Cancer cell classification using Scikit-learn

Saving a machine learning Model

Applying Convolutional Neural Network on mnist dataset

Python \| NLP analysis of Restaurant reviews

Learning Model Building in Scikit-learn

Implementing Artificial Neural Network training process

A single neuron neural network in PythonPython \| How and where to apply
Feature Scaling?Identifying handwritten digits using Logistic Regression
in PyTorch

Python \| How and where to apply Feature Scaling?Identifying handwritten
digits using Logistic Regression in PyTorch

Identifying handwritten digits using Logistic Regression in PyTorch

Python GUI
----------

Tkinter Tutorial

Kivy Tutorial

Python GUI -- tkinterSimple GUI calculator using TkinterSimple
registration form using TkinterCreate a stopwatch using pythonDesigning
GUI applications Using PyQtColor game using Tkinter in PythonMake
Notepad using TkinterMessage Encode-Decode using TkinterReal time
currency convertor using Tkinter

Simple GUI calculator using TkinterSimple registration form using
TkinterCreate a stopwatch using pythonDesigning GUI applications Using
PyQtColor game using Tkinter in PythonMake Notepad using TkinterMessage
Encode-Decode using TkinterReal time currency convertor using Tkinter

Simple registration form using TkinterCreate a stopwatch using
pythonDesigning GUI applications Using PyQtColor game using Tkinter in
PythonMake Notepad using TkinterMessage Encode-Decode using TkinterReal
time currency convertor using Tkinter

Create a stopwatch using pythonDesigning GUI applications Using
PyQtColor game using Tkinter in PythonMake Notepad using TkinterMessage
Encode-Decode using TkinterReal time currency convertor using Tkinter

Designing GUI applications Using PyQtColor game using Tkinter in
PythonMake Notepad using TkinterMessage Encode-Decode using TkinterReal
time currency convertor using Tkinter

Color game using Tkinter in PythonMake Notepad using TkinterMessage
Encode-Decode using TkinterReal time currency convertor using Tkinter

Make Notepad using TkinterMessage Encode-Decode using TkinterReal time
currency convertor using Tkinter

Message Encode-Decode using Tkinter

Real time currency convertor using Tkinter

Modules in Python
-----------------

Introduction of Modules

OS module

Calendar Module

Python Urllib Module

pprint

Timit function

Import module

Working With Database
---------------------

MongoDB and Python

SQL using Python \| Set 1

SQL using Python and SQLite \| Set 2

SQL using Python \| Set 3 (Handling large data)

Inserting variables to database table using Python

MYSQLdb Connection in Python

Database management in PostgreSQL

Oracle Database Connection in Python

Misc
----

10 Essential Python Tips And Tricks For ProgrammersAmazing hacks of
PythonInput method for comptetive programmingOptimization Tips for
Python CodeWhy import star in Python is a bad ideaWhy is python best
suited for Competitive Coding?Python trics for Competitive Coding

Amazing hacks of Python

Input method for comptetive programmingOptimization Tips for Python
CodeWhy import star in Python is a bad ideaWhy is python best suited for
Competitive Coding?Python trics for Competitive Coding

Optimization Tips for Python Code

Why import star in Python is a bad idea

Why is python best suited for Competitive Coding?Python trics for
Competitive Coding

Python trics for Competitive Coding

Applications and Projects
-------------------------

Python \| Program to crawl a web page and get most frequent
wordsFacebook login using pythonFB Chatting through pythonC/C++ code
formating toolFind Live running status and PNR of any train using
Railway APIFetching top news using News APIFetching text from
Wikipedia's Infobox in PythonGet emotions of images using Microsoft
emotion API in PythonWebsite blockerSend SMS updates to mobile phone
using pythonPython Desktop News Notifier in 20 linesMorse Code
Translator In PythonPerforming Google Search using Python codeReading
and generating qr codeBirthday reminder application in pythonProgram to
display Astrological sign or Zodiac sign for given date of birthTrack
bird migrationNews notifierwhatsapp using pythonPython \| Automating
Happy Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Facebook login using pythonFB Chatting through pythonC/C++ code
formating toolFind Live running status and PNR of any train using
Railway APIFetching top news using News APIFetching text from
Wikipedia's Infobox in PythonGet emotions of images using Microsoft
emotion API in PythonWebsite blockerSend SMS updates to mobile phone
using pythonPython Desktop News Notifier in 20 linesMorse Code
Translator In PythonPerforming Google Search using Python codeReading
and generating qr codeBirthday reminder application in pythonProgram to
display Astrological sign or Zodiac sign for given date of birthTrack
bird migrationNews notifierwhatsapp using pythonPython \| Automating
Happy Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

FB Chatting through pythonC/C++ code formating toolFind Live running
status and PNR of any train using Railway APIFetching top news using
News APIFetching text from Wikipedia's Infobox in PythonGet emotions of
images using Microsoft emotion API in PythonWebsite blockerSend SMS
updates to mobile phone using pythonPython Desktop News Notifier in 20
linesMorse Code Translator In PythonPerforming Google Search using
Python codeReading and generating qr codeBirthday reminder application
in pythonProgram to display Astrological sign or Zodiac sign for given
date of birthTrack bird migrationNews notifierwhatsapp using
pythonPython \| Automating Happy Birthday post on Facebook using
SeleniumDesign a Keylogger in PythonPython \| Implementation of Movie
Recommender System

C/C++ code formating toolFind Live running status and PNR of any train
using Railway APIFetching top news using News APIFetching text from
Wikipedia's Infobox in PythonGet emotions of images using Microsoft
emotion API in PythonWebsite blockerSend SMS updates to mobile phone
using pythonPython Desktop News Notifier in 20 linesMorse Code
Translator In PythonPerforming Google Search using Python codeReading
and generating qr codeBirthday reminder application in pythonProgram to
display Astrological sign or Zodiac sign for given date of birthTrack
bird migrationNews notifierwhatsapp using pythonPython \| Automating
Happy Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Find Live running status and PNR of any train using Railway APIFetching
top news using News APIFetching text from Wikipedia's Infobox in
PythonGet emotions of images using Microsoft emotion API in
PythonWebsite blockerSend SMS updates to mobile phone using pythonPython
Desktop News Notifier in 20 linesMorse Code Translator In
PythonPerforming Google Search using Python codeReading and generating
qr codeBirthday reminder application in pythonProgram to display
Astrological sign or Zodiac sign for given date of birthTrack bird
migrationNews notifierwhatsapp using pythonPython \| Automating Happy
Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Fetching top news using News APIFetching text from Wikipedia's Infobox
in PythonGet emotions of images using Microsoft emotion API in
PythonWebsite blockerSend SMS updates to mobile phone using pythonPython
Desktop News Notifier in 20 linesMorse Code Translator In
PythonPerforming Google Search using Python codeReading and generating
qr codeBirthday reminder application in pythonProgram to display
Astrological sign or Zodiac sign for given date of birthTrack bird
migrationNews notifierwhatsapp using pythonPython \| Automating Happy
Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Fetching text from Wikipedia's Infobox in PythonGet emotions of images
using Microsoft emotion API in PythonWebsite blockerSend SMS updates to
mobile phone using pythonPython Desktop News Notifier in 20 linesMorse
Code Translator In PythonPerforming Google Search using Python
codeReading and generating qr codeBirthday reminder application in
pythonProgram to display Astrological sign or Zodiac sign for given date
of birthTrack bird migrationNews notifierwhatsapp using pythonPython \|
Automating Happy Birthday post on Facebook using SeleniumDesign a
Keylogger in PythonPython \| Implementation of Movie Recommender System

Get emotions of images using Microsoft emotion API in PythonWebsite
blockerSend SMS updates to mobile phone using pythonPython Desktop News
Notifier in 20 linesMorse Code Translator In PythonPerforming Google
Search using Python codeReading and generating qr codeBirthday reminder
application in pythonProgram to display Astrological sign or Zodiac sign
for given date of birthTrack bird migrationNews notifierwhatsapp using
pythonPython \| Automating Happy Birthday post on Facebook using
SeleniumDesign a Keylogger in PythonPython \| Implementation of Movie
Recommender System

Website blockerSend SMS updates to mobile phone using pythonPython
Desktop News Notifier in 20 linesMorse Code Translator In
PythonPerforming Google Search using Python codeReading and generating
qr codeBirthday reminder application in pythonProgram to display
Astrological sign or Zodiac sign for given date of birthTrack bird
migrationNews notifierwhatsapp using pythonPython \| Automating Happy
Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Send SMS updates to mobile phone using pythonPython Desktop News
Notifier in 20 linesMorse Code Translator In PythonPerforming Google
Search using Python codeReading and generating qr codeBirthday reminder
application in pythonProgram to display Astrological sign or Zodiac sign
for given date of birthTrack bird migrationNews notifierwhatsapp using
pythonPython \| Automating Happy Birthday post on Facebook using
SeleniumDesign a Keylogger in PythonPython \| Implementation of Movie
Recommender System

Python Desktop News Notifier in 20 linesMorse Code Translator In
PythonPerforming Google Search using Python codeReading and generating
qr codeBirthday reminder application in pythonProgram to display
Astrological sign or Zodiac sign for given date of birthTrack bird
migrationNews notifierwhatsapp using pythonPython \| Automating Happy
Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Morse Code Translator In PythonPerforming Google Search using Python
codeReading and generating qr codeBirthday reminder application in
pythonProgram to display Astrological sign or Zodiac sign for given date
of birthTrack bird migrationNews notifierwhatsapp using pythonPython \|
Automating Happy Birthday post on Facebook using SeleniumDesign a
Keylogger in PythonPython \| Implementation of Movie Recommender System

Performing Google Search using Python codeReading and generating qr
codeBirthday reminder application in pythonProgram to display
Astrological sign or Zodiac sign for given date of birthTrack bird
migrationNews notifierwhatsapp using pythonPython \| Automating Happy
Birthday post on Facebook using SeleniumDesign a Keylogger in
PythonPython \| Implementation of Movie Recommender System

Reading and generating qr codeBirthday reminder application in
pythonProgram to display Astrological sign or Zodiac sign for given date
of birthTrack bird migrationNews notifierwhatsapp using pythonPython \|
Automating Happy Birthday post on Facebook using SeleniumDesign a
Keylogger in PythonPython \| Implementation of Movie Recommender System

Birthday reminder application in pythonProgram to display Astrological
sign or Zodiac sign for given date of birthTrack bird migrationNews
notifierwhatsapp using pythonPython \| Automating Happy Birthday post on
Facebook using SeleniumDesign a Keylogger in PythonPython \|
Implementation of Movie Recommender System

Program to display Astrological sign or Zodiac sign for given date of
birthTrack bird migrationNews notifierwhatsapp using pythonPython \|
Automating Happy Birthday post on Facebook using SeleniumDesign a
Keylogger in PythonPython \| Implementation of Movie Recommender System

Track bird migrationNews notifierwhatsapp using pythonPython \|
Automating Happy Birthday post on Facebook using SeleniumDesign a
Keylogger in PythonPython \| Implementation of Movie Recommender System

News notifierwhatsapp using pythonPython \| Automating Happy Birthday
post on Facebook using SeleniumDesign a Keylogger in PythonPython \|
Implementation of Movie Recommender System

whatsapp using pythonPython \| Automating Happy Birthday post on
Facebook using SeleniumDesign a Keylogger in PythonPython \|
Implementation of Movie Recommender System

Python \| Automating Happy Birthday post on Facebook using Selenium

Design a Keylogger in PythonPython \| Implementation of Movie
Recommender System

Python \| Implementation of Movie Recommender System

Recommended Python Tutorials
----------------------------

Python Tutorial

Machine Learning Tutorial

Django Tutorial

Pandas Tutorial

OpenCV Python Tutorial

Selenium Python Tutorial

Python Tkinter Tutorial

  

Also, check

Recent Articles on Python !

Python Programming Examples

Python Output & Multiple Choice Questions
