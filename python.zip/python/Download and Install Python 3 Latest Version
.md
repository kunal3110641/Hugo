---
title: "Download and Install Python 3 Latest Version
"
draft: false
menu:
sidebar:
name: "Download and Install Python 3 Latest Version
"
parent: "Python"
weight: 3
---

Download and Install Python 3 Latest Version
--------------------------------------------



Here we will be discussing how to get the answer to all questions
related to installing Python on Windows/Linux/mac OS. Python was
developed by Guido van Rossum in the early 1990's and its latest version
is 3.11.2, we can simply call it Python 3. To understand how to install
Python You need to know What Python is and where it is actually
installed in your system. Let's consider a few points:

Python is a widely-used general-purpose, high-level programming
language.

Every Release of Python is open-source. Python releases have also been
General Public License (GPL) -compatible.

Any version of Python can be downloaded from Python Software Foundation
website at python.org.

Most the languages, notably Linux provides a package manager through
which you can directly install Python on your Operating System

In this Python tutorial on Installation and Setup, you'll see how to
install Python on Windows, mac OS, Linux, iOS, and Android.

Python Latest Version Installation and Setup
--------------------------------------------

Here you can choose your OS and see the corresponding tutorial,

Windows

Linux

mac OS / Mac OS X

Android

iOS (iPhone / iPad)

Online Interpreters of Python

How to install Python on Windows?
---------------------------------

Since windows don't come with Python preinstalled, it needs to be
installed explicitly. Here we will define step by step tutorial on How
to install Python on Windows. Follow the steps below :

Download Python Latest Version from python.org
----------------------------------------------

Step 1: First and foremost step is to open a browser and type
https://www.python.org/downloads/windows/ 

Step 2: Underneath the Python Releases for Windows find the Latest
Python 3 Release -- Python 3.11.2 (the latest stable release as of now
is Python 3.11.2).

![](https://media.geeksforgeeks.org/wp-content/uploads/20230324092503/Screenshot-2023-03-24-092449.png)

Python installation

Step 3: On this page move to Files and click on Windows x86-64
executable installer for 64-bit or Windows x86 executable installer for
32-bit. 

![how-to-install-python-for-windows-steps](https://media.geeksforgeeks.org/wp-content/uploads/20190926114317/how-to-install-python-for-windows-steps.png)

Here we are providing the installation process of Python 3.11.2 on Windows
--------------------------------------------------------------------------

Run the Python Installer for how to install python on windows downloads
folder 

Make sure to mark Add Python 3.11 to PATH otherwise you will have to do
it explicitly. It will start installing python on windows. 

![](https://media.geeksforgeeks.org/wp-content/uploads/20230324093124/Screenshot-2023-03-24-093115.png)

Adding to path

After installation is complete click on Close. Bingo..!! Python is
installed. Now go to windows and type IDLE. 

![](https://media.geeksforgeeks.org/wp-content/uploads/20230324093328/Screenshot-2023-03-24-093317.png)

Python Shell

 

This is Python Interpreter also called Python Shell. I printed Hello
geeks, python is working smoothly.

The three greater than \>\>\> sign is called Python command prompt,
where we write our program and with a single enter key, it will give
result so instantly. 

How to install Python on Linux?
-------------------------------

On every Linux system including the following OS,

Ubuntu

Linux Mint

Debian

openSUSE

CentOS

Fedora

and my favorite one, Arch Linux.

You will find Python already installed. You can check it using the
following command from the terminal

    $ python --version

To check the latest version of python 2.x.x :

    $ python2 --version

To check the latest version of python 3.x.x :

    $ python3 --version

![](https://media.geeksforgeeks.org/wp-content/uploads/20230324093447/Screenshot-2023-03-24-093438.png)

Version check

 

Clearly, it won't be the latest version of python. There can be multiple
methods to install python on a Linux base system and it all depends on
your Linux system. For almost every Linux system, the following commands
would work definitely.

    $ sudo add-apt-repository ppa:deadsnakes/ppa
    $ sudo apt-get update
    $ sudo apt-get install python3.11.2

Download and install Python's Latest Version on Linux
-----------------------------------------------------

To install the latest version from the source code of Python follow the
below steps:

Download Python Latest Version from python.org

First and foremost step is to open a browser and open
https://www.python.org/downloads/source/ 

![](https://media.geeksforgeeks.org/wp-content/uploads/20230324093611/Screenshot-2023-03-24-093602.png)

Python Source Releases

Underneath the Stable Releases find Download Gzipped source tarball
(latest stable release as of now is Python 3.11.2).

Download and install Homebrew Package Manager
---------------------------------------------

If you don't have homebrew installed on your system, follow the steps
below Open the Terminal Application of macOS from Application -\>
Utilities. Bash terminal will open where you can enter commands Enter
following command in macOS terminal

    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

Enter the system password if prompted. This will install the Homebrew
package Manager on your OS. After you see a message called "Installation
Successful". You are ready to install python version 3 on your macOS.

![install-python-on-mac](https://media.geeksforgeeks.org/wp-content/uploads/20191001121855/install-python-on-mac.png)![install-python-on-mac-4-](https://media.geeksforgeeks.org/wp-content/uploads/20191001121845/install-python-on-mac-4-.png)

Install Python Latest Version on macOS / macOS X
------------------------------------------------

To install python simple open Terminal app from Application -\>
Utilities and enter following command

    brew install python3

After command processing is complete, Python's version 3 would be
installed on your mac. To verify the installation enter following
commands in your Terminal app

![install-python-on-mac-2](https://media.geeksforgeeks.org/wp-content/uploads/20191001121848/install-python-on-mac-2.png)

    python

    pip3

![install-python-on-mac-1-](https://media.geeksforgeeks.org/wp-content/uploads/20191001121851/install-python-on-mac-1-.png)

 Bingo..!! Python is installed on your computer. You can explore more
about Python here

Offline Python 3.11 interpreter: no Internet is required to run Python
programs.

Pip package manager and a custom repository for prebuilt wheel packages
for enhanced scientific libraries, such as numpy, scipy, matplotlib,
scikit-learn.

Tensorflow is now also available.

Examples available out-of-the-box for quicker learning.

Complete Tkinter support for GUI.

Full-featured Terminal Emulator, with a readline support (available in
pip).

To install Pydroid app go to play store link here -- Pydroid 3 -- IDE
for Python 3

![How-to-install-python-on-android1](https://media.geeksforgeeks.org/wp-content/uploads/20191001105624/Hw-to-install-python-on-android1.png)

After installation is complete, run the app and it will show as
installing python.

![Hw-to-install-python-on-android2](https://media.geeksforgeeks.org/wp-content/uploads/20191001105621/Hw-to-install-python-on-android2.png)

Wait for a minute and it will show the ide. Here you can enter the
Python code.

![](https://media.geeksforgeeks.org/wp-content/uploads/20191001105619/Hw-to-install-python-on-android3.png)

Click on the yellow button to run the code.  

![](https://media.geeksforgeeks.org/wp-content/uploads/20191001105625/How-to-install-python-on-android.png)

Python is installed successfully. You can check more features of this
app here.

GeeksforGeeks IDE -- ide.geeksforgeeks.org

Python Fiddle: pythonfiddle.com

Python Anywhere: www.pythonanywhere.com

Online gdp compiler -- onlinegdb.com

kaggle -- kaggle.com

JuPyter/IPython Notebook -- jupyter.org

Google Colab -- colab.research.google.com
