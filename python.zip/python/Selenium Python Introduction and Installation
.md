---
title: "Selenium Python Introduction and Installation
"
draft: false
menu:
sidebar:
name: "Selenium Python Introduction and Installation
"
parent: "Python"
weight: 137
---

Selenium Python Introduction and Installation
---------------------------------------------



Selenium's Python Module is built to perform automated testing with
Python. Selenium Python bindings provides a simple API to write
functional/acceptance tests using Selenium WebDriver. Through Selenium
Python API you can access all functionalities of Selenium WebDriver in
an intuitive way. To check more details about Selenium visit -- Selenium
Basics -- Components, Features, Uses and Limitations. 

Selenium Python Introduction
----------------------------

Selenium Python bindings provide a convenient API to access Selenium
WebDrivers like Firefox, Ie, Chrome, Remote etc. Selenium released it's
latest version 4.5.0. The current supported Python versions are 3.7 and
above. 

Open Source and Portable -- Selenium is an open source and portable Web
testing Framework.

Combination of tool and DSL -- Selenium is combination of tools and DSL
(Domain Specific Language) in order to carry out various types of tests.

Easier to understand and implement -- Selenium commands are categorized
in terms of different classes which make it easier to understand and
implement.

Reduce test execution time -- Selenium supports parallel test execution
that reduce the time taken in executing parallel tests.

Lesser resources required -- Selenium requires lesser resources when
compared to its competitors like UFT, RFT, etc.

Supports Multiple Operating Systems -- Android, iOS, Windows, Linux,
Mac, Solaris.

Supports Multiple Browsers -- Google Chrome, Mozilla Firefox, Internet
Explorer, Edge, Opera, Safari, etc.

Parallel Test Execution -- It also supports parallel test execution
which reduces time and increases the efficiency of tests.

Selenium Python Installation
----------------------------

For any operating system selenium can be installed after you have
installed python on your operating system. If not, checkout -- Download
and Install Python 3 Latest Version 

First MethodOpen Terminal/Cmd and Write Command as written Below 

    python -m pip install selenium

Second MethodAlternatively, you can download the source distribution
here, unarchive it, and run the command below:  

    python setup.py install

Installing Webdrivers
---------------------

One Can Install Firefox, Chromium, PhantomJs(Deprecated Now), etc.  

for using Firefox you may need to install GeckoDriver 

for using Chrome you may need to install Chromium 

In this article, Firefox is used so One can Follow the Below Steps to
Install:-

Steps for Linux:-1. Go to the geckodriver releases page. Find the latest
version of the driver for your platform and download it. For example:  

    wget https://github.com/mozilla/geckodriver/releases/download/v0.24.0/geckodriver-v0.24.0-linux64.tar.gz

2\. Extract the file with:  

    tar -xvzf geckodriver*

3\. Make it executable:  

    chmod +x geckodriver

4\. Move Files to usr/local/bin  

    sudo mv geckodriver /usr/local/bin/

Steps for Windows:-1. Same as Step 1 in Linux Download the GeckoDriver2.
Extract it using WinRar or any application you may have.3. Add it to
Path using Command Prompt

    setx path "%path%;GeckoDriver Path"

For Example:-  

    setx path "%path%;c:/user/eliote/Desktop/geckodriver-v0.26.0-win64/geckodriver.exe"

Creating Simple Code 
---------------------

Python3
-------

\# Python program to demonstrate\# selenium \# import webdriverfrom
selenium import webdriver \# create webdriver objectdriver =
webdriver.Firefox()\# get
google.co.indriver.get(\"https://google.co.in\")

Output:

![python-selenium](https://media.geeksforgeeks.org/wp-content/uploads/20191227170655/Screenshot-from-2019-12-26-13-28-471.png)

 
