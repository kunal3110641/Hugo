---
title: "Python MySQL -- Order By Clause
"
draft: false
menu:
sidebar:
name: "Python MySQL -- Order By Clause
"
parent: "Python"
weight: 118
---

Python MySQL -- Order By Clause
-------------------------------



A connector is employed when we have to use MySQL with other programming
languages. The work of MySQL-connector is to provide access to MySQL
Driver to the required language. Thus, it generates a connection between
the programming language and the MySQL Server.

OrderBy Clause
--------------

OrderBy is used to arrange the result set in either ascending or
descending order. By default, it is always in ascending order unless
"DESC" is mentioned, which arranges it in descending order."ASC" can
also be used to explicitly arrange it in ascending order. But, it is
generally not done this way since default already does that.

Syntax-

    SELECT column1, column2
    FROM table_name
    ORDER BY column_name ASC|DESC;

The following programs will help you understand this better.DATABASE IN
USE:

![python-order-by](https://media.geeksforgeeks.org/wp-content/uploads/20200306172253/python-order-by.png)

Example 1: Program to arrange the data in ascending order by name

\# Python program to demonstrate\# order by clause    import
mysql.connector  \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',  password = \'\')  cs = mydb.cursor()  \#
Order by clausestatement =\"SELECT \* FROM Student ORDER BY
Name\"cs.execute(statement)  result\_set = cs.fetchall()  for x in
result\_set:    print(x)      \# Disconnecting from the
databasemydb.close()

Output:

![python-mysql-order-by](https://media.geeksforgeeks.org/wp-content/uploads/20200306172634/python-mysql-order-by.png)

Example 2: Arranging the database in descending order

\# Python program to demonstrate\# order by clause    import
mysql.connector  \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor()  \# Order by
clausestatement =\"SELECT \* FROM Student ORDER BY Name
DESC\"cs.execute(statement)  result\_set = cs.fetchall()  for x in
result\_set:    print(x)    \# Disconnecting from the
database  mydb.close()

Output:

![python-mysql-order-by-2](https://media.geeksforgeeks.org/wp-content/uploads/20200306172847/python-mysql-order-by-2.png)

Example 3: Program to get namefrom the table, arranged in descending
order by Roll no.

\# Python program to demonstrate\# order by clause    import
mysql.connector  \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor()  \# Order by
clausestatement =\"SELECT Name FROM Student ORDER BY Roll\_no
DESC\"cs.execute(statement)  result\_set = cs.fetchall()  for x in
result\_set:    print(x)      \# Disconnecting from the
databasemydb.close()

Output:

![python-mysql-order-by-3](https://media.geeksforgeeks.org/wp-content/uploads/20200306173127/python-mysql-order-by-3.png)
