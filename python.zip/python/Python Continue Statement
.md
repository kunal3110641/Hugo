---
title: "Python Continue Statement
"
draft: false
menu:
sidebar:
name: "Python Continue Statement
"
parent: "Python"
weight: 38
---

Python Continue Statement
-------------------------



Python Continue Statement skips the execution of the program block from
after the continue statement and forces the control to start the next
iteration.

Python Continue Statement
-------------------------

Python Continue statement is a loop control statement that forces to
execute the next iteration of the loop while skipping the rest of the
code inside the loop for the current iteration only, i.e. when the
continue statement is executed in the loop, the code inside the loop
following the continue statement will be skipped for the current
iteration and the next iteration of the loop will begin.

Python continue Statement Syntax
--------------------------------

    while True:
        ...
        if x == 10:
            continue
        print(x)

Flowchart of Continue Statement
-------------------------------

![Python Continue
Statement](https://media.geeksforgeeks.org/wp-content/uploads/20191120200342/Continue-statement-python1.jpg)

flowchart of Python continue statement

Continue statement in Python Example
------------------------------------

Example 1: Demonstration of Continue statement in Python
--------------------------------------------------------

In this example, we will use continue inside some condition within a
loop.

Python3
-------

for var in \"Geeksforgeeks\":    if var ==
\"e\":        continue    print(var)

Output:

    G
    k
    s
    f
    o
    r
    g
    k
    s

Time complexity: O(n).Auxiliary space: O(1).

Explanation: Here we are skipping the print of character 'e' using
if-condition checking and continue statement.

Example 2: Printing range with Python Continue Statement
--------------------------------------------------------

Consider the situation when you need to write a program which prints the
number from 1 to 10, but not 6. 

It is specified that you have to do this using loop and only one loop is
allowed to use. Here comes the usage of the continue statement. What we
can do here is we can run a loop from 1 to 10 and every time we have to
compare the value of the loop variable with 6. If it is equal to 6 we
will use the continue statement to continue to the next iteration
without printing anything, otherwise we will print the value.

Python3
-------

\# loop from 1 to 10for i in range(1, 11):     \# If i is equals to
6,    \# continue to next iteration    \# without printing    if i ==
6:        continue    else:        \# otherwise print the
value        \# of i        print(i, end=\" \")

Output: 

    1 2 3 4 5 7 8 9 10 

Note: The continue statement can be used with any other loop also like
while loop, similarly as it is used with for loop above.

Usage of Continue Statement
---------------------------

Loops in Python automate and repeat the tasks efficiently. But
sometimes, there may arise a condition where you want to exit the loop
completely, skip an iteration or ignore that condition. These can be
done by loop control statements. Continue is a type of loop control
statement that can alter the flow of the loop. 

To read more on pass and break, refer to these articles:

Python pass statement

Python break statement
