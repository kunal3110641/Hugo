---
title: "Deserialize JSON to Object in Python
"
draft: false
menu:
sidebar:
name: "Deserialize JSON to Object in Python
"
parent: "Python"
weight: 107
---

Deserialize JSON to Object in Python
------------------------------------



Let us see how to deserialize a JSON document into a Python object.
Deserialization is the process of decoding the data that is in JSON
format into native data type. In Python, deserialization decodes JSON
data into a dictionary(data type in python).We will be using these
methods of the json module to perform this task :  

loads() : to deserialize a JSON document to a Python object.

load() : to deserialize a JSON formatted stream ( which supports reading
from a file) to a Python object.

Example 1 : Using the loads() function.  

Python3
-------

\# importing the moduleimport json \# creating the JSON data as a
stringdata = \'{\"Name\" : \"Romy\", \"Gender\" :
\"Female\"}\' print(\"Datatype before deserialization : \"      +
str(type(data)))  \# deserializing the datadata =
json.loads(data) print(\"Datatype after deserialization : \"      +
str(type(data)))

Output :  

    Datatype before deserialization : 
    Datatype after deserialization : 

Example 2 : Using the load() function. We have to deserialize a file
named file.json.  

![](https://media.geeksforgeeks.org/wp-content/uploads/20200721141328/json_file.png)

 

Python3
-------

\# importing the moduleimport json \# opening the JSON filedata =
open(\'file.json\',) print(\"Datatype before deserialization : \"      +
str(type(data)))    \# deserializing the datadata =
json.load(data) print(\"Datatype after deserialization : \"      +
str(type(data)))

Output :  

    Datatype before deserialization : 
    Datatype after deserialization : 

 
