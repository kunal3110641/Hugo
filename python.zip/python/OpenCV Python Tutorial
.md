---
title: "OpenCV Python Tutorial
"
draft: false
menu:
sidebar:
name: "OpenCV Python Tutorial
"
parent: "Python"
weight: 131
---

OpenCV Python Tutorial
----------------------



OpenCV is a huge open-source library for computer vision, machine
learning, and image processing. OpenCV supports a wide variety of
programming languages like Python, C++, Java, etc. It can process images
and videos to identify objects, faces, or even the handwriting of a
human. When it is integrated with various libraries, such as Numpy which
is a highly optimized library for numerical operations, then the number
of weapons increases in your Arsenal i.e whatever operations one can do
in Numpy can be combined with OpenCV.

This OpenCV tutorial will help you learn the Image-processing from
Basics to Advance, like operations on Images, Videos using a huge set of
Opencv-programs and projects.

Table Of Content:

Getting StartedWorking with ImagesGetting StartedImage ProcessingFeature
Detection and DescriptionDrawing FunctionsWorking with VideosGetting
StartedVideo ProcessingApplications and Projects

Working with ImagesGetting StartedImage ProcessingFeature Detection and
DescriptionDrawing FunctionsWorking with VideosGetting StartedVideo
ProcessingApplications and Projects

Getting StartedImage ProcessingFeature Detection and DescriptionDrawing
Functions

Image ProcessingFeature Detection and DescriptionDrawing Functions

Feature Detection and DescriptionDrawing Functions

Drawing Functions

Working with VideosGetting StartedVideo ProcessingApplications and
Projects

Getting StartedVideo Processing

Video Processing

Applications and Projects

Recent Articles on OpenCV !!

 

OpenCV -- OverviewIntroduction to OpenCVInstall OpenCV for Python on
WindowsInstall OpenCV for Python on LinuxSet up Opencv with anaconda
environment

Introduction to OpenCVInstall OpenCV for Python on WindowsInstall OpenCV
for Python on LinuxSet up Opencv with anaconda environment

Install OpenCV for Python on WindowsInstall OpenCV for Python on
LinuxSet up Opencv with anaconda environment

Install OpenCV for Python on LinuxSet up Opencv with anaconda
environment

Set up Opencv with anaconda environment

Working with Images
-------------------

Getting Started

Reading an image in OpenCV using PythonDisplay an image in OpenCV using
PythonWriting an image in OpenCV using PythonOpenCV \| Saving an
ImageColor SpacesArithmetic operations on ImagesBitwise Operations on
Binary Images

Display an image in OpenCV using PythonWriting an image in OpenCV using
PythonOpenCV \| Saving an ImageColor SpacesArithmetic operations on
ImagesBitwise Operations on Binary Images

Writing an image in OpenCV using PythonOpenCV \| Saving an ImageColor
SpacesArithmetic operations on ImagesBitwise Operations on Binary Images

OpenCV \| Saving an ImageColor SpacesArithmetic operations on
ImagesBitwise Operations on Binary Images

Color SpacesArithmetic operations on ImagesBitwise Operations on Binary
Images

Arithmetic operations on ImagesBitwise Operations on Binary Images

Bitwise Operations on Binary Images

Image Processing

Image ResizingEroding an ImageBlurring an ImageCreate Border around
ImagesGrayscaling of ImagesScaling, Rotating, Shifting and Edge
DetectionErosion and Dilation of imagesAnalyze an image using
HistogramHistograms EqualizationSimple ThresholdingAdaptive
ThresholdingOtsu ThresholdingSegmentation using ThresholdingConvert an
image from one color space to anotherFilter Color with OpenCVDenoising
of colored imagesVisualizing image in different color spacesFind
Co-ordinates of ContoursBilateral FilteringImage Inpainting using
OpenCVIntensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Eroding an ImageBlurring an ImageCreate Border around ImagesGrayscaling
of ImagesScaling, Rotating, Shifting and Edge DetectionErosion and
Dilation of imagesAnalyze an image using HistogramHistograms
EqualizationSimple ThresholdingAdaptive ThresholdingOtsu
ThresholdingSegmentation using ThresholdingConvert an image from one
color space to anotherFilter Color with OpenCVDenoising of colored
imagesVisualizing image in different color spacesFind Co-ordinates of
ContoursBilateral FilteringImage Inpainting using OpenCVIntensity
Transformation Operations on ImagesImage RegistrationBackground
subtractionBackground Subtraction in an Image using Concept of Running
AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Blurring an ImageCreate Border around ImagesGrayscaling of
ImagesScaling, Rotating, Shifting and Edge DetectionErosion and Dilation
of imagesAnalyze an image using HistogramHistograms EqualizationSimple
ThresholdingAdaptive ThresholdingOtsu ThresholdingSegmentation using
ThresholdingConvert an image from one color space to anotherFilter Color
with OpenCVDenoising of colored imagesVisualizing image in different
color spacesFind Co-ordinates of ContoursBilateral FilteringImage
Inpainting using OpenCVIntensity Transformation Operations on
ImagesImage RegistrationBackground subtractionBackground Subtraction in
an Image using Concept of Running AverageForeground Extraction in an
Image using Grabcut AlgorithmMorphological Operations in Image
Processing (Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Create Border around ImagesGrayscaling of ImagesScaling, Rotating,
Shifting and Edge DetectionErosion and Dilation of imagesAnalyze an
image using HistogramHistograms EqualizationSimple ThresholdingAdaptive
ThresholdingOtsu ThresholdingSegmentation using ThresholdingConvert an
image from one color space to anotherFilter Color with OpenCVDenoising
of colored imagesVisualizing image in different color spacesFind
Co-ordinates of ContoursBilateral FilteringImage Inpainting using
OpenCVIntensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Grayscaling of ImagesScaling, Rotating, Shifting and Edge
DetectionErosion and Dilation of imagesAnalyze an image using
HistogramHistograms EqualizationSimple ThresholdingAdaptive
ThresholdingOtsu ThresholdingSegmentation using ThresholdingConvert an
image from one color space to anotherFilter Color with OpenCVDenoising
of colored imagesVisualizing image in different color spacesFind
Co-ordinates of ContoursBilateral FilteringImage Inpainting using
OpenCVIntensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Scaling, Rotating, Shifting and Edge DetectionErosion and Dilation of
imagesAnalyze an image using HistogramHistograms EqualizationSimple
ThresholdingAdaptive ThresholdingOtsu ThresholdingSegmentation using
ThresholdingConvert an image from one color space to anotherFilter Color
with OpenCVDenoising of colored imagesVisualizing image in different
color spacesFind Co-ordinates of ContoursBilateral FilteringImage
Inpainting using OpenCVIntensity Transformation Operations on
ImagesImage RegistrationBackground subtractionBackground Subtraction in
an Image using Concept of Running AverageForeground Extraction in an
Image using Grabcut AlgorithmMorphological Operations in Image
Processing (Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Erosion and Dilation of imagesAnalyze an image using HistogramHistograms
EqualizationSimple ThresholdingAdaptive ThresholdingOtsu
ThresholdingSegmentation using ThresholdingConvert an image from one
color space to anotherFilter Color with OpenCVDenoising of colored
imagesVisualizing image in different color spacesFind Co-ordinates of
ContoursBilateral FilteringImage Inpainting using OpenCVIntensity
Transformation Operations on ImagesImage RegistrationBackground
subtractionBackground Subtraction in an Image using Concept of Running
AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Analyze an image using HistogramHistograms EqualizationSimple
ThresholdingAdaptive ThresholdingOtsu ThresholdingSegmentation using
ThresholdingConvert an image from one color space to anotherFilter Color
with OpenCVDenoising of colored imagesVisualizing image in different
color spacesFind Co-ordinates of ContoursBilateral FilteringImage
Inpainting using OpenCVIntensity Transformation Operations on
ImagesImage RegistrationBackground subtractionBackground Subtraction in
an Image using Concept of Running AverageForeground Extraction in an
Image using Grabcut AlgorithmMorphological Operations in Image
Processing (Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Histograms EqualizationSimple ThresholdingAdaptive ThresholdingOtsu
ThresholdingSegmentation using ThresholdingConvert an image from one
color space to anotherFilter Color with OpenCVDenoising of colored
imagesVisualizing image in different color spacesFind Co-ordinates of
ContoursBilateral FilteringImage Inpainting using OpenCVIntensity
Transformation Operations on ImagesImage RegistrationBackground
subtractionBackground Subtraction in an Image using Concept of Running
AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Simple ThresholdingAdaptive ThresholdingOtsu ThresholdingSegmentation
using ThresholdingConvert an image from one color space to anotherFilter
Color with OpenCVDenoising of colored imagesVisualizing image in
different color spacesFind Co-ordinates of ContoursBilateral
FilteringImage Inpainting using OpenCVIntensity Transformation
Operations on ImagesImage RegistrationBackground subtractionBackground
Subtraction in an Image using Concept of Running AverageForeground
Extraction in an Image using Grabcut AlgorithmMorphological Operations
in Image Processing (Opening)Morphological Operations in Image
Processing (Closing)Morphological Operations in Image Processing
(Gradient)Image segmentation using Morphological operationsImage
TranslationImage Pyramid

Adaptive ThresholdingOtsu ThresholdingSegmentation using
ThresholdingConvert an image from one color space to anotherFilter Color
with OpenCVDenoising of colored imagesVisualizing image in different
color spacesFind Co-ordinates of ContoursBilateral FilteringImage
Inpainting using OpenCVIntensity Transformation Operations on
ImagesImage RegistrationBackground subtractionBackground Subtraction in
an Image using Concept of Running AverageForeground Extraction in an
Image using Grabcut AlgorithmMorphological Operations in Image
Processing (Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Otsu ThresholdingSegmentation using ThresholdingConvert an image from
one color space to anotherFilter Color with OpenCVDenoising of colored
imagesVisualizing image in different color spacesFind Co-ordinates of
ContoursBilateral FilteringImage Inpainting using OpenCVIntensity
Transformation Operations on ImagesImage RegistrationBackground
subtractionBackground Subtraction in an Image using Concept of Running
AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Segmentation using ThresholdingConvert an image from one color space to
anotherFilter Color with OpenCVDenoising of colored imagesVisualizing
image in different color spacesFind Co-ordinates of ContoursBilateral
FilteringImage Inpainting using OpenCVIntensity Transformation
Operations on ImagesImage RegistrationBackground subtractionBackground
Subtraction in an Image using Concept of Running AverageForeground
Extraction in an Image using Grabcut AlgorithmMorphological Operations
in Image Processing (Opening)Morphological Operations in Image
Processing (Closing)Morphological Operations in Image Processing
(Gradient)Image segmentation using Morphological operationsImage
TranslationImage Pyramid

Convert an image from one color space to anotherFilter Color with
OpenCVDenoising of colored imagesVisualizing image in different color
spacesFind Co-ordinates of ContoursBilateral FilteringImage Inpainting
using OpenCVIntensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Filter Color with OpenCVDenoising of colored imagesVisualizing image in
different color spacesFind Co-ordinates of ContoursBilateral
FilteringImage Inpainting using OpenCVIntensity Transformation
Operations on ImagesImage RegistrationBackground subtractionBackground
Subtraction in an Image using Concept of Running AverageForeground
Extraction in an Image using Grabcut AlgorithmMorphological Operations
in Image Processing (Opening)Morphological Operations in Image
Processing (Closing)Morphological Operations in Image Processing
(Gradient)Image segmentation using Morphological operationsImage
TranslationImage Pyramid

Denoising of colored imagesVisualizing image in different color
spacesFind Co-ordinates of ContoursBilateral FilteringImage Inpainting
using OpenCVIntensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Visualizing image in different color spacesFind Co-ordinates of
ContoursBilateral FilteringImage Inpainting using OpenCVIntensity
Transformation Operations on ImagesImage RegistrationBackground
subtractionBackground Subtraction in an Image using Concept of Running
AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Find Co-ordinates of ContoursBilateral FilteringImage Inpainting using
OpenCVIntensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Bilateral FilteringImage Inpainting using OpenCVIntensity Transformation
Operations on ImagesImage RegistrationBackground subtractionBackground
Subtraction in an Image using Concept of Running AverageForeground
Extraction in an Image using Grabcut AlgorithmMorphological Operations
in Image Processing (Opening)Morphological Operations in Image
Processing (Closing)Morphological Operations in Image Processing
(Gradient)Image segmentation using Morphological operationsImage
TranslationImage Pyramid

Image Inpainting using OpenCVIntensity Transformation Operations on
ImagesImage RegistrationBackground subtractionBackground Subtraction in
an Image using Concept of Running AverageForeground Extraction in an
Image using Grabcut AlgorithmMorphological Operations in Image
Processing (Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Intensity Transformation Operations on ImagesImage
RegistrationBackground subtractionBackground Subtraction in an Image
using Concept of Running AverageForeground Extraction in an Image using
Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Image RegistrationBackground subtractionBackground Subtraction in an
Image using Concept of Running AverageForeground Extraction in an Image
using Grabcut AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Background subtractionBackground Subtraction in an Image using Concept
of Running AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Background Subtraction in an Image using Concept of Running
AverageForeground Extraction in an Image using Grabcut
AlgorithmMorphological Operations in Image Processing
(Opening)Morphological Operations in Image Processing
(Closing)Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Foreground Extraction in an Image using Grabcut AlgorithmMorphological
Operations in Image Processing (Opening)Morphological Operations in
Image Processing (Closing)Morphological Operations in Image Processing
(Gradient)Image segmentation using Morphological operationsImage
TranslationImage Pyramid

Morphological Operations in Image Processing (Opening)Morphological
Operations in Image Processing (Closing)Morphological Operations in
Image Processing (Gradient)Image segmentation using Morphological
operationsImage TranslationImage Pyramid

Morphological Operations in Image Processing (Closing)Morphological
Operations in Image Processing (Gradient)Image segmentation using
Morphological operationsImage TranslationImage Pyramid

Morphological Operations in Image Processing (Gradient)Image
segmentation using Morphological operationsImage TranslationImage
Pyramid

Image segmentation using Morphological operationsImage TranslationImage
Pyramid

Image TranslationImage Pyramid

Image Pyramid

Line detection using Houghline methodCircle DetectionDetect corner of an
imageCorner Detection with Shi-Tomasi methodCorner detection with Harris
Corner DetectionFind Circles and Ellipses in an ImageDocument field
detectionSmile detection

Circle DetectionDetect corner of an imageCorner Detection with
Shi-Tomasi methodCorner detection with Harris Corner DetectionFind
Circles and Ellipses in an ImageDocument field detectionSmile detection

Detect corner of an imageCorner Detection with Shi-Tomasi methodCorner
detection with Harris Corner DetectionFind Circles and Ellipses in an
ImageDocument field detectionSmile detection

Corner Detection with Shi-Tomasi methodCorner detection with Harris
Corner DetectionFind Circles and Ellipses in an ImageDocument field
detectionSmile detection

Corner detection with Harris Corner DetectionFind Circles and Ellipses
in an ImageDocument field detectionSmile detection

Find Circles and Ellipses in an ImageDocument field detectionSmile
detection

Document field detectionSmile detection

Smile detection

Drawing Functions

Draw a lineDraw arrow segmentDraw an ellipseDraw a circleDraw a
rectangleDraw a text stringFind and Draw ContoursDraw a triangle with
centroid

Draw arrow segmentDraw an ellipseDraw a circleDraw a rectangleDraw a
text stringFind and Draw ContoursDraw a triangle with centroid

Draw an ellipseDraw a circleDraw a rectangleDraw a text stringFind and
Draw ContoursDraw a triangle with centroid

Draw a circleDraw a rectangleDraw a text stringFind and Draw
ContoursDraw a triangle with centroid

Draw a rectangleDraw a text stringFind and Draw ContoursDraw a triangle
with centroid

Draw a text stringFind and Draw ContoursDraw a triangle with centroid

Find and Draw ContoursDraw a triangle with centroid

Draw a triangle with centroid

Working with Videos
-------------------

Getting Started

Play a video using OpenCV

Video Processing

Create video using multiple imagesExtract images from video

Extract images from video

Applications and Projects
-------------------------

Extract frames using OpenCVDisplaying the coordinates of the points
clicked on the image using Python-OpenCVWhite and black dot
detectionOpenCV BGR color palette with trackbarsDraw rectangular shape
and extract objectsInvisible Cloak using OpenCVUnsupervised Face
Clustering PipelineSaving Operated Video from a webcamFace Detection
using Python and OpenCV with webcamOpening multiple color windowsPlay a
video in reverse modeTemplate matching using OpenCV in PythonCartooning
an Image using OpenCV -- PythonVehicle detection in a Video frame using
Python -- OpenCVCount number of Faces using Python -- OpenCVLive Webcam
Drawing using OpenCVDetect and Recognize Car License Plate from a video
in real time

Displaying the coordinates of the points clicked on the image using
Python-OpenCV

White and black dot detectionOpenCV BGR color palette with trackbarsDraw
rectangular shape and extract objectsInvisible Cloak using
OpenCVUnsupervised Face Clustering PipelineSaving Operated Video from a
webcamFace Detection using Python and OpenCV with webcamOpening multiple
color windowsPlay a video in reverse modeTemplate matching using OpenCV
in PythonCartooning an Image using OpenCV -- PythonVehicle detection in
a Video frame using Python -- OpenCVCount number of Faces using Python
-- OpenCVLive Webcam Drawing using OpenCVDetect and Recognize Car
License Plate from a video in real time

OpenCV BGR color palette with trackbarsDraw rectangular shape and
extract objectsInvisible Cloak using OpenCVUnsupervised Face Clustering
PipelineSaving Operated Video from a webcamFace Detection using Python
and OpenCV with webcamOpening multiple color windowsPlay a video in
reverse modeTemplate matching using OpenCV in PythonCartooning an Image
using OpenCV -- PythonVehicle detection in a Video frame using Python --
OpenCVCount number of Faces using Python -- OpenCVLive Webcam Drawing
using OpenCVDetect and Recognize Car License Plate from a video in real
time

Draw rectangular shape and extract objectsInvisible Cloak using
OpenCVUnsupervised Face Clustering PipelineSaving Operated Video from a
webcamFace Detection using Python and OpenCV with webcamOpening multiple
color windowsPlay a video in reverse modeTemplate matching using OpenCV
in PythonCartooning an Image using OpenCV -- PythonVehicle detection in
a Video frame using Python -- OpenCVCount number of Faces using Python
-- OpenCVLive Webcam Drawing using OpenCVDetect and Recognize Car
License Plate from a video in real time

Invisible Cloak using OpenCVUnsupervised Face Clustering PipelineSaving
Operated Video from a webcamFace Detection using Python and OpenCV with
webcamOpening multiple color windowsPlay a video in reverse modeTemplate
matching using OpenCV in PythonCartooning an Image using OpenCV --
PythonVehicle detection in a Video frame using Python -- OpenCVCount
number of Faces using Python -- OpenCVLive Webcam Drawing using
OpenCVDetect and Recognize Car License Plate from a video in real time

Unsupervised Face Clustering PipelineSaving Operated Video from a
webcamFace Detection using Python and OpenCV with webcamOpening multiple
color windowsPlay a video in reverse modeTemplate matching using OpenCV
in PythonCartooning an Image using OpenCV -- PythonVehicle detection in
a Video frame using Python -- OpenCVCount number of Faces using Python
-- OpenCVLive Webcam Drawing using OpenCVDetect and Recognize Car
License Plate from a video in real time

Saving Operated Video from a webcamFace Detection using Python and
OpenCV with webcamOpening multiple color windowsPlay a video in reverse
modeTemplate matching using OpenCV in PythonCartooning an Image using
OpenCV -- PythonVehicle detection in a Video frame using Python --
OpenCVCount number of Faces using Python -- OpenCVLive Webcam Drawing
using OpenCVDetect and Recognize Car License Plate from a video in real
time

Face Detection using Python and OpenCV with webcamOpening multiple color
windowsPlay a video in reverse modeTemplate matching using OpenCV in
PythonCartooning an Image using OpenCV -- PythonVehicle detection in a
Video frame using Python -- OpenCVCount number of Faces using Python --
OpenCVLive Webcam Drawing using OpenCVDetect and Recognize Car License
Plate from a video in real time

Opening multiple color windowsPlay a video in reverse modeTemplate
matching using OpenCV in PythonCartooning an Image using OpenCV --
PythonVehicle detection in a Video frame using Python -- OpenCVCount
number of Faces using Python -- OpenCVLive Webcam Drawing using
OpenCVDetect and Recognize Car License Plate from a video in real time

Play a video in reverse modeTemplate matching using OpenCV in
PythonCartooning an Image using OpenCV -- PythonVehicle detection in a
Video frame using Python -- OpenCVCount number of Faces using Python --
OpenCVLive Webcam Drawing using OpenCVDetect and Recognize Car License
Plate from a video in real time

Template matching using OpenCV in PythonCartooning an Image using OpenCV
-- PythonVehicle detection in a Video frame using Python -- OpenCVCount
number of Faces using Python -- OpenCVLive Webcam Drawing using
OpenCVDetect and Recognize Car License Plate from a video in real time

Cartooning an Image using OpenCV -- Python

Vehicle detection in a Video frame using Python -- OpenCV

Count number of Faces using Python -- OpenCV

Live Webcam Drawing using OpenCV

Detect and Recognize Car License Plate from a video in real time

 
