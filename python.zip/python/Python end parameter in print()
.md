---
title: "Python end parameter in print()
"
draft: false
menu:
sidebar:
name: "Python end parameter in print()
"
parent: "Python"
weight: 14
---

Python end parameter in print()
-------------------------------



By default Python's print() function ends with a newline. A programmer
with C/C++ background may wonder how to print without a newline.
Python's print() function comes with a parameter called 'end'. By
default, the value of this parameter is '\\n', i.e. the new line
character. 

Example 1:
----------

Here, we can end a print statement with any character/string using this
parameter. 

Python3
-------

\# ends the output with a spaceprint(\"Welcome to\", end = \'
\')print(\"GeeksforGeeks\", end= \' \')

Output:

    Welcome to GeeksforGeeks

Example 2: 
-----------

One more program to demonstrate the working of the end parameter. 

Python3
-------

\# ends the output with \'@\'print(\"Python\",
end=\'@\')print(\"GeeksforGeeks\")

Output:

    Python@GeeksforGeeks

Example 3:
----------

The print() function uses the sep parameter to separate the arguments
and ends after the last argument.

Python3
-------

print(\'G\',\'F\', sep=\'\', end=\'\')print(\'G\')\#\\n provides new
line after printing the yearprint(\'09\',\'12\',\'2016\', sep=\'-\',
end=\'\\n\')  print(\'Red\',\'Green\',\'Blue\', sep=\',\',
end=\'@\')print(\'geeksforgeeks\')

Output

    GFG
    09-12-2016
    Red,Green,Blue@geeksforgeeks

Using end to concatenate strings:
---------------------------------

In this example, we use the end parameter to concatenate the two print()
statements into a single line of output. The end parameter is set to a
space character " " for the first print() statement, so the second
print() statement will start on the same line, separated by a space
character.

The end parameter is a useful feature of the print() function in Python
that can be used to control the formatting of output in various ways.

Python3
-------

name = \"Alice\"age = 30print(\"My name is\", name, \"and I am\", age,
\"years old.\", end=\" \")print(\"Nice to meet you!\")

    My name is Alice and I am 30 years old. Nice to meet you!
