---
title: "Python Pandas DataFrame
"
draft: false
menu:
sidebar:
name: "Python Pandas DataFrame
"
parent: "Python"
weight: 100
---

Python Pandas DataFrame
=======================

Pandas DataFrame is two-dimensional size-mutable, potentially
heterogeneous tabular data structure with labeled axes (rows and
columns). A Data frame is a two-dimensional data structure, i.e., data
is aligned in a tabular fashion in rows and columns. Pandas DataFrame
consists of three principal components, the data, rows, and columns.

![](https://media.geeksforgeeks.org/wp-content/uploads/finallpandas.png){.alignnone
.size-full .wp-image-819624 width="800" height="495"}

We will get a brief insight on all these basic operation which can be
performed on Pandas DataFrame :

Creating a DataFrame

Dealing with Rows and Columns

Indexing and Selecting Data

Working with Missing Data

Iterating over rows and columns

Creating a Pandas DataFrame
---------------------------

In the real world, a Pandas DataFrame will be created by loading the
datasets from existing storage, storage can be SQL Database, CSV file,
and Excel file. Pandas DataFrame can be created from the lists,
dictionary, and from a list of dictionary etc. Dataframe can be created
in different ways here are some ways by which we create a dataframe:

Creating a dataframe using List: DataFrame can be created using a single
list or a list of lists.

Python3
-------


    # import pandas as pd
    import pandas as pd

    # list of strings
    lst = ['Geeks', 'For', 'Geeks', 'is', 
                'portal', 'for', 'Geeks']

    # Calling DataFrame constructor on list
    df = pd.DataFrame(lst)
    print(df)

Output: Creating DataFrame from dict of ndarray/lists: To create
DataFrame from dict of narray/list, all the narray must be of same
length. If index is passed then the length index should be equal to the
length of arrays. If no index is passed, then by default, index will be
range(n) where n is the array length.

![](https://media.geeksforgeeks.org/wp-content/uploads/df_from_list1.png){.alignnone
.size-full .wp-image-756787 width="126" height="300"}

Python3
-------

    # Python code demonstrate creating 
    # DataFrame from dict narray / lists 
    # By default addresses.

    import pandas as pd

    # intialise data of lists.
    data = {'Name':['Tom', 'nick', 'krish', 'jack'],
            'Age':[20, 21, 19, 18]}

    # Create DataFrame
    df = pd.DataFrame(data)

    # Print the output.
    print(df)

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/df2-1.png){.alignnone
.size-full .wp-image-688564 width="199" height="222"}

 For more details refer to Creating a Pandas DataFrame

Dealing with Rows and Columns
-----------------------------

A Data frame is a two-dimensional data structure, i.e., data is aligned
in a tabular fashion in rows and columns. We can perform basic
operations on rows/columns like selecting, deleting, adding, and
renaming.

Column Selection: In Order to select a column in Pandas DataFrame, we
can either access the columns by calling them by their columns name.

Python3
-------

    # Import pandas package
    import pandas as pd

    # Define a dictionary containing employee data
    data = {'Name':['Jai', 'Princi', 'Gaurav', 'Anuj'],
            'Age':[27, 24, 22, 32],
            'Address':['Delhi', 'Kanpur', 'Allahabad', 'Kannauj'],
            'Qualification':['Msc', 'MA', 'MCA', 'Phd']}

    # Convert the dictionary into DataFrame 
    df = pd.DataFrame(data)

    # select two columns
    print(df[['Name', 'Qualification']])

Output: Row Selection: Pandas provide a unique method to retrieve rows
from a Data frame. DataFrame.loc\[\] method is used to retrieve rows
from Pandas DataFrame. Rows can also be selected by passing integer
location to an iloc\[\] function.Note: We'll be using nba.csv file in
below examples.

![](https://media.geeksforgeeks.org/wp-content/uploads/df_col1.png){.alignnone
.size-full .wp-image-715108 width="251" height="232"}

Python3
-------

    # importing pandas package
    import pandas as pd

    # making data frame from csv file
    data = pd.read_csv("nba.csv", index_col ="Name")

    # retrieving row by loc method
    first = data.loc["Avery Bradley"]
    second = data.loc["R.J. Hunter"]


    print(first, "\n\n\n", second)

Output:As shown in the output image, two series were returned since
there was only one parameter both of the times.For more Details refer to
Dealing with Rows and Columns 

![](https://media.geeksforgeeks.org/wp-content/uploads/out1-22.jpg){.alignnone
.size-full .wp-image-526757 width="409" height="383"}

Indexing and Selecting Data
---------------------------

Indexing in pandas means simply selecting particular rows and columns of
data from a DataFrame. Indexing could mean selecting all the rows and
some of the columns, some of the rows and all of the columns, or some of
each of the rows and columns. Indexing can also be known as Subset
Selection.

Indexing a Dataframe using indexing operator \[\] :Indexing operator is
used to refer to the square brackets following an object. The .loc and
.iloc indexers also use the indexing operator to make selections. In
this indexing operator to refer to df\[\].

Selecting a single columns
--------------------------

In order to select a single column, we simply put the name of the column
in-between the brackets

Python3
-------

    # importing pandas package
    import pandas as pd

    # making data frame from csv file
    data = pd.read_csv("nba.csv", index_col ="Name")

    # retrieving columns by indexing operator
    first = data["Age"]



    print(first)

Output: Indexing a DataFrame using .loc\[ \] :This function selects data
by the label of the rows and columns. The df.loc indexer selects data in
a different way than just the indexing operator. It can select subsets
of rows or columns. It can also simultaneously select subsets of rows
and columns.

![](https://media.geeksforgeeks.org/wp-content/uploads/snippp.jpg){.aligncenter
.size-full .wp-image-788120 width="305" height="431"}

Selecting a single row
----------------------

In order to select a single row using .loc\[\], we put a single row
label in a .loc function.

Python3
-------

    # importing pandas package
    import pandas as pd

    # making data frame from csv file
    data = pd.read_csv("nba.csv", index_col ="Name")

    # retrieving row by loc method
    first = data.loc["Avery Bradley"]
    second = data.loc["R.J. Hunter"]


    print(first, "\n\n\n", second)

Output:As shown in the output image, two series were returned since
there was only one parameter both of the times. Indexing a DataFrame
using .iloc\[ \] :This function allows us to retrieve rows and columns
by position. In order to do that, we'll need to specify the positions of
the rows that we want, and the positions of the columns that we want as
well. The df.iloc indexer is very similar to df.loc but only uses
integer locations to make its selections.

![](https://media.geeksforgeeks.org/wp-content/uploads/index10.png){.aligncenter
.size-full .wp-image-784680 width="289" height="351"}

Selecting a single row
----------------------

In order to select a single row using .iloc\[\], we can pass a single
integer to .iloc\[\] function.

Python3
-------

    import pandas as pd

    # making data frame from csv file
    data = pd.read_csv("nba.csv", index_col ="Name")


    # retrieving rows by iloc method 
    row2 = data.iloc[3] 



    print(row2)

Output: For more Details refer

![](https://media.geeksforgeeks.org/wp-content/uploads/pandas7.png){.aligncenter
.size-full .wp-image-783694 width="263" height="171"}

Indexing and Selecting Data with Pandas

Boolean Indexing in Pandas

 

Working with Missing Data
-------------------------

Missing Data can occur when no information is provided for one or more
items or for a whole unit. Missing Data is a very big problem in real
life scenario. Missing Data can also refer to as NA(Not Available)
values in pandas.

Checking for missing values using isnull() and notnull() :In order to
check missing values in Pandas DataFrame, we use a function isnull() and
notnull(). Both function help in checking whether a value is NaN or not.
These function can also be used in Pandas Series in order to find null
values in a series.

Python3
-------

    # importing pandas as pd
    import pandas as pd

    # importing numpy as np
    import numpy as np

    # dictionary of lists
    dict = {'First Score':[100, 90, np.nan, 95],
            'Second Score': [30, 45, 56, np.nan],
            'Third Score':[np.nan, 40, 80, 98]}

    # creating a dataframe from list
    df = pd.DataFrame(dict)

    # using isnull() function  
    df.isnull()

Output: Filling missing values using fillna(), replace() and
interpolate() :In order to fill null values in a datasets, we use
fillna(), replace() and interpolate() function these function replace
NaN values with some value of their own. All these function help in
filling a null values in datasets of a DataFrame. Interpolate() function
is basically used to fill NA values in the dataframe but it uses various
interpolation technique to fill the missing values rather than
hard-coding the value.

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture1-41.png){.alignnone
.size-full .wp-image-794832 width="292" height="148"}

Python3
-------

    # importing pandas as pd
    import pandas as pd

    # importing numpy as np
    import numpy as np

    # dictionary of lists
    dict = {'First Score':[100, 90, np.nan, 95],
            'Second Score': [30, 45, 56, np.nan],
            'Third Score':[np.nan, 40, 80, 98]}

    # creating a dataframe from dictionary
    df = pd.DataFrame(dict)

    # filling missing value using fillna()  
    df.fillna(0)

Output: Dropping missing values using dropna() :In order to drop a null
values from a dataframe, we used dropna() function this fuction drop
Rows/Columns of datasets with Null values in different ways.

![](https://media.geeksforgeeks.org/wp-content/uploads/pd4.jpg){.aligncenter
.size-full .wp-image-802875 width="283" height="136"}

Python3
-------

    # importing pandas as pd
    import pandas as pd

    # importing numpy as np
    import numpy as np

    # dictionary of lists
    dict = {'First Score':[100, 90, np.nan, 95],
            'Second Score': [30, np.nan, 45, 56],
            'Third Score':[52, 40, 80, 98],
            'Fourth Score':[np.nan, np.nan, np.nan, 65]}

    # creating a dataframe from dictionary
    df = pd.DataFrame(dict)
      
    df

Now we drop rows with at least one Nan value (Null value)

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture16-1.png){.alignnone
.size-full .wp-image-795102 width="355" height="135"}

Python3
-------

    # importing pandas as pd
    import pandas as pd

    # importing numpy as np
    import numpy as np

    # dictionary of lists
    dict = {'First Score':[100, 90, np.nan, 95],
            'Second Score': [30, np.nan, 45, 56],
            'Third Score':[52, 40, 80, 98],
            'Fourth Score':[np.nan, np.nan, np.nan, 65]}

    # creating a dataframe from dictionary
    df = pd.DataFrame(dict)

    # using dropna() function  
    df.dropna()

Output:For more Details refer to Working with Missing Data in Pandas 

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture17-1.png){.alignnone
.size-full .wp-image-795114 width="369" height="67"}

Iterating over rows and columns
-------------------------------

Iteration is a general term for taking each item of something, one after
another. Pandas DataFrame consists of rows and columns so, in order to
iterate over dataframe, we have to iterate a dataframe like a
dictionary.

Iterating over rows :In order to iterate over rows, we can use three
function iteritems(), iterrows(), itertuples() . These three function
will help in iteration over rows.

Python3
-------

    # importing pandas as pd
    import pandas as pd
     
    # dictionary of lists
    dict = {'name':["aparna", "pankaj", "sudhir", "Geeku"],
            'degree': ["MBA", "BCA", "M.Tech", "MBA"],
            'score':[90, 40, 80, 98]}

    # creating a dataframe from a dictionary 
    df = pd.DataFrame(dict)

    print(df)

Now we apply iterrows() function in order to get a each element of rows.

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture12-5.png){.alignnone
.size-full .wp-image-796918 width="183" height="143"}

Python3
-------

    # importing pandas as pd
    import pandas as pd
     
    # dictionary of lists
    dict = {'name':["aparna", "pankaj", "sudhir", "Geeku"],
            'degree': ["MBA", "BCA", "M.Tech", "MBA"],
            'score':[90, 40, 80, 98]}

    # creating a dataframe from a dictionary 
    df = pd.DataFrame(dict)

    # iterating over rows using iterrows() function 
    for i, j in df.iterrows():
        print(i, j)
        print()

Output: Iterating over Columns :In order to iterate over columns, we
need to create a list of dataframe columns and then iterating through
that list to pull out the dataframe columns.

![](https://media.geeksforgeeks.org/wp-content/uploads/pd1.jpg){.alignnone
.size-full .wp-image-802664 width="216" height="350"}

Python3
-------

    # importing pandas as pd
    import pandas as pd
      
    # dictionary of lists
    dict = {'name':["aparna", "pankaj", "sudhir", "Geeku"],
            'degree': ["MBA", "BCA", "M.Tech", "MBA"],
            'score':[90, 40, 80, 98]}
     
    # creating a dataframe from a dictionary 
    df = pd.DataFrame(dict)

    print(df)

Now we iterate through columns in order to iterate through columns we
first create a list of dataframe columns and then iterate through list.

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture12-5.png){.alignnone
.size-full .wp-image-796918 width="183" height="143"}

Python3
-------

    # creating a list of dataframe columns
    columns = list(df)

    for i in columns:

        # printing the third element of the column
        print (df[i][2])

Output: For more Details refer to Iterating over rows and columns in
Pandas DataFrame

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture55.jpg){.alignnone
.size-full .wp-image-802580 width="92" height="55"}

DataFrame Methods:

FUNCTIONDESCRIPTIONindex()Method returns index (row labels) of the
DataFrameinsert()Method inserts a column into a DataFrameadd()Method
returns addition of dataframe and other, element-wise (binary operator
add)sub()Method returns subtraction of dataframe and other, element-wise
(binary operator sub)mul()Method returns multiplication of dataframe and
other, element-wise (binary operator mul)div()Method returns floating
division of dataframe and other, element-wise (binary operator
truediv)unique()Method extracts the unique values in the
dataframenunique()Method returns count of the unique values in the
dataframevalue\_counts()Method counts the number of times each unique
value occurs within the Seriescolumns()Method returns the column labels
of the DataFrameaxes()Method returns a list representing the axes of the
DataFrameisnull()Method creates a Boolean Series for extracting rows
with null valuesnotnull()Method creates a Boolean Series for extracting
rows with non-null valuesbetween()Method extracts rows where a column
value falls in between a predefined rangeisin()Method extracts rows from
a DataFrame where a column value exists in a predefined
collectiondtypes()Method returns a Series with the data type of each
column. The result's index is the original DataFrame's
columnsastype()Method converts the data types in a Seriesvalues()Method
returns a Numpy representation of the DataFrame i.e. only the values in
the DataFrame will be returned, the axes labels will be
removedsort\_values()- Set1, Set2Method sorts a data frame in Ascending
or Descending order of passed Columnsort\_index()Method sorts the values
in a DataFrame based on their index positions or labels instead of their
values but sometimes a data frame is made out of two or more data frames
and hence later index can be changed using this methodloc\[\]Method
retrieves rows based on index labeliloc\[\]Method retrieves rows based
on index positionix\[\]Method retrieves DataFrame rows based on either
index label or index position. This method combines the best features of
the .loc\[\] and .iloc\[\] methodsrename()Method is called on a
DataFrame to change the names of the index labels or column
namescolumns()Method is an alternative attribute to change the coloumn
namedrop()Method is used to delete rows or columns from a
DataFramepop()Method is used to delete rows or columns from a
DataFramesample()Method pulls out a random sample of rows or columns
from a DataFramensmallest()Method pulls out the rows with the smallest
values in a columnnlargest()Method pulls out the rows with the largest
values in a columnshape()Method returns a tuple representing the
dimensionality of the DataFramendim()Method returns an 'int'
representing the number of axes / array dimensions.Returns 1 if Series,
otherwise returns 2 if DataFramedropna()Method allows the user to
analyze and drop Rows/Columns with Null values in different
waysfillna()Method manages and let the user replace NaN values with some
value of their ownrank()Values in a Series can be ranked in order with
this methodquery()Method is an alternate string-based syntax for
extracting a subset from a DataFramecopy()Method creates an independent
copy of a pandas objectduplicated()Method creates a Boolean Series and
uses it to extract rows that have duplicate
valuesdrop\_duplicates()Method is an alternative option to identifying
duplicate rows and removing them through filteringset\_index()Method
sets the DataFrame index (row labels) using one or more existing
columnsreset\_index()Method resets index of a Data Frame. This method
sets a list of integer ranging from 0 to length of data as
indexwhere()Method is used to check a Data Frame for one or more
condition and return the result accordingly. By default, the rows not
satisfying the condition are filled with NaN value

 More on Pandas

Python \| Pandas Series

Python \| Pandas Working With Text Data

Python \| Pandas Working with Dates and Times

Python \| Pandas Merging, Joining, and Concatenating
