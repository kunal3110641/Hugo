---
title: "How to assign values to variables in Python and other languages
"
draft: false
menu:
sidebar:
name: "How to assign values to variables in Python and other languages
"
parent: "Python"
weight: 8
---

How to assign values to variables in Python and other languages
---------------------------------------------------------------



This article discusses methods to assign values to variables. 

Method 1: Direct Initialisation Method 
---------------------------------------

In this method, you will directly assign the value in python but in
other programming languages like C, and C++, you have to first
initialize the data type of the variable. So, In Python, there is no
need for explicit declaration in variables as compared to using some
other programming languages. You can start using the variable right
away.

C++
---

// C++ code to demonstrate variable assignment// upon condition using
Direct Initialisation Method \#include using namespace std; int
main(){    // initialising variables directly    int a = 5;     //
printing value of a    cout \<\< \"The value of a is: \" \<\< a;}

C
-

// C code to demonstrate variable assignment// upon condition using
Direct Initialisation Method \#include  int main(){    // initialising
variables directly    int a = 5;     // printing value of
a    printf(\"The value of a is: %d\", a);}

Java
----

// Java code to demonstrate variable assignment// upon condition using
Direct Initialisation Method import java.io.\*; class GFG {    public
static void main(String args\[\])    {         // initialising variables
directly        int a = 5;         // printing value of
a        System.out.println(\"The value of a is: \" + a);    }}

Python3
-------

\# Python 3 code to demonstrate variable assignment\# upon condition
using Direct Initialisation Method \# initialising variable directlya =
5 \# printing value of aprint (\"The value of a is: \" + str(a))

C\#
---

// C\# code to demonstrate variable assignment// upon condition using
Direct Initialisation Methodusing System;  class GFG{     public static
void Main(String \[\]args){         // Initialising variables
directly    int a = 5;     // Printing value of a    Console.Write(\"The
value of a is: \" + a);}}  // This code is contributed by
shivanisinghss2110

Javascript
----------

// this code is contributed by shivanisinghss2110

    The value of a is: 5

Assigning multiple values to different variables :
--------------------------------------------------

Unlike other languages, we can easily assign values to multiple
variables in python easily.

Java
----

/\*package whatever //do not write package name here \*/ //Assigning
multiple values in java import java.io.\*; class GFG {    public static
void main (String\[\] args) {               String
a=\"geeks\",b=\"for\",c=\"geeks\";      System.out.println(a+b+c);           }}

Python
------

\# Assigning multiple values in single
line a,b,c=\"geeks\",\"for\",\"geeks\"print(a+b+c)

Javascript
----------

\# Assigning multiple values in single line let
\[a,b,c\]=\[\"geeks\",\"for\",\"geeks\"\]console.log(a+b+c);

    geeksforgeeks

Method 2: Using Conditional Operator (?:)

This method is also called Ternary operators. So Basic Syntax of a
Conditional Operator is:-

                                                                       
 condition? True\_value : False\_Value

Using Conditional Operator, you can write one line code in python. The
conditional operator works in such a way that first evaluates the
condition, if the condition is true, the first expression( True\_value)
will print else evaluates the second expression(False\_Value).

Below is the syntax in other popular languages.

C++
---

// C++ code to demonstrate variable assignment// upon condition using
Conditional Operator \#include using namespace std; int main(){    //
initialising variables using Conditional Operator    int a = 20 \> 10 ?
1 : 0;     // printing value of a    cout \<\< \"The value of a is: \"
\<\< a;}

C
-

// C code to demonstrate variable assignment// upon condition using
Conditional Operator \#include  int main(){    // initialising variables
using Conditional Operator    int a = 20 \> 10 ? 1 : 0;     // printing
value of a    printf(\"The value of a is: %d\", a);}

Java
----

// Java code to demonstrate variable assignment// upon condition using
Conditional Operator import java.io.\*; class GFG {    public static
void main(String args\[\])    {         // initialising variables using
Conditional Operator        int a = 20 \> 10 ? 1 : 0;         //
printing value of a        System.out.println(\"The value of a is: \" +
a);    }}

Python3
-------

\# Python3 code to demonstrate variable assignment\# upon condition
using Conditional Operator \# Initialising variables using Conditional
Operatora = 1 if 20 \> 10 else 0 \# Printing value of aprint(\"The value
of a is: \" , str(a)) \# This code is contributed by shivanisinghss2110

C\#
---

// C\# code to demonstrate variable assignment// upon condition using
Conditional Operator using System; class GFG {    public static void
Main(String \[\]args)    {         // initialising variables using
Conditional Operator        int a = 20 \> 10 ? 1 : 0;         //
printing value of a        Console.Write(\"The value of a is: \" +
a);    }}// this code is contributed by shivanisinghss2110

Javascript
----------

    The value of a is: 1

One liner if-else instead of Conditional Operator (?:) in Python
----------------------------------------------------------------

Python3
-------

\# Python 3 code to demonstrate variable assignment\# upon condition
using One liner if-else \# initialising variable using Conditional
Operator\# a = 20 \> 10 ? 1 : 0 is not possible in Python\# Instead
there is one liner if-elsea = 1 if 20 \> 10 else 0 \# printing value of
aprint (\"The value of a is: \" + str(a))

    The value of a is: 1
