---
title: "Taking multiple inputs from user in Python
"
draft: false
menu:
sidebar:
name: "Taking multiple inputs from user in Python
"
parent: "Python"
weight: 11
---

Taking multiple inputs from user in Python
------------------------------------------



The developer often wants a user to enter multiple values or inputs in
one line. In C++/C user can take multiple inputs in one line using scanf
but in Python user can take multiple values or inputs in one line by two
methods. 

Using split() method

Using List comprehension

Using split() method : This function helps in getting multiple inputs
from users. It breaks the given input by the specified separator. If a
separator is not provided then any white space is a separator.
Generally, users use a split() method to split a Python string but one
can use it in taking multiple inputs.

Syntax : 

    input().split(separator, maxsplit)

Example : 

Python3
-------

\# Python program showing how to\# multiple input using split \# taking
two inputs at a timex, y = input(\"Enter two values:
\").split()print(\"Number of boys: \", x)print(\"Number of girls: \",
y) \# taking three inputs at a timex, y, z = input(\"Enter three values:
\").split()print(\"Total number of students: \", x)print(\"Number of
boys is : \", y)print(\"Number of girls is : \", z) \# taking two inputs
at a timea, b = input(\"Enter two values: \").split()print(\"First
number is {} and second number is {}\".format(a, b)) \# taking multiple
inputs at a time\# and type casting using list() functionx =
list(map(int, input(\"Enter multiple values: \").split()))print(\"List
of students: \", x)

Output: 

    Enter two values: 5 10
    Number of boys:  5  
    Number of girls:  10
    Enter three values: 5 10 15
    Total number of students:  5
    Number of boys is :  10     
    Number of girls is :  15    
    Enter two values: 5 10
    First number is 5 and second number is 10
    Enter multiple values: 5 10 15 20 25
    List of students:  [5, 10, 15, 20, 25]

Using List comprehension : List comprehension is an elegant way to
define and create a list in Python. We can create lists just like
mathematical statements in one line only. It is also used in getting
multiple inputs from a user. 

Example: 

Python3
-------

\# Python program showing\# how to take multiple input\# using List
comprehension \# taking two input at a timex, y = \[int(x) for x in
input(\"Enter two values: \").split()\]print(\"First Number is: \",
x)print(\"Second Number is: \", y) \# taking three input at a timex, y,
z = \[int(x) for x in input(\"Enter three values:
\").split()\]print(\"First Number is: \", x)print(\"Second Number is:
\", y)print(\"Third Number is: \", z) \# taking two inputs at a timex, y
= \[int(x) for x in input(\"Enter two values: \").split()\]print(\"First
number is {} and second number is {}\".format(x, y)) \# taking multiple
inputs at a timex = \[int(x) for x in input(\"Enter multiple values:
\").split()\]print(\"Number of list is: \", x)

Output :

    Enter two values: 5 10
    First Number is:  5
    Second Number is:  10
    Enter three values: 5 10 15
    First Number is:  5
    Second Number is:  10
    Third Number is:  15
    Enter two values: 5 10
    First number is 5 and second number is 10
    Enter multiple values: 5 10 15 20 25
    Number of list is:  [5, 10, 15, 20, 25]

Note: The above examples take input separated by spaces. In case we wish
to take input separated by comma (, ), we can use the following: 

Python3
-------

\# taking multiple inputs at a time separated by commax = \[int(x) for x
in input(\"Enter multiple value: \").split(\",\")\]print(\"Number of
list is: \", x)

