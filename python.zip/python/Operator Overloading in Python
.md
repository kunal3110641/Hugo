---
title: "Operator Overloading in Python
"
draft: false
menu:
sidebar:
name: "Operator Overloading in Python
"
parent: "Python"
weight: 20
---

Operator Overloading in Python
------------------------------



Operator Overloading means giving extended meaning beyond their
predefined operational meaning. For example operator + is used to add
two integers as well as join two strings and merge two lists. It is
achievable because '+' operator is overloaded by int class and str
class. You might have noticed that the same built-in operator or
function shows different behavior for objects of different classes, this
is called Operator Overloading. 

Example

Python3
-------

\# Python program to show use of\# + operator for different
purposes. print(1 + 2) \# concatenate two
stringsprint(\"Geeks\"+\"For\") \# Product two numbersprint(3 \* 4) \#
Repeat the Stringprint(\"Geeks\"\*4)

    3
    GeeksFor
    12
    GeeksGeeksGeeksGeeks

How to overload the operators in Python? 

Consider that we have two objects which are a physical representation of
a class (user-defined data type) and we have to add two objects with
binary '+' operator it throws an error, because compiler don't know how
to add two objects. So we define a method for an operator and that
process is called operator overloading. We can overload all existing
operators but we can't create a new operator. To perform operator
overloading, Python provides some special function or magic function
that is automatically invoked when it is associated with that particular
operator. For example, when we use + operator, the magic method
\_\_add\_\_ is automatically invoked in which the operation for +
operator is defined.

Overloading binary + operator in Python: 

When we use an operator on user-defined data types then automatically a
special function or magic function associated with that operator is
invoked. Changing the behavior of operator is as simple as changing the
behavior of a method or function. You define methods in your class and
operators work according to that behavior defined in methods. When we
use + operator, the magic method \_\_add\_\_ is automatically invoked in
which the operation for + operator is defined. Thereby changing this
magic method's code, we can give extra meaning to the + operator. 

How Does the Operator Overloading Actually work?

Whenever you change the behavior of the existing operator through
operator overloading, you have to redefine the special function that is
invoked automatically when the operator is used with the objects. 

For Example: 

Code 1:  

Python3
-------

\# Python Program illustrate how\# to overload an binary + operator\#
And how it actually works class A:    def \_\_init\_\_(self,
a):        self.a = a     \# adding two objects    def \_\_add\_\_(self,
o):        return self.a + o.aob1 = A(1)ob2 = A(2)ob3 = A(\"Geeks\")ob4
= A(\"For\") print(ob1 + ob2)print(ob3 + ob4)\# Actual working when
Binary Operator is used.print(A.\_\_add\_\_(ob1 ,
ob2))print(A.\_\_add\_\_(ob3,ob4))\#And can also be Understand as
:print(ob1.\_\_add\_\_(ob2))print(ob3.\_\_add\_\_(ob4))

    3
    GeeksFor
    3
    GeeksFor
    3
    GeeksFor

Here, We defined the special function "\_\_add\_\_( )"  and when the
objects ob1 and ob2 are coded as "ob1 + ob2", the special function is
automatically called as ob1.\_\_add\_\_(ob2) which simply means that ob1
calls the \_\_add\_\_( ) function with ob2 as an Argument and It
actually means A .\_\_add\_\_(ob1, ob2). Hence, when the Binary operator
is overloaded, the object before the operator calls the respective
function with object after operator as parameter.

Code 2: 

Python3
-------

\# Python Program to perform addition\# of two complex numbers using
binary\# + operator overloading. class complex:    def
\_\_init\_\_(self, a, b):        self.a = a        self.b = b      \#
adding two objects    def \_\_add\_\_(self, other):        return self.a
+ other.a, self.b + other.b Ob1 = complex(1, 2)Ob2 = complex(2, 3)Ob3 =
Ob1 + Ob2print(Ob3)

    (3, 5)

Overloading comparison operators in Python :  

Python3
-------

\# Python program to overload\# a comparison operators class A:    def
\_\_init\_\_(self, a):        self.a = a    def \_\_gt\_\_(self,
other):        if(self.a\>other.a):            return
True        else:            return Falseob1 = A(2)ob2 =
A(3)if(ob1\>ob2):    print(\"ob1 is greater than
ob2\")else:    print(\"ob2 is greater than ob1\")

Output:

    ob2 is greater than ob1

Overloading equality and less than operators: 

Python3
-------

\# Python program to overload equality\# and less than operators class
A:    def \_\_init\_\_(self, a):        self.a = a    def
\_\_lt\_\_(self, other):        if(self.a

Output:

    ob1 is lessthan ob2
    Not equal

Python magic methods or special functions for operator overloading
------------------------------------------------------------------

Binary Operators:
-----------------

OperatorMagic Method+\_\_add\_\_(self, other)--\_\_sub\_\_(self,
other)\*\_\_mul\_\_(self, other)/\_\_truediv\_\_(self,
other)//\_\_floordiv\_\_(self, other)%\_\_mod\_\_(self,
other)\*\*\_\_pow\_\_(self, other)\>\>\_\_rshift\_\_(self,
other)\<\<\_\_lshift\_\_(self, other)&\_\_and\_\_(self,
other)\|\_\_or\_\_(self, other)\^\_\_xor\_\_(self, other)

Comparison Operators:
---------------------

OperatorMagic Method\<\_\_lt\_\_(self, other)\>\_\_gt\_\_(self,
other)\<=\_\_le\_\_(self, other)\>=\_\_ge\_\_(self,
other)==\_\_eq\_\_(self, other)!=\_\_ne\_\_(self, other)

Assignment Operators:

OperatorMagic Method-=\_\_isub\_\_(self, other)+=\_\_iadd\_\_(self,
other)\*=\_\_imul\_\_(self, other)/=\_\_idiv\_\_(self,
other)//=\_\_ifloordiv\_\_(self, other)%=\_\_imod\_\_(self,
other)\*\*=\_\_ipow\_\_(self, other)\>\>=\_\_irshift\_\_(self,
other)\<\<=\_\_ilshift\_\_(self, other)&=\_\_iand\_\_(self,
other)\|=\_\_ior\_\_(self, other)\^=\_\_ixor\_\_(self, other)

Unary Operators:

OperatorMagic
Method--\_\_neg\_\_(self)+\_\_pos\_\_(self)\~\_\_invert\_\_(self)

Note: It is not possible to change the number of operands of an
operator. For example: If we can not overload a unary operator as a
binary operator. The following code will throw a syntax error.

Python3
-------

\# Python program which attempts to\# overload \~ operator as binary
operator  class A:    def \_\_init\_\_(self, a):        self.a =
a     \# Overloading \~ operator, but with two operands    def
\_\_invert\_\_(self):        return \"This is the \~ operator,
overloaded as binary operator.\"  ob1 = A(2) print(\~ob1)

    This is the ~ operator, overloaded as binary operator.

operator overloading on Boolean values: 
----------------------------------------

In Python, you can overload the Boolean operators and, or, and not by
defining the \_\_and\_\_, \_\_or\_\_, and \_\_not\_\_ special methods in
your class.

Here's an example of how to overload the and operator for a custom
class:

Python
------

class MyClass:    def \_\_init\_\_(self, value):        self.value =
value     def \_\_and\_\_(self, other):        return MyClass(self.value
and other.value) a = MyClass(True)b = MyClass(False)c = a & b  \#
c.value is False

Explanation:
------------

In this example, we define a MyClass that has a single attribute value,
which is a boolean. We then overload the & operator by defining the
\_\_and\_\_ method to perform a logical and operation on the value
attribute of two MyClass instances.

When we call a & b, the \_\_and\_\_ method is called with a as the first
argument and b as the second argument. The method returns a new instance
of MyClass with a value attribute that is the logical and of a.value and
b.value.

Note that Python also provides built-in boolean operators that can be
used with any object. For example, you can use the bool() function to
convert any object to a boolean value, and the all() and any() functions
to perform logical and and or operations on a sequence of boolean
values. Overloading the boolean operators in a custom class can be
useful to provide a more natural syntax and semantics for your class.

Advantages:
-----------

Overloading boolean operators in a custom class can provide several
advantages, including:

Improved readability: By overloading boolean operators, you can provide
a more natural syntax and semantics for your class that makes it easier
to read and understand.

Consistency with built-in types: Overloading boolean operators can make
your class behave more like built-in types in Python, which can make it
easier to use and integrate with other code.

Operator overloading: Overloading boolean operators is an example of
operator overloading in Python, which can make your code more concise
and expressive by allowing you to use familiar operators to perform
custom operations on your objects.

Custom behavior: Overloading boolean operators can allow you to define
custom behavior for your class that is not available in built-in types
or other classes.

Enhanced functionality: By overloading boolean operators, you can add
new functionality to your class that was not available before, such as
the ability to perform logical and or or operations on instances of your
class.

Overall, overloading boolean operators in a custom class can make your
code more readable, consistent, concise, expressive, and functional.
However, it's important to use operator overloading judiciously and only
when it makes sense for the semantics of your class.
