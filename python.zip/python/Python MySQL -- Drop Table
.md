---
title: "Python MySQL -- Drop Table
"
draft: false
menu:
sidebar:
name: "Python MySQL -- Drop Table
"
parent: "Python"
weight: 120
---

Python MySQL -- Drop Table
--------------------------



A connector is employed when we have to use MySQL with other programming
languages. The work of MySQL-connector is to provide access to MySQL
Driver to the required language. Thus, it generates a connection between
the programming language and the MySQL Server.

Drop Table Command
------------------

Drop command affects the structure of the table and not data. It is used
to delete an already existing table. For cases where you are not sure if
the table to be dropped exists or not DROP TABLE IF EXISTS command is
used. Both cases will be dealt with in the following examples. Syntax:

    DROP TABLE tablename;

    DROP TABLE IF EXISTS tablename;

The following programs will help you understand this better. Tables
before drop: Example 1: Program to demonstrate drop if exists. We will
try to drop a table which does not exist in the above database. 

![python-mysql-drop](https://media.geeksforgeeks.org/wp-content/uploads/20200306175724/python-mysql-drop.png)

Python3
-------

\# Python program to demonstrate\# drop clause  import
mysql.connector \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',) cs = mydb.cursor() \# drop
clausestatement = \"Drop Table if exists Employee\" \# Uncommenting
statement =\"DROP TABLE employee\"\# Will raise an error as the table
employee\# does not exists cs.execute(statement)cs.commit()     \#
Disconnecting from the databasemydb.close()

Output: Example 2: Program to drop table Geeks 

![python-mysql-drop-1](https://media.geeksforgeeks.org/wp-content/uploads/20200306180259/python-mysql-drop-1.png)

Python3
-------

\# Python program to demonstrate\# drop clause  import
mysql.connector \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',) cs = mydb.cursor() \# drop
clausestatement =\"DROP TABLE
Geeks\" cs.execute(statement)cs.commit()     \# Disconnecting from the
databasemydb.close()

Output:

![python-mysql-drop-2](https://media.geeksforgeeks.org/wp-content/uploads/20200306180436/python-mysql-drop-2.png)
