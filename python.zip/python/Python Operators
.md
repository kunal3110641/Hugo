---
title: "Python Operators
"
draft: false
menu:
sidebar:
name: "Python Operators
"
parent: "Python"
weight: 17
---

Python Operators
----------------



In Python programming, Operators in general are used to perform
operations on values and variables. These are standard symbols used for
the purpose of logical and arithmetic operations. In this article, we
will look into different types of Python operators. 

OPERATORS: These are the special symbols. Eg- + , \* , /, etc.

OPERAND: It is the value on which the operator is applied.

Types of Operators in Python
----------------------------

Arithmetic Operators

Comparison Operators

Logical Operators

Bitwise Operators

Assignment Operators

Identity Operators and Membership Operators

Arithmetic Operators in Python
------------------------------

Python Arithmetic operators are used to perform basic mathematical
operations like addition, subtraction, multiplication, and division.

In Python 3.x the result of division is a floating-point while in Python
2.x division of 2 integers was an integer. To obtain an integer result
in Python 3.x floored (// integer) is used.

OperatorDescriptionSyntax+Addition: adds two operandsx + y--Subtraction:
subtracts two operandsx -- y\*Multiplication: multiplies two operandsx
\* y/Division (float): divides the first operand by the secondx /
y//Division (floor): divides the first operand by the secondx //
y%Modulus: returns the remainder when the first operand is divided by
the secondx % y\*\*Power: Returns first raised to power secondx \*\* y

Example of Arithmetic Operators in Python
-----------------------------------------

Division Operators
------------------

Division Operators allow you to divide two numbers and return a
quotient, i.e., the first number or number at the left is divided by the
second number or number at the right and returns the quotient. 

There are two types of division operators: 

Float division

Floor division

Float division
--------------

The quotient returned by this operator is always a float number, no
matter if two numbers are integers. For example:

Python3
-------

\# python program to demonstrate the use of
\"/\"print(5/5)print(10/2)print(-10/2)print(20.0/2)

Output:

    1.0
    5.0
    -5.0
    10.0

Integer division( Floor division)
---------------------------------

The quotient returned by this operator is dependent on the argument
being passed. If any of the numbers is float, it returns output in
float. It is also known as Floor division because, if any number is
negative, then the output will be floored. For example:

Python3
-------

\# python program to demonstrate the use of \"//\"print(10//3)print
(-5//2)print (5.0//2)print (-5.0//2)

Output:

    3
    -3
    2.0
    -3.0

Precedence of Arithmetic Operators in Python
--------------------------------------------

The precedence of Arithmetic Operators in python is as follows:

P -- Parentheses

E -- Exponentiation

M -- Multiplication (Multiplication and division have the same
precedence)

D -- Division

A -- Addition (Addition and subtraction have the same precedence)

S -- Subtraction

The modulus operator helps us extract the last digit/s of a number. For
example:

x % 10 -\> yields the last digit

x % 100 -\> yield last two digits

Arithmetic Operators With Addition, Subtraction, Multiplication, Modulo and Power
---------------------------------------------------------------------------------

Here is an example showing how different Arithmetic Operators in Python
work:

Python3
-------

\# Examples of Arithmetic Operatora = 9b = 4 \# Addition of numbersadd =
a + b \# Subtraction of numberssub = a - b \# Multiplication of
numbermul = a \* b \# Modulo of both numbermod = a % b \# Powerp = a
\*\* b \# print resultsprint(add)print(sub)print(mul)print(mod)print(p)

Output:

    13
    5
    36
    1
    6561

Note: Refer to Differences between / and // for some interesting facts
about these two operators.

Comparison Operators in Python
------------------------------

In Python Comparison of Relational operators compares the values. It
either returns True or False according to the condition.

OperatorDescriptionSyntax\>Greater than: True if the left operand is
greater than the rightx \> y=Greater than or equal to True if the left
operand is greater than or equal to the rightx \>= y\<=Less than or
equal to True if the left operand is less than or equal to the rightx
\<= y

= is an assignment operator and == comparison operator.

Precedence of Comparison Operators in Python
--------------------------------------------

In python, the comparison operators have lower precedence than the
arithmetic operators. All the operators within comparison operators have
same precedence order.

Example of Comparison Operators in Python
-----------------------------------------

Let's see an example of Comparision Operators in Python.

Python3
-------

\# Examples of Relational Operatorsa = 13b = 33 \# a \> b is
Falseprint(a \> b) \# a \< b is Trueprint(a \< b) \# a == b is
Falseprint(a == b) \# a != b is Trueprint(a != b) \# a \>= b is
Falseprint(a \>= b) \# a \<= b is Trueprint(a \<= b)

    False
    True
    False
    True
    False
    True

Logical Operators in Python
---------------------------

Python Logical operators perform Logical AND, Logical OR, and Logical
NOT operations. It is used to combine conditional statements.

OperatorDescriptionSyntaxandLogical AND: True if both the operands are
truex and yorLogical OR: True if either of the operands is true x or
ynotLogical NOT: True if the operand is false not x

Precedence of Logical Operators in Python
-----------------------------------------

The precedence of Logical Operators in python is as follows:

Logical not

logical and

logical or

Example of Logical Operators in Python
--------------------------------------

The following code shows how to implement Logical Operators in Python:

Python3
-------

\# Examples of Logical Operatora = Trueb = False \# Print a and b is
Falseprint(a and b) \# Print a or b is Trueprint(a or b) \# Print not a
is Falseprint(not a)

    False
    True
    False

Bitwise Operators in Python
---------------------------

Python Bitwise operators act on bits and perform bit-by-bit operations.
These are used to operate on binary numbers.

OperatorDescriptionSyntax&Bitwise ANDx & y\|Bitwise ORx \| y\~Bitwise
NOT\~x\^Bitwise XORx \^ y\>\>Bitwise right shiftx\>\>\<Precedence of
Bitwise Operators in Python

The precedence of Bitwise Operators in python is as follows:

Bitwise NOT

Bitwise Shift

Bitwise AND

Bitwise XOR

Bitwise OR

Bitwise Operators in Python
---------------------------

Here is an example showing how Bitwise Operators in Python work:

Python3
-------

\# Examples of Bitwise operatorsa = 10b = 4 \# Print bitwise AND
operationprint(a & b) \# Print bitwise OR operationprint(a \| b) \#
Print bitwise NOT operationprint(\~a) \# print bitwise XOR
operationprint(a \^ b) \# print bitwise right shift operationprint(a
\>\> 2) \# print bitwise left shift operationprint(a \<\< 2)

    0
    14
    -11
    14
    2
    40

Assignment Operators in Python
------------------------------

Python Assignment operators are used to assign values to the variables.

OperatorDescriptionSyntax=Assign the value of the right side of the
expression to the left side operand x = y + z+=Add AND: Add right-side
operand with left-side operand and then assign to left operanda+=b    
a=a+b-=Subtract AND: Subtract right operand from left operand and then
assign to left operanda-=b     a=a-b\*=Multiply AND: Multiply right
operand with left operand and then assign to left operanda\*=b    
a=a\*b/=Divide AND: Divide left operand with right operand and then
assign to left operanda/=b     a=a/b%=Modulus AND: Takes modulus using
left and right operands and assign the result to left operanda%=b    
a=a%b//=Divide(floor) AND: Divide left operand with right operand and
then assign the value(floor) to left operanda//=b    
a=a//b\*\*=Exponent AND: Calculate exponent(raise power) value using
operands and assign value to left operanda\*\*=b     a=a\*\*b&=Performs
Bitwise AND on operands and assign value to left operanda&=b    
a=a&b\|=Performs Bitwise OR on operands and assign value to left
operanda\|=b     a=a\|b\^=Performs Bitwise xOR on operands and assign
value to left operanda\^=b     a=a\^b\>\>=Performs Bitwise right shift
on operands and assign value to left operanda\>\>=b    
a=a\>\>b\<\<=Performs Bitwise left shift on operands and assign value to
left operanda \<\<= b     a= a \<\< b

Assignment Operators in Python
------------------------------

Let's see an example of Assignment Operators in Python.

Python3
-------

\# Examples of Assignment Operatorsa = 10 \# Assign valueb =
aprint(b) \# Add and assign valueb += aprint(b) \# Subtract and assign
valueb -= aprint(b) \# multiply and assignb \*= aprint(b) \# bitwise
lishift operatorb \<\<= aprint(b)

    10
    20
    10
    100
    102400

Identity Operators in Python
----------------------------

In Python, is and is not are the identity operators both are used to
check if two values are located on the same part of the memory. Two
variables that are equal do not imply that they are identical. 

    is          True if the operands are identical 
    is not      True if the operands are not identical 

Example Identity Operators in Python
------------------------------------

Let's see an example of Identity Operators in Python.

Python3
-------

a = 10b = 20c = a print(a is not b)print(a is c)

    True
    True

Membership Operators in Python
------------------------------

In Python, in and not in are the membership operators that are used to
test whether a value or variable is in a sequence.

    in            True if value is found in the sequence
    not in        True if value is not found in the sequence

Examples of Membership Operators in Python
------------------------------------------

The following code shows how to implement Membership Operators in
Python:

Python3
-------

\# Python program to illustrate\# not \'in\' operatorx = 24y = 20list =
\[10, 20, 30, 40, 50\] if (x not in list):    print(\"x is NOT present
in given list\")else:    print(\"x is present in given list\") if (y in
list):    print(\"y is present in given list\")else:    print(\"y is NOT
present in given list\")

    x is NOT present in given list
    y is present in given list

Ternary Operator in Python
--------------------------

in Python, Ternary operators also known as conditional expressions are
operators that evaluate something based on a condition being true or
false. It was added to Python in version 2.5. 

It simply allows testing a condition in a single line replacing the
multiline if-else making the code compact.

Syntax :  \[on\_true\] if \[expression\] else \[on\_false\] 

Examples of Ternary Operator in Python
--------------------------------------

Here is a simple example of Ternary Operator in Python.

Python3
-------

\# Program to demonstrate conditional operatora, b = 10, 20 \# Copy
value of a in min if a \< b else copy bmin = a if a \< b else
b print(min)

Output: 

    10

Precedence and Associativity of Operators in Python
---------------------------------------------------

In Python, Operator precedence and associativity determine the
priorities of the operator.

Operator Precedence in Python
-----------------------------

This is used in an expression with more than one operator with different
precedence to determine which operation to perform first.

Let's see an example of how Operator Precedence in Python works:

Python3
-------

\# Examples of Operator Precedence \# Precedence of \'+\' & \'\*\'expr =
10 + 20 \* 30print(expr) \# Precedence of \'or\' & \'and\'name =
\"Alex\"age = 0 if name == \"Alex\" or name == \"John\" and age \>=
2:    print(\"Hello! Welcome.\")else:    print(\"Good Bye!!\")

    610
    Hello! Welcome.

Operator Associativity in Python
--------------------------------

If an expression contains two or more operators with the same precedence
then Operator Associativity is used to determine. It can either be Left
to Right or from Right to Left.

The following code shows hoe Operator Associativity in Python works:

Python3
-------

\# Examples of Operator Associativity \# Left-right associativity\# 100
/ 10 \* 10 is calculated as\# (100 / 10) \* 10 and not\# as 100 / (10 \*
10)print(100 / 10 \* 10) \# Left-right associativity\# 5 - 2 + 3 is
calculated as\# (5 - 2) + 3 and not\# as 5 - (2 + 3)print(5 - 2 + 3) \#
left-right associativityprint(5 - (2 + 3)) \# right-left associativity\#
2 \*\* 3 \*\* 2 is calculated as\# 2 \*\* (3 \*\* 2) and not\# as (2
\*\* 3) \*\* 2print(2 \*\* 3 \*\* 2)

    100.0
    6
    0
    512

To try your knowledge of Python Operators, you can take out the quiz on
Python Operators. 
