---
title: "Python Arrays
"
draft: false
menu:
sidebar:
name: "Python Arrays
"
parent: "Python"
weight: 32
---

Python Arrays
-------------



An array is a collection of items stored at contiguous memory locations.
The idea is to store multiple items of the same type together. This
makes it easier to calculate the position of each element by simply
adding an offset to a base value, i.e., the memory location of the first
element of the array (generally denoted by the name of the array).For
simplicity, we can think of an array a fleet of stairs where on each
step is placed a value (let's say one of your friends). Here, you can
identify the location of any of your friends by simply knowing the count
of the step they are on. Array can be handled in Python by a module
named array. They can be useful when we have to manipulate only a
specific data type values. A user can treat lists as arrays. However,
user cannot constraint the type of elements stored in a list. If you
create arrays using the array module, all elements of the array must be
of the same type.  

![](https://media.geeksforgeeks.org/wp-content/uploads/CommonArticleDesign1-min.png)

Creating a Array
----------------

Array in Python can be created by importing array module.
array(data\_type, value\_list) is used to create an array with data type
and value list specified in its arguments. 

Python3
-------

\# Python program to demonstrate\# Creation of Array \# importing
\"array\" for array creationsimport array as arr \# creating an array
with integer typea = arr.array(\'i\', \[1, 2, 3\]) \# printing original
arrayprint(\"The new created array is : \", end=\" \")for i in range(0,
3):    print(a\[i\], end=\" \")print() \# creating an array with double
typeb = arr.array(\'d\', \[2.5, 3.2, 3.3\]) \# printing original
arrayprint(\"\\nThe new created array is : \", end=\" \")for i in
range(0, 3):    print(b\[i\], end=\" \")

    The new created array is :  1 2 3 

    The new created array is :  2.5 3.2 3.3 

Output : 

    The new created array is :  1 2 3 
    The new created array is :  2.5 3.2 3.3 

Complexities for Creation of Arrays:
------------------------------------

Time Complexity: O(1)

Auxiliary Space: O(n)

Some of the data types are mentioned below which will help in creating
an array of different data types. 

![](https://media.geeksforgeeks.org/wp-content/uploads/CommonArticleDesign2-min.png)

Adding Elements to a Array
--------------------------

Elements can be added to the Array by using built-in insert() function.
Insert is used to insert one or more data elements into an array. Based
on the requirement, a new element can be added at the beginning, end, or
any given index of array. append() is also used to add the value
mentioned in its arguments at the end of the array.  

Python3
-------

\# Python program to demonstrate\# Adding Elements to a Array \#
importing \"array\" for array creationsimport array as arr \# array with
int typea = arr.array(\'i\', \[1, 2, 3\])  print(\"Array before
insertion : \", end=\" \")for i in range(0, 3):    print(a\[i\], end=\"
\")print() \# inserting array using\# insert() functiona.insert(1,
4) print(\"Array after insertion : \", end=\" \")for i in
(a):    print(i, end=\" \")print() \# array with float typeb =
arr.array(\'d\', \[2.5, 3.2, 3.3\]) print(\"Array before insertion : \",
end=\" \")for i in range(0, 3):    print(b\[i\], end=\" \")print() \#
adding an element using append()b.append(4.4) print(\"Array after
insertion : \", end=\" \")for i in (b):    print(i, end=\" \")print()

    Array before insertion :  1 2 3 
    Array after insertion :  1 4 2 3 
    Array before insertion :  2.5 3.2 3.3 
    Array after insertion :  2.5 3.2 3.3 4.4 

Output : 

    Array before insertion : 1 2 3 
    Array after insertion :  1 4 2 3 
    Array before insertion : 2.5 3.2 3.3 
    Array after insertion :  2.5 3.2 3.3 4.4 

Complexities for Adding elements to the Arrays:
-----------------------------------------------

Time Complexity: O(1)/O(n) ( O(1) -- for inserting elements at the end
of the array, O(n) -- for inserting elements at the beginning of the
array and to the full array

Auxiliary Space: O(1)

Accessing elements from the Array
---------------------------------

In order to access the array items refer to the index number. Use the
index operator \[ \] to access an item in a array. The index must be an
integer. 

Python3
-------

\# Python program to demonstrate\# accessing of element from list \#
importing array moduleimport array as arr \# array with int typea =
arr.array(\'i\', \[1, 2, 3, 4, 5, 6\]) \# accessing element of
arrayprint(\"Access element is: \", a\[0\]) \# accessing element of
arrayprint(\"Access element is: \", a\[3\]) \# array with float typeb =
arr.array(\'d\', \[2.5, 3.2, 3.3\]) \# accessing element of
arrayprint(\"Access element is: \", b\[1\]) \# accessing element of
arrayprint(\"Access element is: \", b\[2\])

    Access element is:  1
    Access element is:  4
    Access element is:  3.2
    Access element is:  3.3

Output : 

    Access element is:  1
    Access element is:  4
    Access element is:  3.2
    Access element is:  3.3

Complexities for accessing elements in the Arrays:
--------------------------------------------------

Time Complexity: O(1)

Auxiliary Space: O(1)

Removing Elements from the Array
--------------------------------

Elements can be removed from the array by using built-in remove()
function but an Error arises if element doesn't exist in the set.
Remove() method only removes one element at a time, to remove range of
elements, iterator is used. pop() function can also be used to remove
and return an element from the array, but by default it removes only the
last element of the array, to remove element from a specific position of
the array, index of the element is passed as an argument to the pop()
method.Note -- Remove method in List will only remove the first
occurrence of the searched element. 

Python3
-------

\# Python program to demonstrate\# Removal of elements in a Array \#
importing \"array\" for array operationsimport array \# initializing
array with array values\# initializes array with signed integersarr =
array.array(\'i\', \[1, 2, 3, 1, 5\]) \# printing original
arrayprint(\"The new created array is : \", end=\"\")for i in range(0,
5):    print(arr\[i\], end=\" \") print(\"\\r\") \# using pop() to
remove element at 2nd positionprint(\"The popped element is : \",
end=\"\")print(arr.pop(2)) \# printing array after poppingprint(\"The
array after popping is : \", end=\"\")for i in range(0,
4):    print(arr\[i\], end=\" \") print(\"\\r\") \# using remove() to
remove 1st occurrence of 1arr.remove(1) \# printing array after
removingprint(\"The array after removing is : \", end=\"\")for i in
range(0, 3):    print(arr\[i\], end=\" \")

    The new created array is : 1 2 3 1 5 
    The popped element is : 3
    The array after popping is : 1 2 1 5 
    The array after removing is : 2 1 5 

Output: 

    The new created array is : 1 2 3 1 5 
    The popped element is : 3
    The array after popping is : 1 2 1 5 
    The array after removing is : 2 1 5 

Complexities for Removing elements in the Arrays:
-------------------------------------------------

Time Complexity: O(1)/O(n) ( O(1) -- for removing elements at the end of
the array, O(n) -- for removing elements at the beginning of the array
and to the full array

Auxiliary Space: O(1)

Slicing of a Array
------------------

In Python array, there are multiple ways to print the whole array with
all the elements, but to print a specific range of elements from the
array, we use Slice operation. Slice operation is performed on array
with the use of colon(:). To print elements from beginning to a range
use \[:Index\], to print elements from end use \[:-Index\], to print
elements from specific Index till the end use \[Index:\], to print
elements within a range, use \[Start Index:End Index\] and to print
whole List with the use of slicing operation, use \[:\]. Further, to
print whole array in reverse order, use \[::-1\]. 

![](https://media.geeksforgeeks.org/wp-content/uploads/CommonArticleDesign3-min.png)

Python3
-------

\# Python program to demonstrate\# slicing of elements in a Array \#
importing array moduleimport array as arr \# creating a listl = \[1, 2,
3, 4, 5, 6, 7, 8, 9, 10\] a = arr.array(\'i\', l)print(\"Initial Array:
\")for i in (a):    print(i, end=\" \") \# Print elements of a range\#
using Slice operationSliced\_array = a\[3:8\]print(\"\\nSlicing elements
in a range 3-8: \")print(Sliced\_array) \# Print elements from a\#
pre-defined point to endSliced\_array = a\[5:\]print(\"\\nElements
sliced from 5th \"      \"element till the end:
\")print(Sliced\_array) \# Printing elements from\# beginning till
endSliced\_array = a\[:\]print(\"\\nPrinting all elements using slice
operation: \")print(Sliced\_array)

    Initial Array: 
    1 2 3 4 5 6 7 8 9 10 
    Slicing elements in a range 3-8: 
    array('i', [4, 5, 6, 7, 8])

    Elements sliced from 5th element till the end: 
    array('i', [6, 7, 8, 9, 10])

    Printing all elements using slice operation: 
    array('i', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

Searching element in a Array
----------------------------

In order to search an element in the array we use a python in-built
index() method. This function returns the index of the first occurrence
of value mentioned in arguments. 

Python3
-------

\# Python code to demonstrate\# searching an element in array  \#
importing array moduleimport array \# initializing array with array
values\# initializes array with signed integersarr = array.array(\'i\',
\[1, 2, 3, 1, 2, 5\]) \# printing original arrayprint(\"The new created
array is : \", end=\"\")for i in range(0, 6):    print(arr\[i\], end=\"
\") print(\"\\r\") \# using index() to print index of 1st occurrence of
2print(\"The index of 1st occurrence of 2 is : \",
end=\"\")print(arr.index(2)) \# using index() to print index of 1st
occurrence of 1print(\"The index of 1st occurrence of 1 is : \",
end=\"\")print(arr.index(1))

    The new created array is : 1 2 3 1 2 5 
    The index of 1st occurrence of 2 is : 1
    The index of 1st occurrence of 1 is : 0

Output:  

    The new created array is : 1 2 3 1 2 5 
    The index of 1st occurrence of 2 is : 1
    The index of 1st occurrence of 1 is : 0

Complexities for searching elements in the Arrays:
--------------------------------------------------

Time Complexity: O(n)

Auxiliary Space: O(1)

Updating Elements in a Array
----------------------------

In order to update an element in the array we simply reassign a new
value to the desired index we want to update. 

Python3
-------

\# Python code to demonstrate\# how to update an element in array \#
importing array moduleimport array \# initializing array with array
values\# initializes array with signed integersarr = array.array(\'i\',
\[1, 2, 3, 1, 2, 5\]) \# printing original arrayprint(\"Array before
updation : \", end=\"\")for i in range(0, 6):    print(arr\[i\], end=\"
\") print(\"\\r\") \# updating a element in a arrayarr\[2\] =
6print(\"Array after updation : \", end=\"\")for i in range(0,
6):    print(arr\[i\], end=\" \")print() \# updating a element in a
arrayarr\[4\] = 8print(\"Array after updation : \", end=\"\")for i in
range(0, 6):    print(arr\[i\], end=\" \")

    Array before updation : 1 2 3 1 2 5 
    Array after updation : 1 2 6 1 2 5 
    Array after updation : 1 2 6 1 8 5 

Output:

    Array before updation : 1 2 3 1 2 5 
    Array after updation : 1 2 6 1 2 5 
    Array after updation : 1 2 6 1 8 5 

Complexities for updating elements in the Arrays:
-------------------------------------------------

Time Complexity: O(n)

Auxiliary Space: O(1)

Counting Elements in a Array
----------------------------

In order to count elements in an array we need to use count method.

Python3
-------

import array \# Create an array of integersmy\_array =
array.array(\'i\', \[1, 2, 3, 4, 2, 5, 2\]) \# Count the number of
occurrences of the element 2 in the arraycount = my\_array.count(2) \#
Print the resultprint(\"Number of occurrences of 2:\", count)

    Number of occurrences of 2: 3

Complexities for counting elements in the Arrays:
-------------------------------------------------

Time Complexity: O(n)

Auxiliary Space: O(1)

Reversing Elements in a Array
-----------------------------

In order to reverse elements of an array we need to simply use reverse
method.

Python3
-------

import array \# Create an array of integersmy\_array =
array.array(\'i\', \[1, 2, 3, 4, 5\]) \# Print the original
arrayprint(\"Original array:\", \*my\_array) \# Reverse the array in
placemy\_array.reverse() \# Print the reversed arrayprint(\"Reversed
array:\", \*my\_array)

    Original array: 1 2 3 4 5
    Reversed array: 5 4 3 2 1

Complexities for reversing elements in the Arrays:
--------------------------------------------------

Time Complexity: O(n)

Space: O(1)

                                                                 Extend Element from Array
------------------------------------------------------------------------------------------

In the article,we will cover the python list extend() and try to
understand the Python list extend().

What is extend element from array?
----------------------------------

In Python, an array is used to store multiple values or elements of the
same datatype in a single variable. The extend() function is simply used
to attach an item from iterable to the end of the array. In simpler
terms, this method is used to add an array of values to the end of a
given or existing array.

Syntax of list extend()
-----------------------

The syntax of the extend() method:

    list.extend(iterable)

Here,all the element of iterable are added to the end of list1

Example 1:
----------

Python3
-------

\#Python program to demonstrate \# Adding Elements to a Array \#
importing \"array\" for array creations import array as arr \# array
with int type a = arr.array(\'i\', \[1, 2, 3,4,5\]) \#printing original
array print(\"The before array extend  : \", end =\" \") for i in range
(0, 5):       print (a\[i\], end =\" \")     print() \#creating an array
with using extend method a.extend(\[6,7,8,9,10\]) \#printing original
array print(\"\\nThe array after extend :\",end=\" \") for i in
range(0,10):        print(a\[i\],end=\" \")     print()

    The before array extend  :  1 2 3 4 5 

    The array after extend : 1 2 3 4 5 6 7 8 9 10 

Example 2:
----------

Python3
-------

\#Python program to demonstrate \# Creation of Array \# importing
\"array\" for array creations import array as arr \#creating an array
with integer type a=arr.array(\'i\',\[1,2,3,4,5,6\]) \# printing
original array print(\"The Before extend array is :\",end=\" \") for i
in range(0,6):       print(a\[i\],end=\" \")     print() \# creating an
array with using extend method a.extend(\[7,8,9,10,11,12\]) \# printing
original array print(\"\\nThe After extend array is :\",end=\" \") for i
in range(0,12):       print(a\[i\],end=\" \") print() \#array with float
type b = arr.array(\'d\', \[2.1,2.2,2.3,2.4,2.5,2.6\]) print(\"\\nThe
before extend array is :\",end=\" \") for i in
range(0,6):     print(b\[i\],end=\" \")   print() \#extend function
using pass the elemnts b.extend(\[2.6,2.7,2.8,2.9\]) print(\"\\nThe
after extend array is :\",end=\" \") for i in
range(0,9+1):     print(b\[i\],end=\" \")   print() 

    The Before extend array is : 1 2 3 4 5 6 

    The After extend array is : 1 2 3 4 5 6 7 8 9 10 11 12 

    The before extend array is : 2.1 2.2 2.3 2.4 2.5 2.6 

    The after extend array is : 2.1 2.2 2.3 2.4 2.5 2.6 2.6 2.7 2.8 2.9 

Complexities for extend element from array:
-------------------------------------------

Time Complexity: O(1)

Auxiliary Space: O(1)
