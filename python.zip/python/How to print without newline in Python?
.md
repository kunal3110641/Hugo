---
title: "How to print without newline in Python?
"
draft: false
menu:
sidebar:
name: "How to print without newline in Python?
"
parent: "Python"
weight: 13
---

How to print without newline in Python?
---------------------------------------



Generally, people switching from C/C++ to Python wonder how to print two
or more variables or statements without going into a new line in python.
Since the python print() function by default ends with a newline. Python
has a predefined format if you use print(a\_variable) then it will go to
the next line automatically.  

For example: 

Python3
-------

print(\"geeks\")print(\"geeksforgeeks\")

This will result in this: 

    geeks
    geeksforgeeks

But sometimes it may happen that we don't want to go to the next line
but want to print on the same line. So what we can do?  

For Example: 

    Input : [geeks,geeksforgeeks]
    Output : geeks geeksforgeeks

    Input : a = [1, 2, 3, 4]
    Output : 1 2 3 4 

The solution discussed here is totally dependent on the python version
you are using.  

Print without newline in Python 2.x
-----------------------------------

Python
------

\# Python 2 code for printing\# on the same line printing\# geeks and
geeksforgeeks\# in the same
line print(\"geeks\"),print(\"geeksforgeeks\") \# arraya = \[1, 2, 3,
4\] \# printing a element in same\# linefor i in
xrange(4):    print(a\[i\]),

    geeks geeksforgeeks
    1 2 3 4

Print without newline in Python 3.x
-----------------------------------

python3
-------

\# Python 3 code for printing\# on the same line printing\# geeks and
geeksforgeeks\# in the same line print(\"geeks\", end =\"
\")print(\"geeksforgeeks\") \# arraya = \[1, 2, 3, 4\] \# printing a
element in same\# linefor i in range(4):    print(a\[i\], end =\" \")

    geeks geeksforgeeks
    1 2 3 4 

Print without newline in Python 3.x without using for loop
----------------------------------------------------------

Python3
-------

\# Print without newline in Python 3.x without using for loop l = \[1,
2, 3, 4, 5, 6\] \# using \* symbol prints the list\# elements in a
single lineprint(\*l) \#This code is contributed by anuragsingh1022

    1 2 3 4 5 6

Print without newline Using Python sys module

To use the sys module, first, import the module sys using the import
keyword. Then, make use of the stdout.write() method available inside
the sys module, to print your strings.

It only works with string If you pass a number or a list, you will get a
TypeError.

Python3
-------

import sys sys.stdout.write(\"GeeksforGeeks \")sys.stdout.write(\"is
best website for coding!\")
