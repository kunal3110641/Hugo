---
title: "Python MySQL -- Select Query
"
draft: false
menu:
sidebar:
name: "Python MySQL -- Select Query
"
parent: "Python"
weight: 116
---

Python MySQL -- Select Query
----------------------------



Python Database API ( Application Program Interface ) is the Database
interface for the standard Python. This standard is adhered to by most
Python Database interfaces. There are various Database servers supported
by Python Database such as MySQL, GadFly, mySQL, PostgreSQL, Microsoft
SQL Server 2000, Informix, Interbase, Oracle, Sybase etc. To connect
with MySQL database server from Python, we need to import the
mysql.connector module. Below is a program to connect with MySQL
database geeks. 

Python
------

\# importing required libraryimport mysql.connector \# connecting to the
databasedataBase = mysql.connector.connect(                     host =
\"localhost\",                     user =
\"user\",                     passwd =
\"pswrd\",                     database = \"geeks\" ) \# preparing a
cursor objectcursorObject = dataBase.cursor() \# disconnecting from
serverdataBase.close()

The above program illustrates the connection with the MySQL database
geeks in which host-name is localhost, the username is user and password
is pswrd.

Select Query
------------

After connecting with the database in MySQL we can select queries from
the tables in it. Syntax:

In order to select particular attribute columns from a table, we write
the attribute names.

    SELECT attr1, attr2 FROM table_name

In order to select all the attribute columns from a table, we use the
asterisk '\*' symbol.

    SELECT * FROM table_name

Example 1: Let's consider the table looks like this -- Below is a
program to select a query from the table in the database. 

![python-mysql-select](https://media.geeksforgeeks.org/wp-content/uploads/20200304185953/python-mysql-select.png)

Python
------

\# importing required libraryimport mysql.connector   \# connecting to
the databasedataBase = mysql.connector.connect(                     host
= \"localhost\",                     user =
\"user\",                     passwd =
\"pswrd\",                     database = \"geeks\" )   \# preparing a
cursor objectcursorObject = dataBase.cursor()   print(\"Displaying NAME
and ROLL columns from the STUDENT table:\") \# selecting queryquery =
\"SELECT NAME, ROLL FROM STUDENT\"cursorObject.execute(query) myresult =
cursorObject.fetchall() for x in myresult:    print(x) \# disconnecting
from serverdataBase.close()

Output: Example 2: Let us look at another example for selecting queries
in a table. 

![python-mysql-select-2](https://media.geeksforgeeks.org/wp-content/uploads/20200304190126/python-mysql-select-2.png)

Python
------

\# importing required libraryimport mysql.connector   \# connecting to
the databasedataBase = mysql.connector.connect(                     host
= \"localhost\",                     user =
\"user\",                     passwd =
\"pswrd\",                     database = \"geeks\" )    \# preparing a
cursor objectcursorObject = dataBase.cursor()   print(\"Displaying NAME
and ROLL columns from the STUDENT table:\") \# selecting queryquery =
\"SELECT \* FROM STUDENT\"cursorObject.execute(query) myresult =
cursorObject.fetchall() for x in myresult:    print(x) \# disconnecting
from serverdataBase.close()

Output:

![python-mysql-select-3](https://media.geeksforgeeks.org/wp-content/uploads/20200304190310/python-mysql-select-3.png)
