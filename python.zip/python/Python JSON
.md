---
title: "Python JSON
"
draft: false
menu:
sidebar:
name: "Python JSON
"
parent: "Python"
weight: 102
---

Python JSON
-----------



Python JSON JavaScript Object Notation is a format for structuring data.
It is mainly used for storing and transferring data between the browser
and the server. Python too supports JSON with a built-in package called
JSON. This package provides all the necessary tools for working with
JSON Objects including parsing, serializing, deserializing, and many
more. 

JSON Example
------------

Let's see a simple example where we convert the JSON objects to Python
objects and vice versa.

Convert from JSON to Python object
----------------------------------

Let's see a simple example where we convert the JSON objects to Python
objects. Here, json.loads() method can be used to parse a valid JSON
string and convert it into a Python Dictionary.

Python3
-------

import json  \# JSON stringemployee = \'{\"id\":\"09\", \"name\":
\"Nitin\", \"department\":\"Finance\"}\'print(\"This is JSON\",
type(employee))  print(\"\\nNow convert from JSON to Python\")  \#
Convert string to Python dictemployee\_dict =
json.loads(employee)print(\"Converted to Python\",
type(employee\_dict))print(employee\_dict)

Output:

    This is JSON 

    Now convert from JSON to Python
    Converted to Python 
    {'id': '09', 'name': 'Nitin', 'department': 'Finance'}

Convert from Python object to JSON
----------------------------------

Let's see a simple example where we convert Python objects to JSON
objects. Here json.dumps() function will convert a subset of Python
objects into a JSON string.

Python3
-------

import json  \# JSON stringemployee\_dict = {\'id\': \'09\', \'name\':
\'Nitin\', \'department\': \'Finance\'}print(\"This is Python\",
type(employee\_dict))  print(\"\\nNow Convert from Python to JSON\")  \#
Convert Python dict to JSONjson\_object = json.dumps(employee\_dict,
indent=4)print(\"Converted to JSON\",
type(json\_object))print(json\_object)

Output:

    This is Python 

    Now Convert from Python to JSON
    Converted to JSON 
    {
        "id": "09",
        "name": "Nitin",
        "department": "Finance"
    }

JSON in Python
--------------

This JSON Tutorial will help you learn the working of JSON with Python
from basics to advance, like parsing JSON, reading and writing to JSON
files, and serializing and deserializing JSON using a huge set of JSON
programs.

![JSON in
Python](https://media.geeksforgeeks.org/wp-content/uploads/20201125211352/PythonJSON.jpg)


------------------------

Reading and Writing JSON to a File in Python

Read JSON file using Python

Append to JSON file using Python

Parsing JSON
------------

How to Parse Data From JSON into Python?

How To Convert Python Dictionary To JSON?

Python -- Convert JSON to string

Ways to convert string to json object

Convert JSON data Into a Custom Python Object

Serializing and Deserializing JSON
----------------------------------

Serializing JSON in Python

json.dump() in Python

json.dumps() in Python

Python -- Difference between json.dump() and json.dumps()

Deserialize JSON to Object in Python

json.load() in Python

json.loads() in Python

Difference Between json.load() and json.loads()

Encoding and Decoding Custom Objects in Python-JSON

Serialize and Deserialize complex JSON in Python

Conversion between JSON
-----------------------

Python -- JSON to XML

Python -- XML to JSON

Convert CSV to JSON using Python

Convert multiple JSON files to CSV Python

Convert Text file to JSON in Python

Saving Text, JSON, and CSV to a File in Python

More operations JSON
--------------------

JSON Formatting in Python

Pretty Print JSON in Python

Flattening JSON objects in Python

Check whether a string is valid json or not

Sort JSON by value
