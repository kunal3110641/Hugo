---
title: "Collections.UserDict in Python
"
draft: false
menu:
sidebar:
name: "Collections.UserDict in Python
"
parent: "Python"
weight: 86
---

Collections.UserDict in Python
------------------------------



An unordered collection of data values that are used to store data
values like a map is known as Dictionary in Python. Unlike other Data
Types that hold only a single value as an element, Dictionary holds
key:value pair. Key-value is provided in the dictionary to make it more
optimized.

Note: For more information, refer to Python Dictionary

Collections.UserDict
--------------------

Python supports a dictionary like a container called UserDict present in
the collections module. This class acts as a wrapper class around the
dictionary objects. This class is useful when one wants to create a
dictionary of their own with some modified functionality or with some
new functionality. It can be considered as a way of adding new behaviors
to the dictionary. This class takes a dictionary instance as an argument
and simulates a dictionary that is kept in a regular dictionary. The
dictionary is accessible by the data attribute of this class.

Syntax: 

    collections.UserDict([initialdata])

Example 1:

Python3
-------

\# Python program to demonstrate\# userdict  from collections import
UserDict  d = {\'a\':1,    \'b\': 2,    \'c\': 3} \# Creating an
UserDictuserD = UserDict(d)print(userD.data)  \# Creating an empty
UserDictuserD = UserDict()print(userD.data)

Output:

    {'a': 1, 'b': 2, 'c': 3}
    {}

Example 2: Let's create a class inheriting from UserDict to implement a
customized dictionary.

Python3
-------

\# Python program to demonstrate\# userdict   from collections import
UserDict   \# Creating a Dictionary where\# deletion is not allowedclass
MyDict(UserDict):         \# Function to stop deletion    \# from
dictionary    def \_\_del\_\_(self):        raise
RuntimeError(\"Deletion not allowed\")             \# Function to stop
pop from    \# dictionary    def pop(self, s = None):        raise
RuntimeError(\"Deletion not allowed\")             \# Function to stop
popitem    \# from Dictionary    def popitem(self, s =
None):        raise RuntimeError(\"Deletion not allowed\")     \#
Driver\'s coded = MyDict({\'a\':1,    \'b\': 2,    \'c\':
3}) print(\"Original Dictionary\")print(d) d.pop(1)

Output:

    Original Dictionary
    {'a': 1, 'c': 3, 'b': 2}

    Traceback (most recent call last):
      File "/home/3ce2f334f5d25a3e24d10d567c705ce6.py", line 35, in 
        d.pop(1)
      File "/home/3ce2f334f5d25a3e24d10d567c705ce6.py", line 20, in pop
        raise RuntimeError("Deletion not allowed")
    RuntimeError: Deletion not allowed
    Exception ignored in: 
    Traceback (most recent call last):
      File "/home/3ce2f334f5d25a3e24d10d567c705ce6.py", line 15, in __del__
    RuntimeError: Deletion not allowed

 
