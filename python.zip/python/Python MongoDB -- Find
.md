---
title: "Python MongoDB -- Find
"
draft: false
menu:
sidebar:
name: "Python MongoDB -- Find
"
parent: "Python"
weight: 128
---

Python MongoDB -- Find
----------------------



MongoDB is a cross-platform document-oriented database program and the
most popular NoSQL database program. The term NoSQL means
non-relational. MongoDB stores the data in the form of key-value pairs.
It is an Open Source, Document Database which provides high performance
and scalability along with data modeling and data management of huge
sets of data in an enterprise application. MongoDB also provides the
feature of Auto-Scaling. It uses JSON-like documents, which makes the
database very flexible and scalable.

Finding data from the collection or the database
------------------------------------------------

In MongoDB, there are 2 functions that are used to find the data from
the collection or the database.

find\_one()

find()

Find\_one() Method 
-------------------

In MongoDB, to select data from the collection we use find\_one()
method. It returns the first occurred information in the selection and
brings backs as an output. find\_one() method accepts an optional
parameter filter that specifies the query to be performed and returns
the first occurrence of information from the database. 

Example 1: Find the first document from the student's a
collection/database. Let's suppose the database looks like as follows:

 

![python-mongodb-db1](https://media.geeksforgeeks.org/wp-content/uploads/20200226132249/python-mongodb-db1.png)

Python3
-------

\# Python program to demonstrate\# find\_one()  import
pymongo  mystudent = pymongo.MongoClient(\'localhost\', 27017) \# Name
of the databasemydb = mystudent\[\"gfg\"\] \# Name of the
collectionmycol = mydb\[\"names\"\] x = mycol.find\_one() print(x)

Output :

![python-mongodb-find-one1](https://media.geeksforgeeks.org/wp-content/uploads/20200226132638/python-mongodb-find-one1.png)

Find()
------

find() method is used to select data from the database. It returns all
the occurrences of the information stored in the collection. It has 2
types of parameters, The first parameter of the find() method is a query
object. In the below example we will use an empty Query object, which
will select all information from the collection. Note: It works the same
as SELECT\* without any parameter. 

Example: 

Python3
-------

import pymongo  \# establishing connection\# to the databasemy\_client =
pymongo.MongoClient(\'localhost\', 27017) \# Name of the databasemydb =
my\_client\[\"gfg\"\] \# Name of the collectionmynew =
mydb\[\"names\"\] for x in mycol.find():    print(x)

Output : The second parameter to the find() method is that you can
specify the field to include in the result. The second parameter passed
in the find() method is of object type describing the field. Thus, this
parameter is optional. If omitted then all the fields from the
collection/database will be displayed in the result. To include the
field in the result the value of the parameter passed should be 1, if
the value is 0 then it will be excluded from the result. 

![python-mongodb-find-2](https://media.geeksforgeeks.org/wp-content/uploads/20200226133152/python-mongodb-fond-2.png)

Example: Return only the names and address, not the id: 

![python-mongodb-3](https://media.geeksforgeeks.org/wp-content/uploads/20200226134151/python-mongodb-3.png)

Output: 
