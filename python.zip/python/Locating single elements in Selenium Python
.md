---
title: "Locating single elements in Selenium Python
"
draft: false
menu:
sidebar:
name: "Locating single elements in Selenium Python
"
parent: "Python"
weight: 138
---

Locating single elements in Selenium Python
-------------------------------------------



Locators Strategies in Selenium Python are methods that are used to
locate elements from the page and perform an operation on the same.
Selenium's Python Module is built to perform automated testing with
Python. Selenium Python bindings provide a simple API to write
functional/acceptance tests using Selenium WebDriver. After one has
installed selenium and checked out -- Navigating links using get method,
one might want to play more with Selenium Python. After opening a page
using selenium such as geeksforgeeks, the user might want to click some
buttons automatically or fill a form automatically or any such automated
task. This article revolves around Locating single elements in Selenium
Python.

Locator Strategies to locate single first elements
--------------------------------------------------

Note: find\_element\_by\_\*... has been deprecated and hence By class is
used now with find\_element. To know more: Visit here.

Selenium Python follows different locating strategies for elements. For
locating elements, you have to import By 

    from selenium.webdriver.common.by import By

One can locate an element in 8 different ways. Here is a list of
locating strategies for Selenium in python -- 

LocatorsDescriptionBy.IDThe first element with the id attribute value
matching the location will be returned.By.NAMEThe first element with the
name attribute value matching the location will be returned.By.XPATHThe
first element with the xpath syntax matching the location will be
returned.By.LINK\_TEXTThe first element with the link text value
matching the location will be returned.By.PARTIAL\_LINK\_TEXTThe first
element with the partial link text value matching the location will be
returned.By.TAG\_NAMEThe first element with the given tag name will be
returned.By.CLASS\_NAMEthe first element with the matching class
attribute name will be returned.By.CSS\_SELECTORThe first element with
the matching CSS selector will be returned.

By.ID
-----

With this strategy, the first element with the id attribute value
matching the location will be returned. If no element has a matching id
attribute, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.ID, "id_of_element")

Example: For instance, consider this page source: 

html
----

 

  

           

 

Now after you have created a driver, you can grab an element using --

    login_form = driver.find_element(By.ID, 'loginForm')

Note -- find\_element\_by\_id() has been deprecated.

By.NAME
-------

With this strategy, the first element with the name attribute value
matching the location will be returned. If no element has a matching
name attribute, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.NAME, "name_of_element")

Example: For instance, consider this page source: 

html
----

 

  

           

 

Now after you have created a driver, you can grab an element using --

    element = driver.find_element(By.NAME, 'username')

Note -- find\_element\_by\_name() has been deprecated.

By.XPATH
--------

With this strategy, the first element with pattern of xpath matching the
location will be returned. If no element has a matching element
attribute, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.XPATH, "xpath")

Example -- For instance, consider this page source: 

html
----

 

  

           

 

Now after you have created a driver, you can grab an element using:

    login_form = driver.find_element(By.XPATH, "/html/body/form[1]")
    login_form = driver.find_element(By.XPATH, "//form[1]")

Note -- find\_element\_by\_xpath() has been deprecated.

By.LINK\_TEXT
-------------

With this strategy, the first element with the link text value matching
the location will be returned. If no element has a matching link text
attribute, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.LINK_TEXT, "Text of Link")

Example: For instance, consider this page source: 

html
----

 

  

Are you sure you want to do this?

  [Continue](continue.html)  [Cancel](cancel.html)

Now after you have created a driver, you can grab an element using

    login_form = driver.find_element(By.LINK_TEXT, 'Continue')

Note -- find\_element\_by\_link\_text() has been deprecated.

By.PARTIAL\_LINK\_TEXT
----------------------

With this strategy, the first element with the partial link text value
matching the location will be returned. If no element has a matching
partial link text attribute, a NoSuchElementException will be raised.

Syntax: 

    driver.find_element(By.PARTIAL_LINK_TEXT, "Text of Link")

Example: For instance, consider this page source: 

html
----

 

  

Are you sure you want to do this?

  [Continue](continue.html)  [Cancel](cancel.html)

Now after you have created a driver, you can grab an element using --

    login_form = driver.find_element(By.PARTIAL_LINK_TEXT, 'Conti')

Note -- find\_element\_by\_partial\_link\_text()  has been deprecated.

By.TAG\_NAME
------------

With this strategy, the first element with the given tag name will be
returned. If no element has a matching tag name, a
NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.TAG_NAME, "Tag name")

Example: For instance, consider this page source: 

html
----

 

  

Welcome
=======

  

Site content goes here.

Now after you have created a driver, you can grab an element using --

    login_form = driver.find_element(By.TAG_NAME, 'h1')

Note -- find\_element\_by\_tag\_name()  has been deprecated.

By.CLASS\_NAME
--------------

With this strategy, the first element with the matching class attribute
name will be returned. If no element has a matching class attribute
name, a NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.CLASS_NAME, "class_of_element")

Example: For instance, consider this page source: 

html
----

 

  

Site content goes here.

Now after you have created a driver, you can grab an element using --

    content = driver.find_element(By.CLASS_NAME, 'content')

Note -- find\_element\_by\_class\_name() has been deprecated.

By.CSS\_SELECTOR
----------------

With this strategy, the first element with the matching CSS selector
will be returned. If no element has a matching CSS selector, a
NoSuchElementException will be raised. 

Syntax: 

    driver.find_element(By.CSS_SELECTOR, "CSS Selectors")

Example: For instance, consider this page source: 

html
----

 

  

Site content goes here.

Now after you have created a driver, you can grab an element using --

    content = driver.find_element(By.CSS_SELECTOR, 'p.content')

Note: find\_element\_by\_css\_selector() has been deprecated.
