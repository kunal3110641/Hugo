---
title: "Python MySQL -- Limit Clause
"
draft: false
menu:
sidebar:
name: "Python MySQL -- Limit Clause
"
parent: "Python"
weight: 122
---

Python MySQL -- Limit Clause
----------------------------



A connector is employed when we have to use MySQL with other programming
languages. The work of mysql-connector is to provide access to MySQL
Driver to the required language. Thus, it generates a connection between
the programming language and MySQL Server.

Python-MySQL-Connector
----------------------

This is a MySQL Connector that allows Python to access MySQL Driver and
implement SQL queries in its programming facility. Here we will try
implementing Limit clause on our Database and will study the output
generated.

LIMIT Clause Of SQL
-------------------

The Limit clause is used in SQL to control or limit the number of
records in the result set returned from the query generated. By default,
SQL gives out the required number of records starting from the top but
it allows the use of OFFSET keyword. OFFSET allows you to start from a
custom row and get the required number of result rows. 

Syntax:

    SELECT * FROM tablename LIMIT limit;

    SELECT * FROM tablename LIMIT limit OFFSET offset;

The following programs will help you understand this better. DATABASE IN
USE:  

![python-join-db22](https://media.geeksforgeeks.org/wp-content/uploads/20200316195500/python-join-db22.png)

Example 1: program to display only 2 records 

Python3
-------

import mysql.connector  \# Connecting to the databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor() \# STUDENT and
STudent are\# two different databasestatement =\"SELECT \* FROM STUDENT
LIMIT 2\" cs.execute(statement)result\_set = cs.fetchall() for x in
result\_set:    print(x)

OUTPUT:  

![python-limit-1](https://media.geeksforgeeks.org/wp-content/uploads/20200316195644/python-limit-1.png)

Example 2:program to start from the second record and display the first
two records 

Python3
-------

import mysql.connector  \# Connecting to the databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor() \# STUDENT and
STudent are\# two different databasestatement =\"SELECT \* FROM STUDENT
LIMIT 2 OFFSET 1\" cs.execute(statement)result\_set = cs.fetchall() for
x in result\_set:    print(x)

OUTPUT:

![python-limit-2](https://media.geeksforgeeks.org/wp-content/uploads/20200316195737/python-limit-2.png)
