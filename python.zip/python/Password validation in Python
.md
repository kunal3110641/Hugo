---
title: "Password validation in Python
"
draft: false
menu:
sidebar:
name: "Password validation in Python
"
parent: "Python"
weight: 77
---

Password validation in Python
-----------------------------



Let's take a password as a combination of alphanumeric characters along
with special characters, and check whether the password is valid or not
with the help of few conditions. Conditions for a valid password are:

Should have at least one number.

Should have at least one uppercase and one lowercase character.

Should have at least one special symbol.

Should be between 6 to 20 characters long.

    Input :  Geek12#
    Output : Password is valid.

    Input :  asd123
    Output : Invalid Password !!

We can check if a given string is eligible to be a password or not using
multiple ways. Method \#1: Naive Method (Without using Regex). 

Python3
-------

\# Password validation in Python\# using naive method \# Function to
validate the passworddef password\_check(passwd):         SpecialSym
=\[\'\$\', \'@\', \'\#\', \'%\'\]    val = True         if len(passwd)
\< 6:        print(\'length should be at least 6\')        val =
False             if len(passwd) \> 20:        print(\'length should be
not be greater than 8\')        val = False             if not
any(char.isdigit() for char in passwd):        print(\'Password should
have at least one numeral\')        val = False             if not
any(char.isupper() for char in passwd):        print(\'Password should
have at least one uppercase letter\')        val = False             if
not any(char.islower() for char in passwd):        print(\'Password
should have at least one lowercase letter\')        val =
False             if not any(char in SpecialSym for char in
passwd):        print(\'Password should have at least one of the symbols
\$@\#\')        val = False    if val:        return val \# Main
methoddef main():    passwd = \'Geek12@\'         if
(password\_check(passwd)):        print(\"Password is
valid\")    else:        print(\"Invalid Password !!\")         \#
Driver Code       if \_\_name\_\_ == \'\_\_main\_\_\':    main()

    Password is valid

This code used boolean functions to check if all the conditions were
satisfied or not. We see that though the complexity of the code is
basic, the length is considerable.   Method \#2: Using regex compile()
method of Regex module makes a Regex object, making it possible to
execute regex functions onto the pat variable. Then we check if the
pattern defined by pat is followed by the input string passwd. If so,
the search method returns true, which would allow the password to be
valid. 

Python3
-------

\# importing re libraryimport re def main():    passwd =
\'Geek12@\'    reg =
\"\^(?=.\*\[a-z\])(?=.\*\[A-Z\])(?=.\*\\d)(?=.\*\[@\$!%\*\#?&\])\[A-Za-z\\d@\$!\#%\*?&\]{6,20}\$\"         \#
compiling regex    pat = re.compile(reg)         \# searching
regex                    mat = re.search(pat, passwd)         \#
validating conditions    if mat:        print(\"Password is
valid.\")    else:        print(\"Password invalid !!\") \# Driver
Code    if \_\_name\_\_ == \'\_\_main\_\_\':    main()

    Password is valid.

Using ascii values and for loop:

This code uses a function that checks if a given password satisfies
certain conditions. It uses a single for loop to iterate through the
characters in the password string, and checks if the password contains
at least one digit, one uppercase letter, one lowercase letter, and one
special symbol from a predefined list and based on ascii values. It sets
a boolean variable "val" to True if all these conditions are satisfied,
and returns "val" at the end of the function.

The time complexity of this code is O(n), where n is the length of the
password string. The space complexity is O(1), as the size of the
variables used in the function does not depend on the size of the input.

Python3
-------

def password\_check(passwd):    SpecialSym =\[\'\$\', \'@\', \'\#\',
\'%\'\]    val = True    if len(passwd) \< 6:        print(\'length
should be at least 6\')        val = False    if len(passwd) \>
20:        print(\'length should be not be greater than 8\')        val
= False     \# Check if password contains at least one digit, uppercase
letter, lowercase letter, and special symbol    has\_digit =
False    has\_upper = False    has\_lower = False    has\_sym =
False    for char in passwd:        if ord(char) \>= 48 and ord(char)
\<= 57:            has\_digit = True        elif ord(char) \>= 65 and
ord(char) \<= 90:            has\_upper = True        elif ord(char) \>=
97 and ord(char) \<= 122:            has\_lower = True        elif char
in SpecialSym:            has\_sym = True     if not
has\_digit:        print(\'Password should have at least one
numeral\')        val = False    if not
has\_upper:        print(\'Password should have at least one uppercase
letter\')        val = False    if not
has\_lower:        print(\'Password should have at least one lowercase
letter\')        val = False    if not has\_sym:        print(\'Password
should have at least one of the symbols \$@\#\')        val =
False     return valprint(password\_check(\'Geek12@\')) \# should return
Trueprint(password\_check(\'asd123\')) \# should return
Falseprint(password\_check(\'HELLOworld\')) \# should return
Falseprint(password\_check(\'helloWORLD123@\')) \# should return
Trueprint(password\_check(\'HelloWORLD123\')) \# should return
False\#This code is contributed by Edula Vinay Kumar Reddy

    True
    Password should have at least one uppercase letter
    Password should have at least one of the symbols $@#
    False
    Password should have at least one numeral
    Password should have at least one of the symbols $@#
    False
    True
    Password should have at least one of the symbols $@#
    False
