---
title: "Python MySQL -- Update Query
"
draft: false
menu:
sidebar:
name: "Python MySQL -- Update Query
"
parent: "Python"
weight: 121
---

Python MySQL -- Update Query
----------------------------



A connector is employed when we have to use MySQL with other programming
languages. The work of MySQL-connector is to provide access to MySQL
Driver to the required language. Thus, it generates a connection between
the programming language and the MySQL Server.

Update Clause
-------------

The update is used to change the existing values in a database. By using
update a specific value can be corrected or updated. It only affects the
data and not the structure of the table.The basic advantage provided by
this command is that it keeps the table accurate.

Syntax:

    UPDATE tablename
    SET ="new value"
    WHERE ="old value";

The following programs will help you understand this better.DATABASE IN
USE:

![python-mysql-update](https://media.geeksforgeeks.org/wp-content/uploads/20200306180837/python-mysql-update.png)

Example 1: Program to update the age of student named Rishi Kumar.

\# Python program to demonstrate\# update clause    import
mysql.connector  \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor()  \# drop
clausestatement =\"UPDATE STUDENT SET AGE = 23 WHERE Name =\'Rishi
Kumar\'\"  cs.execute(statement)mydb.commit()  \# Disconnecting from the
databasemydb.close()

Output:

![python-mysql-update1](https://media.geeksforgeeks.org/wp-content/uploads/20200306181248/python-mysql-update1.png)

Example 2: Program to correct the spelling of an Student named SK

\# Python program to demonstrate\# update clause    import
mysql.connector  \# Connecting to the Databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor()  \# drop
clausestatement =\"UPDATE STUDENT SET Name = \'S.K. Anirban\' WHERE Name
=\'SK Anirban\'\"  cs.execute(statement)mydb.commit()  \# Disconnecting
from the databasemydb.close()

Output:

![python-mysql-update2](https://media.geeksforgeeks.org/wp-content/uploads/20200306181526/python-mysql-update2.png)