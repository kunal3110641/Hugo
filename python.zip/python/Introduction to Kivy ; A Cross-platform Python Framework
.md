---
title: "Introduction to Kivy ; A Cross-platform Python Framework
"
draft: false
menu:
sidebar:
name: "Introduction to Kivy ; A Cross-platform Python Framework
"
parent: "Python"
weight: 143
---

Introduction to Kivy ; A Cross-platform Python Framework
--------------------------------------------------------



Kivy is an open-source, cross-platform Python framework used for
developing multi-touch applications with a natural user interface. It
allows developers to build applications that run on multiple platforms,
including Windows, macOS, Linux, iOS, and Android.

Kivy is based on the Model-View-Controller (MVC) architecture and uses a
declarative language to define the user interface. The framework
provides a set of widgets and tools for creating dynamic and responsive
user interfaces, including buttons, labels, text inputs, and more.

One of the main features of Kivy is its support for touch and gesture
input, making it well-suited for developing applications for touch-based
devices like smartphones and tablets. Kivy also supports other input
methods such as mouse, keyboard, and gamepad.

Kivy is built using OpenGL, which provides fast graphics rendering and
enables developers to create visually appealing applications with smooth
animations and transitions.

Kivy is open-source and has an active community of developers who
contribute to the framework, provide support, and share resources like
tutorials and documentation.

Overall, Kivy is a powerful and versatile framework for building
cross-platform applications with a natural user interface, making it a
popular choice for developers looking to create multi-touch applications
that run on multiple platforms.

Kivy is a graphical user interface open-source Python library that
allows you to develop multi-platform applications on Windows, macOS,
Android, iOS, Linux, and Raspberry Pi. The best thing about kivy is, it
performs better than HTML5 cross-platform alternatives. 

Note that it is necessary to have Python 3 on your machine to make use
of the library.

Installation in Windows:  
--------------------------

Step 1: Update the pip and wheel before installing kivy by entering this
command in cmd-  

    python -m pip install --upgrade pip wheel setuptools

![](https://media.geeksforgeeks.org/wp-content/uploads/20201222202740/1.png)

Step 2: Install the dependencies-  

    python -m pip install docutils pygments pypiwin32 kivy.deps.sdl2 kivy.deps.glew
    python -m pip install kivy.deps.gstreamer
    python -m pip install kivy.deps.angle

Step 3: Install kivy.

    python -m pip install kivy

It will result in something like the below image:

![](https://media.geeksforgeeks.org/wp-content/uploads/20201222202743/2.png)

 

Installation in Linux:  
------------------------

Step 1: Add the PPA by entering this command in terminal-  

     sudo add-apt-repository ppa:kivy-team/kivy

Step 2: Update your package list using your package manager-  

    sudo apt-get update

Step 3: Install Kivy  

    sudo apt-get install python3-kivy

Create an application 
----------------------

There are three steps of creating an application with kivy:

Inherit Kivy's App class which represents the window for our widgets

Create a build() method, which will show the content of the widgets.

And at last calling of the run() method.  

Example : This is python3 code to make a simple application that shows
the desired text on the system's screen: 

Python3
-------

import kivykivy.require(\'1.10.0\')  from kivy.app import Appfrom
kivy.uix.button import Label  \# Inherit Kivy\'s App class which
represents the window\# for our widgets\# HelloKivy inherits all the
fields and methods\# from Kivyclass HelloKivy(App):      \# This returns
the content we want in the window    def build(self):          \# Return
a label widget with Hello Kivy        return Label(text =\"Hello
Geeks\")  helloKivy = HelloKivy()helloKivy.run()

To run this code open cmd(terminal in Linux) and go through the
directory in which the code is saved and type this command-  

    python file_name.py

 

![](https://media.geeksforgeeks.org/wp-content/uploads/Screenshot-97-1.png)

Advantages of Kivy:
-------------------

Cross-platform: Kivy allows developers to create applications that run
on multiple platforms, including Windows, macOS, Linux, iOS, and
Android, which reduces development time and costs.

Natural user interface: Kivy is designed for touch-based devices and
provides support for touch and gesture input, making it easy to create
natural and intuitive user interfaces.

Open-source: Kivy is open-source, which means that it is free to use and
has an active community of developers who contribute to the framework,
provide support, and share resources like tutorials and documentation.

Fast graphics rendering: Kivy is built using OpenGL, which provides fast
graphics rendering and enables developers to create visually appealing
applications with smooth animations and transitions.

MVC architecture: Kivy is based on the Model-View-Controller (MVC)
architecture, which provides a structured approach to building
applications and separates the user interface from the underlying logic
and data.

Disadvantages of Kivy:
----------------------

Learning curve: Learning to use Kivy and its declarative language can
take time and effort, especially for developers who are new to the
framework.

Limited third-party libraries: Kivy has a limited number of third-party
libraries compared to other Python frameworks, which can make it
difficult to find specific features or tools.

Limited community support: While Kivy has an active community of
developers, it is not as widely used as other Python frameworks, which
means that support and resources may be limited in some cases.

Performance issues: Kivy may have performance issues with complex
applications, especially on older or low-powered devices. Developers
need to pay attention to optimizing their code for performance to ensure
a smooth user experience. 
