---
title: "Errors and Exceptions in Python
"
draft: false
menu:
sidebar:
name: "Errors and Exceptions in Python
"
parent: "Python"
weight: 64
---

Errors and Exceptions in Python
-------------------------------



Errors are the problems in a program due to which the program will stop
the execution. On the other hand, exceptions are raised when some
internal events occur which changes the normal flow of the program. Two
types of Error occurs in python.  

Syntax errors

Logical errors (Exceptions)  

 

Syntax errors
-------------

When the proper syntax of the language is not followed then a syntax
error is thrown.Example  

Python3
-------

\# initialize the amount variableamount = 10000  \# check that You are
eligible to\#  purchase Dsa Self Paced or
notif(amount\>2999)    print(\"You are eligible to purchase Dsa Self
Paced\")     

Output: 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200616141640/python_syntax1.png)

It returns a syntax error message because after the if statement a
colon: is missing. We can fix this by writing the correct syntax. 

logical errors(Exception)
-------------------------

When in the runtime an error that occurs after passing the syntax test
is called exception or logical type. For example, when we divide any
number by zero then the ZeroDivisionError exception is raised, or when
we import a module that does not exist then ImportError is
raised.Example 1:  

Python3
-------

\# initialize the amount variablemarks = 10000  \# perform division with
0a = marks / 0print(a)

Output: 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200616143535/zerodivition.png)

In the above example the ZeroDivisionError as we are trying to divide a
number by 0.Example 2: When indentation is not correct.  

Python3
-------

if(a\<3):print(\"gfg\")

Output: 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200616161329/IE.png)

Some of the common built-in exceptions are other than above mention
exceptions are: 

 

ExceptionDescriptionIndexErrorWhen the wrong index of a list is
retrieved.AssertionErrorIt occurs when the assert statement
failsAttributeErrorIt occurs when an attribute assignment is
failed.ImportErrorIt occurs when an imported module is not
found.KeyErrorIt occurs when the key of the dictionary is not
found.NameErrorIt occurs when the variable is not defined.MemoryErrorIt
occurs when a program runs out of memory.TypeErrorIt occurs when a
function and operation are applied in an incorrect type.

Note: For more information, refer to Built-in Exceptions in Python 

Error Handling
--------------

When an error and an exception are raised then we handle that with the
help of the Handling method. 

Handling Exceptions with Try/Except/Finally We can handle errors by the
Try/Except/Finally method. we write unsafe code in the try, fall back
code in except and final code in finally block.Example  

Python3
-------

\# put unsafe operation in try blocktry:     print(\"code
start\")               \# unsafe operation perform     print(1 / 0)  \#
if error occur the it goes in except blockexcept:     print(\"an error
occurs\")  \# final code in finally
blockfinally:     print(\"GeeksForGeeks\")

Output:  

    code start
    an error occurs
    GeeksForGeeks

 

Raising exceptions for a predefined condition When we want to code for
the limitation of certain conditions then we can raise an
exception. Example  

Python3
-------

\# try for unsafe codetry:    amount = 1999    if amount \<
2999:                  \# raise the ValueError        raise
ValueError(\"please add money in your
account\")    else:        print(\"You are eligible to purchase DSA Self
Paced course\")              \# if false then raise the value
errorexcept ValueError as e:        print(e)

Output:  

    please add money in your account
