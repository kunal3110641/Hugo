---
title: "Collections.UserList in Python
"
draft: false
menu:
sidebar:
name: "Collections.UserList in Python
"
parent: "Python"
weight: 87
---

Collections.UserList in Python
------------------------------



Python Lists are array-like data structure but unlike it can be
homogeneous. A single list may contain DataTypes like Integers, Strings,
as well as Objects. List in Python are ordered and have a definite
count. The elements in a list are indexed according to a definite
sequence and the indexing of a list is done with 0 being the first
index. Note: For more information, refer to Python List 

Collections.UserList
--------------------

Python supports a List like a container called UserList present in the
collections module. This class acts as a wrapper class around the List
objects. This class is useful when one wants to create a list of their
own with some modified functionality or with some new functionality. It
can be considered as a way of adding new behaviors for the list. This
class takes a list instance as an argument and simulates a list that is
kept in a regular list. The list is accessible by the data attribute of
the this class.Syntax: 

    collections.UserList([list])

Example 1: 

Python3
-------

\# Python program to demonstrate\# userlist  from collections import
UserList  L = \[1, 2, 3, 4\] \# Creating a userlistuserL =
UserList(L)print(userL.data)  \# Creating empty userlistuserL =
UserList()print(userL.data)

Output: 

    [1, 2, 3, 4]
    []

The time complexity of this Python program is O(n), where n is the
length of the input list L.

 The auxiliary space used by this program is O(n), where n is the length
of the input list L. 

Python3
-------

\# Python program to demonstrate\# userlist   from collections import
UserList   \# Creating a List where\# deletion is not allowedclass
MyList(UserList):         \# Function to stop deletion    \# from
List    def remove(self, s = None):        raise RuntimeError(\"Deletion
not allowed\")             \# Function to stop pop from    \#
List    def pop(self, s = None):        raise RuntimeError(\"Deletion
not allowed\")     \# Driver\'s codeL = MyList(\[1, 2, 3,
4\]) print(\"Original List\") \# Inserting to
List\"L.append(5)print(\"After Insertion\")print(L) \# Deleting From
ListL.remove()

Output: 

    Original List
    After Insertion
    [1, 2, 3, 4, 5]

 

    Traceback (most recent call last):
      File "/home/9399c9e865a7493dce58e88571472d23.py", line 33, in 
        L.remove()
      File "/home/9399c9e865a7493dce58e88571472d23.py", line 15, in remove
        raise RuntimeError("Deletion not allowed")
    RuntimeError: Deletion not allowed

 
