---
title: "Types of inheritance Python
"
draft: false
menu:
sidebar:
name: "Types of inheritance Python
"
parent: "Python"
weight: 57
---

Types of inheritance Python
---------------------------



Inheritance is defined as the mechanism of inheriting the properties of
the base class to the child class. Here we a going to see the types of
inheritance in Python.

![Types of inheritance
Python](https://media.geeksforgeeks.org/wp-content/uploads/20220707180832/typesofinheritance.gif)

 

Types of Inheritance in Python
------------------------------

Types of Inheritance depend upon the number of child and parent classes
involved. There are four types of inheritance in Python:

Single Inheritance: 
--------------------

Single inheritance enables a derived class to inherit properties from a
single parent class, thus enabling code reusability and the addition of
new features to existing code.

![](https://media.geeksforgeeks.org/wp-content/uploads/20200108135809/inheritance11.png)

 

Example:

Python3
-------

\# Python program to demonstrate\# single inheritance \# Base classclass
Parent:    def func1(self):        print(\"This function is in parent
class.\") \# Derived class  class Child(Parent):    def
func2(self):        print(\"This function is in child class.\")  \#
Driver\'s codeobject = Child()object.func1()object.func2()

Output:

    This function is in parent class.
    This function is in child class.

Multiple Inheritance: 
----------------------

When a class can be derived from more than one base class this type of
inheritance is called multiple inheritances. In multiple inheritances,
all the features of the base classes are inherited into the derived
class. 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200108144424/multiple-inheritance1.png)

 

Example:

Python3
-------

\# Python program to demonstrate\# multiple inheritance \# Base
class1class Mother:    mothername = \"\"     def
mother(self):        print(self.mothername) \# Base class2  class
Father:    fathername = \"\"     def
father(self):        print(self.fathername) \# Derived class  class
Son(Mother, Father):    def parents(self):        print(\"Father :\",
self.fathername)        print(\"Mother :\", self.mothername)  \#
Driver\'s codes1 = Son()s1.fathername = \"RAM\"s1.mothername =
\"SITA\"s1.parents()

Output:

    Father : RAM
    Mother : SITA

Multilevel Inheritance :
------------------------

In multilevel inheritance, features of the base class and the derived
class are further inherited into the new derived class. This is similar
to a relationship representing a child and a grandfather. 

![](https://media.geeksforgeeks.org/wp-content/uploads/20200108144705/Multilevel-inheritance1.png)

 

Example:

Python3
-------

\# Python program to demonstrate\# multilevel inheritance \# Base
class  class Grandfather:     def \_\_init\_\_(self,
grandfathername):        self.grandfathername = grandfathername \#
Intermediate class  class Father(Grandfather):    def \_\_init\_\_(self,
fathername, grandfathername):        self.fathername =
fathername         \# invoking constructor of Grandfather
class        Grandfather.\_\_init\_\_(self, grandfathername) \# Derived
class  class Son(Father):    def \_\_init\_\_(self, sonname, fathername,
grandfathername):        self.sonname = sonname         \# invoking
constructor of Father class        Father.\_\_init\_\_(self, fathername,
grandfathername)     def print\_name(self):        print(\'Grandfather
name :\', self.grandfathername)        print(\"Father name :\",
self.fathername)        print(\"Son name :\", self.sonname)  \#  Driver
codes1 = Son(\'Prince\', \'Rampal\', \'Lal
mani\')print(s1.grandfathername)s1.print\_name()

Output:

    Lal mani
    Grandfather name : Lal mani
    Father name : Rampal
    Son name : Prince

Hierarchical Inheritance: 
--------------------------

When more than one derived class are created from a single base this
type of inheritance is called hierarchical inheritance. In this program,
we have a parent (base) class and two child (derived) classes.

![](https://media.geeksforgeeks.org/wp-content/uploads/20200108144949/Hierarchical-inheritance1.png)

 

Example:

Python3
-------

\# Python program to demonstrate\# Hierarchical inheritance  \# Base
classclass Parent:    def func1(self):        print(\"This function is
in parent class.\") \# Derived class1  class Child1(Parent):    def
func2(self):        print(\"This function is in child 1.\") \# Derivied
class2  class Child2(Parent):    def func3(self):        print(\"This
function is in child 2.\")  \# Driver\'s codeobject1 = Child1()object2 =
Child2()object1.func1()object1.func2()object2.func1()object2.func3()

Output:

    This function is in parent class.
    This function is in child 1.
    This function is in parent class.
    This function is in child 2.

Hybrid Inheritance: 
--------------------

Inheritance consisting of multiple types of inheritance is called hybrid
inheritance.

![](https://media.geeksforgeeks.org/wp-content/uploads/Hybrid-Inheritance.png)

 

Example:

Python3
-------

\# Python program to demonstrate\# hybrid inheritance  class
School:    def func1(self):        print(\"This function is in
school.\")  class Student1(School):    def
func2(self):        print(\"This function is in student 1. \")  class
Student2(School):    def func3(self):        print(\"This function is in
student 2.\")  class Student3(Student1, School):    def
func4(self):        print(\"This function is in student 3.\")  \#
Driver\'s codeobject = Student3()object.func1()object.func2()

Output:

    This function is in school.
    This function is in student 1.
