---
title: "Serializing JSON data in Python
"
draft: false
menu:
sidebar:
name: "Serializing JSON data in Python
"
parent: "Python"
weight: 106
---

Serializing JSON data in Python
-------------------------------



Serialization is the process of encoding the from naive data type to
JSON format. The Python module json converts a Python dictionary object
into JSON object, and list and tuple are converted into JSON array, and
int and float converted as JSON number, None converted as JSON null. 

![](https://media.geeksforgeeks.org/wp-content/uploads/20201125193115/Capture-660x274.PNG){width="660"}

Let's take a look at how we serialize Python data to JSON format with
these methods:

Dump().

Dumps().

json.dump()
-----------

json.dump() method can be used for writing to JSON file. Write data to a
file-like object in json format.

Syntax: json.dump(dict, file\_pointer)

Parameters:

dictionary -- name of dictionary which should be converted to JSON
object.

file pointer -- pointer of the file opened in write or append mode.

Below is the implementation:

Converting python object and writing into json file.

Python3
-------

\# import moduleimport json \# Data to be writtendata = {    \"user\":
{        \"name\": \"satyam kumar\",        \"age\":
21,        \"Place\": \"Patna\",        \"Blood group\": \"O+\"    }} \#
Serializing json and\# Writing json filewith open( \"datafile.json\" ,
\"w\" ) as write:    json.dump( data , write )

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/20201125190923/Capture1.PNG){width="843"}

data\_file.json

json.dumps()
------------

json.dumps() method can convert a Python object into a JSON string.

Syntax: json.dumps(dict)

Parameters:

dictionary -- name of dictionary which should be converted to JSON
object.

Below is the implementation:

Converting python object into json string.

Python3
-------

\# import moduleimport json \# Data to be writtendata = {    \"user\":
{        \"name\": \"satyam kumar\",        \"age\":
21,        \"Place\": \"Patna\",        \"Blood group\": \"O+\"    }} \#
Serializing jsonres = json.dumps( data )print( res )

 

 

Output:

 

![](https://media.geeksforgeeks.org/wp-content/uploads/20201125191430/Capture-660x37.PNG){width="660"}

 

 
