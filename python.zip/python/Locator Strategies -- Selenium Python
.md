---
title: "Locator Strategies -- Selenium Python
"
draft: false
menu:
sidebar:
name: "Locator Strategies -- Selenium Python
"
parent: "Python"
weight: 140
---

Locator Strategies -- Selenium Python
-------------------------------------



Locators Strategies in Selenium Python are methods that are used to
locate elements from the page and perform an operation on the same.
Selenium's Python Module is built to perform automated testing with
Python. Selenium Python bindings provides a simple API to write
functional/acceptance tests using Selenium WebDriver. After one has
installed selenium and checked out -- Navigating links using get method,
one might want to play more with Selenium Python. After opening a page
using selenium such as geeksforgeeks, one might want to click some
buttons automatically or fill a form automatically or any such automated
task. This article revolves around two strategies -- Locating Single
Elements and Location Multiple Elements.

![Locator-Strategies-Selenium-Python](https://media.geeksforgeeks.org/wp-content/uploads/20200417212249/Locator-Strategies-Selenium-Python.png)

Locator Strategies to locate single first elements
--------------------------------------------------

Selenium Python follows different locating strategies for elements. One
can locate a element in 8 different ways. Here is a list of locating
strategies for Selenium in python -- 

LocatorsDescriptionfind\_element\_by\_idThe first element with the id
attribute value matching the location will be
returned.find\_element\_by\_nameThe first element with the name
attribute value matching the location will be
returned.find\_element\_by\_xpathThe first element with the xpath syntax
matching the location will be returned.find\_element\_by\_link\_textThe
first element with the link text value matching the location will be
returned.find\_element\_by\_partial\_link\_textThe first element with
the partial link text value matching the location will be
returned.find\_element\_by\_tag\_nameThe first element with the given
tag name will be returned.find\_element\_by\_class\_namethe first
element with the matching class attribute name will be
returned.find\_element\_by\_css\_selectorThe first element with the
matching CSS selector will be returned.

Locator Strategies to locate multiple elements
----------------------------------------------

Selenium Python follows different locating strategies for elements. One
can locate multiple elements in 7 different ways. Here is a list of
locating strategies for Selenium in python --

LocatorsDescriptionfind\_elements\_by\_nameAll elements with name
attribute value matching the location will be
returned.find\_elements\_by\_xpathAll elements with xpath syntax
matching the location will be returned.find\_elements\_by\_link\_textAll
elements with link text value matching the location will be
returned.find\_elements\_by\_partial\_link\_textAll elements with
partial link text value matching the location will be
returned.find\_elements\_by\_tag\_nameAll elements with given tag name
will be returned.find\_elements\_by\_class\_nameAll elements with
matching class attribute name will be
returned.find\_elements\_by\_css\_selectorAll elements with matching CSS
selector will be returned.
