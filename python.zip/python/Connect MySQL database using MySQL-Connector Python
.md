---
title: "Connect MySQL database using MySQL-Connector Python
"
draft: false
menu:
sidebar:
name: "Connect MySQL database using MySQL-Connector Python
"
parent: "Python"
weight: 112
---

Connect MySQL database using MySQL-Connector Python
---------------------------------------------------



While working with Python we need to work with databases, they may be of
different types like MySQL, SQLite, NoSQL, etc. In this article, we will
be looking forward to how to connect MySQL databases using MySQL
Connector/Python.MySQL Connector module of Python is used to connect
MySQL databases with the Python programs, it does that using the Python
Database API Specification v2.0 (PEP 249). It uses the Python standard
library and has no dependencies. 

Connecting to the Database
--------------------------

The mysql.connector provides the connect() method used to create a
connection between the MySQL database and the Python application. The
syntax is given below.

Syntax:

    Conn_obj= mysql.connector.connect(host = , user = , passwd = )    

The connect() function accepts the following arguments.

Hostname -- It represents the server name or IP address on which MySQL
is running.Username -- It represents the name of the user that we use to
work with the MySQL server. By default, the username for the MySQL
database is root.Password -- The password is provided at the time of
installing the MySQL database. We don't need to pass a password if we
are using the root.Database -- It specifies the database name which we
want to connect. This argument is used when we have multiple databases. 

In the following example we will be connecting to MySQL database using
connect()Example: 

Python3
-------

\# Python program to connect\# to mysql database  import
mysql.connector  \# Connecting from the serverconn =
mysql.connector.connect(user =
\'username\',                               host =
\'localhost\',                              database =
\'database\_name\') print(conn) \# Disconnecting from the
serverconn.close()

Output: 

![python-mysql-connect-1](https://media.geeksforgeeks.org/wp-content/uploads/20200304152526/python-mysql-connect-1.png)

Also for the same, we can use connection.MySQLConnection() class instead
of connect():Example: 

Python3
-------

\# Python program to connect\# to mysql database  from mysql.connector
import connection \# Connecting to the serverconn =
connection.MySQLConnection(user =
\'username\',                              host =
\'localhost\',                              database =
\'database\_name\') print(conn) \# Disconnecting from the
serverconn.close()

Output: 

![python-mysql-connect-2](https://media.geeksforgeeks.org/wp-content/uploads/20200304152800/python-mysql-connect-2.png)

Another way is to pass the dictionary in the connect() function using
'\*\*' operator:Example: 

Python3
-------

\# Python program to connect\# to mysql database  from mysql.connector
import connection  dict = {  \'user\': \'root\',  \'host\':
\'localhost\',  \'database\': \'College\'} \# Connecting to the
serverconn = connection.MySQLConnection(\*\*dict) print(conn) \#
Disconnecting from the serverconn.close()

Output: 

![python-mysql-connect-3](https://media.geeksforgeeks.org/wp-content/uploads/20200304153027/python-mysql-connect-3.png)

 Example

Python3
-------

\# importing required librariesimport mysql.connector dataBase =
mysql.connector.connect(host =\"localhost\",user =\"user\",passwd
=\"gfg\") \# preparing a cursor objectcursorObject =
dataBase.cursor() \# creating databasecursorObject.execute(\"CREATE
DATABASE geeks4geeks\")

![](https://media.geeksforgeeks.org/wp-content/uploads/20230314214534/python-mysql-create-db.png)

 
