---
title: "Taking input in Python
"
draft: false
menu:
sidebar:
name: "Taking input in Python
"
parent: "Python"
weight: 09 
---


Taking input in Python
----------------------



Developers often have a need to interact with users, either to get data
or to provide some sort of result. Most programs today use a dialog box
as a way of asking the user to provide some type of input. While Python
provides us with two inbuilt functions to read the input from the
keyboard.  

input ( prompt )

raw\_input ( prompt )

input (): This function first takes the input from the user and converts
it into a string. The type of the returned object always will be . It
does not evaluate the expression it just returns the complete statement
as String. For example, Python provides a built-in function called input
which takes the input from the user. When the input function is called
it stops the program and waits for the user's input. When the user
presses enter, the program resumes and returns what the user typed. 

Syntax:

    inp = input('STATEMENT')
        
    Example:
    1.  >>> name = input('What is your name?\n')     # \n ---> newline  ---> It causes a line break
                >>> What is your name?
                Ram
                >>> print(name)
                Ram 
                
                # ---> comment in python

Python3
-------

\# Python program showing \# a use of input()  val = input(\"Enter your
value: \")print(val)

Output:

 

![](https://media.geeksforgeeks.org/wp-content/uploads/input1-4.png)

Taking String as an input:

Python3
-------

name = input(\'What is your name?\\n\')     \# \\n \-\--\> newline 
\-\--\> It causes a line breakprint(name)

Output:

    What is your name?
    Ram
    Ram

How the input function works in Python :  

When input() function executes program flow will be stopped until the
user has given input.

The text or message displayed on the output screen to ask a user to
enter an input value is optional i.e. the prompt, which will be printed
on the screen is optional.

Whatever you enter as input, the input function converts it into a
string. if you enter an integer value still input() function converts it
into a string. You need to explicitly convert it into an integer in your
code using typecasting. 

Code: 

Python3
-------

\# Program to check input \# type in Python  num = input (\"Enter number
:\")print(num)name1 = input(\"Enter name : \")print(name1)  \# Printing
type of input valueprint (\"type of number\", type(num))print (\"type of
name\", type(name1))

Output: 

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture4-10.png)

raw\_input(): This function works in older version (like Python 2.x).
This function takes exactly what is typed from the keyboard, converts it
to string, and then returns it to the variable in which we want to store
it.

Example:

Python
------

\# Python program showing\# a use of raw\_input()  g =
raw\_input(\"Enter your name : \")print g

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/Capture5-5.png)

 Here, g is a variable that will get the string value, typed by the user
during the execution of the program. Typing of data for the raw\_input()
function is terminated by enter key. We can use raw\_input() to enter
numeric data also. In that case, we use typecasting. For more details on
typecasting refer this. 

Note: input() function takes all the input as a string only

There are various function that are used to take as desired input few of
them are : --

int(input())

float(input())

Python3
-------

num = int(input(\"Enter a number: \"))print(num, \" \",
type(num))              floatNum = float(input(\"Enter a decimal number:
\"))print(floatNum, \" \", type(floatNum))

Output: 

![Output](https://media.geeksforgeeks.org/wp-content/uploads/20221222153421/intFloat.png)

Output

Refer to the article Taking list as input from the user for more
information. 
