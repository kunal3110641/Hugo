---
title: "Python Pandas Series
"
draft: false
menu:
sidebar:
name: "Python Pandas Series
"
parent: "Python"
weight: 101
---

Python Pandas Series
====================

Pandas Series is a one-dimensional labeled array capable of holding data
of any type (integer, string, float, python objects, etc.).

Pandas Series Examples
----------------------

Python3
-------


    # import pandas as pd
    import pandas as pd

    # simple array
    data = [1, 2, 3, 4]

    ser = pd.Series(data)
    print(ser)

Output :

    0    1
    1    2
    2    3
    3    4
    dtype: int64

The axis labels are collectively called index. Pandas Series is nothing
but a column in an excel sheet.Labels need not be unique but must be a
hashable type. The object supports both integer and label-based indexing
and provides a host of methods for performing operations involving the
index.

![Pandas
Series](https://media.geeksforgeeks.org/wp-content/uploads/dataSER-1.png){.alignnone
.size-full .wp-image-840686}

Python Pandas Series
--------------------

We will get a brief insight on all these basic operations which can be
performed on Pandas Series :

Creating a Series

Accessing element of Series

Indexing and Selecting Data in Series

Binary operation on Series

Conversion Operation on Series

Creating a Pandas Series
------------------------

In the real world, a Pandas Series will be created by loading the
datasets from existing storage, storage can be SQL Database, CSV file,
and Excel file. Pandas Series can be created from the lists, dictionary,
and from a scalar value etc. Series can be created in different ways,
here are some ways by which we create a series:

Creating a series from array: In order to create a series from array, we
have to import a numpy module and have to use array() function.

Python3
-------


    # import pandas as pd
    import pandas as pd

    # import numpy as np
    import numpy as np

    # simple array
    data = np.array(['g','e','e','k','s'])

    ser = pd.Series(data)
    print(ser)

Output :

 Creating a series from Lists:In order to create a series from list, we
have to first create a list after that we can create a series from list.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser1.jpg){.alignnone
.size-full .wp-image-836789 width="148" height="114"}


    import pandas as pd

    # a simple list
    list = ['g', 'e', 'e', 'k', 's']
     
    # create series form a list
    ser = pd.Series(list)
    print(ser)

Output :

For more details refer to Creating a Pandas Series 

![](https://media.geeksforgeeks.org/wp-content/uploads/ser1.jpg){.alignnone
.size-full .wp-image-836789 width="148" height="114"}

Accessing element of Series
---------------------------

There are two ways through which we can access element of series, they
are :

Accessing Element from Series with Position

Accessing Element Using Label (index)

Accessing Element from Series with Position : In order to access the
series element refers to the index number. Use the index operator \[ \]
to access an element in a series. The index must be an integer. In order
to access multiple elements from a series, we use Slice operation.

Accessing first 5 elements of Series


    # import pandas and numpy 
    import pandas as pd
    import numpy as np

    # creating simple array
    data = np.array(['g','e','e','k','s','f', 'o','r','g','e','e','k','s'])
    ser = pd.Series(data)
     
     
    #retrieve the first element
    print(ser[:5])

Output : Accessing Element Using Label (index) :In order to access an
element from series, we have to set values by index label. A Series is
like a fixed-size dictionary in that you can get and set values by index
label.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser6.jpg){.alignnone
.size-full .wp-image-836907 width="126" height="110"}

Accessing a single element using index label


    # import pandas and numpy 
    import pandas as pd
    import numpy as np

    # creating simple array
    data = np.array(['g','e','e','k','s','f', 'o','r','g','e','e','k','s'])
    ser = pd.Series(data,index=[10,11,12,13,14,15,16,17,18,19,20,21,22])
     
     
    # accessing a element using index element
    print(ser[16])

Output :

    o

For more details refer to Accessing element of Series 

Indexing and Selecting Data in Series
-------------------------------------

Indexing in pandas means simply selecting particular data from a Series.
Indexing could mean selecting all the data, some of the data from
particular columns. Indexing can also be known as Subset Selection.

Indexing a Series using indexing operator \[\] :Indexing operator is
used to refer to the square brackets following an object. The .loc and
.iloc indexers also use the indexing operator to make selections. In
this indexing operator to refer to df\[ \].

    # importing pandas module  
    import pandas as pd  
        
    # making data frame  
    df = pd.read_csv("nba.csv")  
      
    ser = pd.Series(df['Name']) 
    data = ser.head(10)
    data 

Now we access the element of series using index operator \[ \].

![](https://media.geeksforgeeks.org/wp-content/uploads/ser9.jpg){.alignnone
.size-full .wp-image-836977 width="210" height="199"}

    # using indexing operator
    data[3:6] 

Output : Indexing a Series using .loc\[ \] :This function selects data
by refering the explicit index . The df.loc indexer selects data in a
different way than just the indexing operator. It can select subsets of
data.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser13.jpg){.alignnone
.size-full .wp-image-839146 width="208" height="65"}

    # importing pandas module  
    import pandas as pd  
        
    # making data frame  
    df = pd.read_csv("nba.csv")  
      
    ser = pd.Series(df['Name']) 
    data = ser.head(10)
    data 

Now we access the element of series using .loc\[\] function.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser9.jpg){.alignnone
.size-full .wp-image-836977 width="210" height="199"}

    # using .loc[] function
    data.loc[3:6]

Output : Indexing a Series using .iloc\[ \] :This function allows us to
retrieve data by position. In order to do that, we'll need to specify
the positions of the data that we want. The df.iloc indexer is very
similar to df.loc but only uses integer locations to make its
selections.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser14.jpg){.alignnone
.size-full .wp-image-839168 width="207" height="93"}

    # importing pandas module  
    import pandas as pd  
        
    # making data frame  
    df = pd.read_csv("nba.csv")  
      
    ser = pd.Series(df['Name']) 
    data = ser.head(10)
    data 

Now we access the element of Series using .iloc\[\] function.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser9.jpg){.alignnone
.size-full .wp-image-836977 width="210" height="199"}

    # using .iloc[] function
    data.iloc[3:6]

Output : 

![](https://media.geeksforgeeks.org/wp-content/uploads/ser13.jpg){.alignnone
.size-full .wp-image-839146 width="208" height="65"}

Binary Operation on Series
--------------------------

We can perform binary operation on series like addition, subtraction and
many other operation. In order to perform binary operation on series we
have to use some function like .add(),.sub() etc..Code \#1:

    # importing pandas module  
    import pandas as pd  

    # creating a series
    data = pd.Series([5, 2, 3,7], index=['a', 'b', 'c', 'd'])

    # creating a series
    data1 = pd.Series([1, 6, 4, 9], index=['a', 'b', 'd', 'e'])

    print(data, "\n\n", data1)

Now we add two series using .add() function.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser15.jpg){.alignnone
.size-full .wp-image-839229 width="131" height="195"}

    # adding two series using
    # .add
    data.add(data1, fill_value=0)

Output :Code \#2:

![](https://media.geeksforgeeks.org/wp-content/uploads/ser16.jpg){.alignnone
.size-full .wp-image-839234 width="137" height="99"}

    # importing pandas module  
    import pandas as pd  

    # creating a series
    data = pd.Series([5, 2, 3,7], index=['a', 'b', 'c', 'd'])

    # creating a series
    data1 = pd.Series([1, 6, 4, 9], index=['a', 'b', 'd', 'e'])

    print(data, "\n\n", data1)

Now we subtract two series using .sub function.

![](https://media.geeksforgeeks.org/wp-content/uploads/ser15.jpg){.alignnone
.size-full .wp-image-839229 width="131" height="195"}

    # subtracting two series using
    # .sub
    data.sub(data1, fill_value=0)

Output :For more details refer to Binary operation methods on series 

![](https://media.geeksforgeeks.org/wp-content/uploads/ser17.jpg){.alignnone
.size-full .wp-image-839261 width="127" height="106"}

Conversion Operation on Series
------------------------------

In conversion operation we perform various operation like changing
datatype of series, changing a series to list etc. In order to perform
conversion operation we have various function which help in conversion
like .astype(), .tolist() etc.Code \#1:

    # Python program using astype
    # to convert a datatype of series

    # importing pandas module  
    import pandas as pd 
      
    # reading csv file from url  
    data = pd.read_csv("nba.csv") 
       
    # dropping null value columns to avoid errors 
    data.dropna(inplace = True) 
      
    # storing dtype before converting 
    before = data.dtypes 
      
    # converting dtypes using astype 
    data["Salary"]= data["Salary"].astype(int) 
    data["Number"]= data["Number"].astype(str) 
      
    # storing dtype after converting 
    after = data.dtypes 
      
    # printing to compare 
    print("BEFORE CONVERSION\n", before, "\n") 
    print("AFTER CONVERSION\n", after, "\n") 

Output : Code \#2:

![](https://media.geeksforgeeks.org/wp-content/uploads/ser18.jpg){.alignnone
.size-full .wp-image-839374 width="176" height="400"}

    # Python program converting
    # a series into list

    # importing pandas module  
    import pandas as pd  
      
    # importing regex module 
    import re 
        
    # making data frame  
    data = pd.read_csv("nba.csv")  
        
    # removing null values to avoid errors  
    data.dropna(inplace = True)  
      
    # storing dtype before operation 
    dtype_before = type(data["Salary"]) 
      
    # converting to list 
    salary_list = data["Salary"].tolist() 
      
    # storing dtype after operation 
    dtype_after = type(salary_list) 
      
    # printing dtype 
    print("Data type before converting = {}\nData type after converting = {}"
          .format(dtype_before, dtype_after)) 
      
    # displaying list 
    salary_list 

Output :

![](https://media.geeksforgeeks.org/wp-content/uploads/ser21.jpg){.alignnone
.size-full .wp-image-839406 width="519" height="489"}

Binary operation methods on series:

FunctionDescriptionadd()Method is used to add series or list like
objects with same length to the caller seriessub()Method is used to
subtract series or list like objects with same length from the caller
seriesmul()Method is used to multiply series or list like objects with
same length with the caller seriesdiv()Method is used to divide series
or list like objects with same length by the caller seriessum()Returns
the sum of the values for the requested axisprod()Returns the product of
the values for the requested axismean()Returns the mean of the values
for the requested axispow()Method is used to put each element of passed
series as exponential power of caller series and returned the
resultsabs()Method is used to get the absolute numeric value of each
element in Series/DataFramecov()Method is used to find covariance of two
series

 Pandas series method:

FunctionDescriptionSeries()A pandas Series can be created with the
Series() constructor method. This constructor method accepts a variety
of inputscombine\_first()Method is used to combine two series into
onecount()Returns number of non-NA/null observations in the
Seriessize()Returns the number of elements in the underlying
dataname()Method allows to give a name to a Series object, i.e. to the
columnis\_unique()Method returns boolean if values in the object are
uniqueidxmax()Method to extract the index positions of the highest
values in a Seriesidxmin()Method to extract the index positions of the
lowest values in a Seriessort\_values()Method is called on a Series to
sort the values in ascending or descending ordersort\_index()Method is
called on a pandas Series to sort it by the index instead of its
valueshead()Method is used to return a specified number of rows from the
beginning of a Series. The method returns a brand new Seriestail()Method
is used to return a specified number of rows from the end of a Series.
The method returns a brand new Seriesle()Used to compare every element
of Caller series with passed series.It returns True for every element
which is Less than or Equal to the element in passed seriesne()Used to
compare every element of Caller series with passed series. It returns
True for every element which is Not Equal to the element in passed
seriesge()Used to compare every element of Caller series with passed
series. It returns True for every element which is Greater than or Equal
to the element in passed serieseq()Used to compare every element of
Caller series with passed series. It returns True for every element
which is Equal to the element in passed seriesgt()Used to compare two
series and return Boolean value for every respective elementlt()Used to
compare two series and return Boolean value for every respective
elementclip()Used to clip value below and above to passed Least and Max
valueclip\_lower()Used to clip values below a passed least
valueclip\_upper()Used to clip values above a passed maximum
valueastype()Method is used to change data type of a
seriestolist()Method is used to convert a series to listget()Method is
called on a Series to extract values from a Series. This is alternative
syntax to the traditional bracket syntaxunique()Pandas unique() is used
to see the unique values in a particular columnnunique()Pandas nunique()
is used to get a count of unique valuesvalue\_counts()Method to count
the number of the times each unique value occurs in a
Seriesfactorize()Method helps to get the numeric representation of an
array by identifying distinct valuesmap()Method to tie together the
values from one object to anotherbetween()Pandas between() method is
used on series to check which values lie between first and second
argumentapply()Method is called and feeded a Python function as an
argument to use the function on every Series value. This method is
helpful for executing custom operations that are not included in pandas
or numpy
