---
title: "Inheritance in Python
"
draft: false
menu:
sidebar:
name: "Inheritance in Python
"
parent: "Python"
weight: 56
---

Inheritance in Python
---------------------



One of the core concepts in object-oriented programming (OOP) languages
is inheritance. It is a mechanism that allows you to create a hierarchy
of classes that share a set of properties and methods by deriving a
class from another class. Inheritance is the capability of one class to
derive or inherit the properties from another class. 

Benefits of inheritance are: 
-----------------------------

It represents real-world relationships well.

It provides the reusability of a code. We don't have to write the same
code again and again. Also, it allows us to add more features to a class
without modifying it.

It is transitive in nature, which means that if class B inherits from
another class A, then all the subclasses of B would automatically
inherit from class A.

Inheritance offers a simple, understandable model structure. 

Less development and maintenance expenses result from an inheritance. 

Python Inheritance Syntax
-------------------------

    Class BaseClass:
        {Body}
    Class DerivedClass(BaseClass):
        {Body}

Creating a Parent Class
-----------------------

Creating a Person class with Display methods.

Python3
-------

\# A Python program to demonstrate inheritance class
Person(object):     \# Constructor  def \_\_init\_\_(self, name,
id):    self.name = name    self.id = id   \# To check if this person is
an employee  def Display(self):    print(self.name, self.id)  \# Driver
codeemp = Person(\"Satyam\", 102) \# An Object of Personemp.Display()

Output:

    Satyam 102

Creating a Child Class
----------------------

Here Emp is another class which is going to inherit the properties of
the Person class(base class).

Python3
-------

class Emp(Person):     def Print(self):    print(\"Emp class
called\")     Emp\_details = Emp(\"Mayank\", 103) \# calling parent
class functionEmp\_details.Display() \# Calling child class
functionEmp\_details.Print()

Output:

    Mayank 103
    Emp class called

Example of Inheritance in Python 
---------------------------------

Python3
-------

\# A Python program to demonstrate inheritance \# Base or Super class.
Note object in bracket.\# (Generally, object is made ancestor of all
classes)\# In Python 3.x \"class Person\" is\# equivalent to \"class
Person(object)\"  class Person(object):     \# Constructor    def
\_\_init\_\_(self, name):        self.name = name     \# To get
name    def getName(self):        return self.name     \# To check if
this person is an employee    def isEmployee(self):        return
False  \# Inherited or Subclass (Note Person in bracket)class
Employee(Person):     \# Here we return true    def
isEmployee(self):        return True  \# Driver codeemp =
Person(\"Geek1\")  \# An Object of Personprint(emp.getName(),
emp.isEmployee()) emp = Employee(\"Geek2\")  \# An Object of
Employeeprint(emp.getName(), emp.isEmployee())

Output: 

    Geek1 False
    Geek2 True

What is object class?
---------------------

Like the Java Object class, in Python (from version 3. x), the object is
the root of all classes. 

In Python 3.x, "class Test(object)" and "class Test" are same. 

In Python 2. x, "class Test(object)" creates a class with the object as
a parent (called a new-style class), and "class Test" creates an
old-style class (without an objecting parent). 

Subclassing (Calling constructor of parent class)
-------------------------------------------------

A child class needs to identify which class is its parent class. This
can be done by mentioning the parent class name in the definition of the
child class. 

Eg: class subclass\_name (superclass\_name): 

Python3
-------

\# Python code to demonstrate how parent constructors\# are called. \#
parent classclass Person(object):     \# \_\_init\_\_ is known as the
constructor    def \_\_init\_\_(self, name, idnumber):        self.name
= name        self.idnumber = idnumber     def
display(self):        print(self.name)        print(self.idnumber) \#
child class  class Employee(Person):    def \_\_init\_\_(self, name,
idnumber, salary, post):        self.salary = salary        self.post =
post         \# invoking the \_\_init\_\_ of the parent
class        Person.\_\_init\_\_(self, name, idnumber)  \# creation of
an object variable or an instancea = Employee(\'Rahul\', 886012, 200000,
\"Intern\") \# calling a function of the class Person using its
instancea.display()

Output: 

    Rahul
    886012

'a' is the instance created for the class Person. It invokes the
\_\_init\_\_() of the referred class. You can see 'object' written in
the declaration of the class Person. In Python, every class inherits
from a built-in basic class called 'object'. The constructor i.e. the
'\_\_init\_\_' function of a class is invoked when we create an object
variable or an instance of the class.The variables defined within
\_\_init\_\_() are called the instance variables or objects. Hence,
'name' and 'idnumber' are the objects of the class Person. Similarly,
'salary' and 'post' are the objects of the class Employee. Since the
class Employee inherits from class Person, 'name' and 'idnumber' are
also the objects of class Employee.

Python program to demonstrate error if we forget to invoke \_\_init\_\_() of the parent
---------------------------------------------------------------------------------------

If you forget to invoke the \_\_init\_\_() of the parent class then its
instance variables would not be available to the child class. 

The following code produces an error for the same reason. 

Python3
-------

class A:    def \_\_init\_\_(self, n=\'Rahul\'):        self.name =
n  class B(A):    def \_\_init\_\_(self, roll):        self.roll =
roll  object = B(23)print(object.name)

Output : 

    Traceback (most recent call last):
      File "/home/de4570cca20263ac2c4149f435dba22c.py", line 12, in 
        print (object.name)
    AttributeError: 'B' object has no attribute 'name'

Different types of Inheritance:
-------------------------------

Single inheritance: When a child class inherits from only one parent
class, it is called single inheritance. We saw an example above.

Multiple inheritances: When a child class inherits from multiple parent
classes, it is called multiple inheritances. 

Unlike java, python shows multiple inheritances.

Python3
-------

\# Python example to show the working of multiple\# inheritance  class
Base1(object):    def \_\_init\_\_(self):        self.str1 =
\"Geek1\"        print(\"Base1\")  class Base2(object):    def
\_\_init\_\_(self):        self.str2 =
\"Geek2\"        print(\"Base2\")  class Derived(Base1, Base2):    def
\_\_init\_\_(self):         \# Calling constructors of Base1        \#
and Base2
classes        Base1.\_\_init\_\_(self)        Base2.\_\_init\_\_(self)        print(\"Derived\")     def
printStrs(self):        print(self.str1, self.str2)  ob =
Derived()ob.printStrs()

Output: 

    Base1
    Base2
    Derived
    Geek1 Geek2

Multilevel inheritance: When we have a child and grandchild
relationship. 

Python3
-------

\# A Python program to demonstrate inheritance \# Base or Super class.
Note object in bracket.\# (Generally, object is made ancestor of all
classes)\# In Python 3.x \"class Person\" is\# equivalent to \"class
Person(object)\"  class Base(object):     \# Constructor    def
\_\_init\_\_(self, name):        self.name = name     \# To get
name    def getName(self):        return self.name  \# Inherited or Sub
class (Note Person in bracket)class Child(Base):     \#
Constructor    def \_\_init\_\_(self, name,
age):        Base.\_\_init\_\_(self, name)        self.age = age     \#
To get name    def getAge(self):        return self.age \# Inherited or
Sub class (Note Person in bracket)  class GrandChild(Child):     \#
Constructor    def \_\_init\_\_(self, name, age,
address):        Child.\_\_init\_\_(self, name, age)        self.address
= address     \# To get address    def getAddress(self):        return
self.address  \# Driver codeg = GrandChild(\"Geek1\", 23,
\"Noida\")print(g.getName(), g.getAge(), g.getAddress())

Output: 

    Geek1 23 Noida

Hierarchical inheritance More than one derived class are created from a
single base.

Hybrid inheritance: This form combines more than one form of
inheritance. Basically, it is a blend of more than one type of
inheritance.

For more details please read this article: Types of inheritance in
Python

Private members of the parent class 
------------------------------------

We don't always want the instance variables of the parent class to be
inherited by the child class i.e. we can make some of the instance
variables of the parent class private, which won't be available to the
child class. We can make an instance variable private by adding double
underscores before its name. For example,

Python3
-------

\# Python program to demonstrate private members\# of the parent
class  class C(object):    def \_\_init\_\_(self):        self.c =
21         \# d is private instance variable        self.\_\_d =
42  class D(C):    def \_\_init\_\_(self):        self.e =
84        C.\_\_init\_\_(self)  object1 = D() \# produces an error as d
is private instance variableprint(object1.d)

Output : 

      File "/home/993bb61c3e76cda5bb67bd9ea05956a1.py", line 16, in 
        print (object1.d)                     
    AttributeError: type object 'D' has no attribute 'd'

Since 'd' is made private by those underscores, it is not available to
the child class 'D' and hence the error.
