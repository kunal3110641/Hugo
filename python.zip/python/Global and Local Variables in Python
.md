---
title: "Global and Local Variables in Python
"
draft: false
menu:
sidebar:
name: "Global and Local Variables in Python
"
parent: "Python"
weight: 46
---

Global and Local Variables in Python
------------------------------------



Python Global variables are those which are not defined inside any
function and have a global scope whereas Python local variables are
those which are defined inside a function and their scope is limited to
that function only. In other words, we can say that local variables are
accessible only inside the function in which it was initialized whereas
the global variables are accessible throughout the program and inside
every function. 

Python Local Variables
----------------------

Local variables in Python are those which are initialized inside a
function and belong only to that particular function. It cannot be
accessed anywhere outside the function. Let's see how to create a local
variable.

Creating local variables in Python
----------------------------------

Defining and accessing local variables

Python3
-------

def f():     \# local variable    s = \"I love
Geeksforgeeks\"    print(s)  \# Driver codef()

    I love Geeksforgeeks

Can a local variable be used outside a function?

If we will try to use this local variable outside the function then
let's see what will happen.

Python3
-------

def f():         \# local variable    s = \"I love
Geeksforgeeks\"    print(\"Inside Function:\", s) \# Driver
codef()print(s)

Output:

    NameError: name 's' is not defined

Python Global Variables
-----------------------

These are those which are defined outside any function and which are
accessible throughout the program, i.e., inside and outside of every
function. Let's see how to create a Python global variable.

Create a global variable  in Python
-----------------------------------

Defining and accessing Python global variables.

Python3
-------

\# This function uses global variable sdef f():    print(\"Inside
Function\", s) \# Global scopes = \"I love
Geeksforgeeks\"f()print(\"Outside Function\", s)

    Inside Function I love Geeksforgeeks
    Outside Function I love Geeksforgeeks

The variable s is defined as the global variable and is used both inside
the function as well as outside the function.

Note: As there are no locals, the value from the globals will be used
but make sure both the local and the global variables should have same
name.

Why do we use Local and Global variables in Python?
---------------------------------------------------

Now, what if there is a Python variable with the same name initialized
inside a function as well as globally? Now the question arises, will the
local variable will have some effect on the global variable or vice
versa, and what will happen if we change the value of a variable inside
of the function f()? Will it affect the globals as well? We test it in
the following piece of code: 

Example

If a variable with the same name is defined inside the scope of the
function as well then it will print the value given inside the function
only and not the global value. 

Python3
-------

\# This function has a variable with\# name same as s.def f():    s =
\"Me too.\"    print(s) \# Global scopes = \"I love
Geeksforgeeks\"f()print(s)

    Me too.
    I love Geeksforgeeks

Now, what if we try to change the value of a global variable inside the
function? Let's see it using the below example.

Python3
-------

\# This function uses global variable sdef f():    s +=
\'GFG\'    print(\"Inside Function\", s)  \# Global scopes = \"I love
Geeksforgeeks\"f()

Output:

    UnboundLocalError: local variable 's' referenced before assignment

To make the above program work, we need to use the "global" keyword in
Python. Let's see what this global keyword is.

The global Keyword
------------------

We only need to use the global keyword in a function if we want to do
assignments or change the global variable. global is not needed for
printing and accessing. Python "assumes" that we want a local variable
due to the assignment to s inside of f(), so the first statement throws
the error message. Any variable which is changed or created inside of a
function is local if it hasn't been declared as a global variable. To
tell Python, that we want to use the global variable, we have to use the
keyword "global", as can be seen in the following example: 

Example 1: Using Python global keyword

Python3
-------

\# This function modifies the global variable \'s\'def f():    global
s    s += \' GFG\'    print(s)    s = \"Look for Geeksforgeeks Python
Section\"    print(s) \# Global Scopes = \"Python is great!\"f()print(s)

    Python is great! GFG
    Look for Geeksforgeeks Python Section
    Look for Geeksforgeeks Python Section

Now there is no ambiguity. 

Example 2: Using Python global and local variables

Python3
-------

a = 1 \# Uses global because there is no local \'a\'def
f():    print(\'Inside f() : \', a) \# Variable \'a\' is redefined as a
localdef g():    a = 2    print(\'Inside g() : \', a) \# Uses global
keyword to modify global \'a\'def h():    global a    a =
3    print(\'Inside h() : \', a)  \# Global scopeprint(\'global : \',
a)f()print(\'global : \', a)g()print(\'global : \', a)h()print(\'global
: \', a)

    global :  1
    Inside f() :  1
    global :  1
    Inside g() :  2
    global :  1
    Inside h() :  3
    global :  3

Difference b/w Local Variable Vs. Global Variables
--------------------------------------------------

Comparision BasisGlobal VariableLocal VariableDefinitiondeclared outside
the functionsdeclared within the functionsLifetimeThey are created  the
execution of the program begins and are lost when the program is
endedThey are created when the function starts its execution and are
lost when the function endsData SharingOffers Data SharingIt doesn't
offers Data SharingScopeCan be access throughout the codeCan access only
inside the functionParameters neededparameter passing is not
necessaryparameter passing is necessaryStorage A fixed location selected
by the compilerThey are  kept on the stackValueOnce the value changes it
is reflected throughout the codeonce changed the variable don't affect
other functions of the program
