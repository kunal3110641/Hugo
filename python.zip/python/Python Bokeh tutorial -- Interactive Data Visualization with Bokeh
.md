---
title: "Python Bokeh tutorial -- Interactive Data Visualization with Bokeh
"
draft: false
menu:
sidebar:
name: "Python Bokeh tutorial -- Interactive Data Visualization with Bokeh
"
parent: "Python"
weight: 146
---

Python Bokeh tutorial -- Interactive Data Visualization with Bokeh
------------------------------------------------------------------



Python Bokeh is a Data Visualization library that provides interactive
charts and plots. Bokeh renders its plots using HTML and JavaScript that
uses modern web browsers for presenting elegant, concise construction of
novel graphics with high-level interactivity. 

Features of Bokeh:

Flexibility: Bokeh can be used for common plotting requirements and for
custom and complex use-cases.

Productivity: Its interaction with other popular Pydata tools (such as
Pandas and Jupyter notebook) is very easy.

Interactivity: It creates interactive plots that change with the user
interaction.

Powerful: Generation of visualizations for specialized use-cases can be
done by adding JavaScript.

Shareable: Visual data are shareable. They can also be rendered in
Jupyter notebooks.

Open source: Bokeh is an open-source project.

![Python Bokeh
Tutorial](https://media.geeksforgeeks.org/wp-content/uploads/20210219160041/PythonBokehmin.jpg)

This tutorial aims at providing insight to Bokeh using well-explained
concepts and examples with the help of a huge dataset. So let's dive
deep into the Bokeh and learn all it from basic to advance.

Table Of Content 

Installation

Bokeh Interfaces -- Basic Concepts of Bokeh

Getting Started

Annotations and Legends Customizing Legends  

Customizing Legends  

Plotting Different Types of Plots Bar PlotScatter PlotPatch PlotArea
PlotPie Chart

Bar Plot

Scatter Plot

Patch Plot

Area Plot

Pie Chart

Creating Different Shapes CircleOvalTriangleRectanglePolygon

Circle

Oval

Triangle

Rectangle

Polygon

Plotting Multiple Plots Vertical LayoutsHorizontal LayoutGrid Layout

Vertical Layouts

Horizontal Layout

Grid Layout

Interactive Data Visualization Configuring Plot ToolsInteractive
LegendsAdding Widgets to the Plot

Configuring Plot Tools

Interactive Legends

Adding Widgets to the Plot

Creating Different Types of Glyphs

Visualizing Different Types of Data

More Topics on Bokeh

Installation
------------

Bokeh is supported by CPython 3.6 and older with both standard
distribution and anaconda distribution. Bokeh package has the following
dependencies.

1\. Required Dependencies

PyYAML\>=3.10

python-dateutil\>=2.1

Jinja2\>=2.7

numpy\>=1.11.3

pillow\>=4.0

packaging\>=16.8

tornado\>=5

typing\_extensions \>=3.7.4

2\. Optional Dependencies

Jupyter

NodeJS

NetworkX

Pandas

psutil

Selenium, GeckoDriver, Firefox

Sphinx

Bokeh can be installed using both conda package manager and pip. To
install it using conda type the below command in the terminal.

    conda install bokeh

This will install all the dependencies. If all the dependencies are
installed then you can install the bokeh from PyPI using pip. Type the
below command in the terminal.

    pip install bokeh

Refer to the below article to get detailed information about the
installation of Bokeh.

Python -- Setting up the Bokeh Environment

Bokeh Interfaces -- Basic Concepts of Bokeh
-------------------------------------------

Bokeh is simple to use as it provides a simple interface to the data
scientists who do not want to be distracted by its implementation and
also provides a detailed interface to developers and software engineers
who may want more control over the Bokeh to create more sophisticated
features. To do this Bokeh follows the layered approach. 

Bokeh.models
------------

This class is the Python Library for Bokeh that contains model classes
that handle the JSON data created by Bokeh's JavaScript library
(BokehJS). Most of the models are very basic consisting of very few
attributes or no methods.

bokeh.plotting
--------------

This is the mid-level interface that provides Matplotlib or MATLAB like
features for plotting. It deals with the data that is to be plotted and
creating the valid axes, grids, and tools. The main class of this
interface is the Figure class.

Getting Started
---------------

After the installation and learning about the basic concepts of Bokeh
let's create a simple plot.

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# instantiating the figure object graph =
figure(title = \"Bokeh Line Graph\")   \# the points to be plotted x =
\[1, 2, 3, 4, 5\] y = \[5, 4, 3, 2, 1\]   \# plotting the line
graph graph.line(x, y)   \# displaying the model show(graph)

Output:

![Bokeh Tutorial simple
plot](https://media.geeksforgeeks.org/wp-content/uploads/20210208185539/bokehtutorialsimpleplot.png)

In the above example, we have created a simple Plot with the Title as
Bokeh Line Graph. If you are using Jupyter then the output will be
created in a new tab in the browser.

Annotations and Legends
-----------------------

Annotations are the supplemental information such as titles, legends,
arrows, etc that can be added to the graphs. In the above example, we
have already seen how to add the titles to the graph. In this section,
we will see about the legends.

Adding legends to your figures can help to properly describe and define
them. Hence, giving more clarity. Legends in Bokeh are simple to
implement. They can be basic, automatically grouped, manually mentioned,
explicitly indexed, and also interactive.

Example:

Python3
-------

\# importing the modulesfrom bokeh.plotting import figure, output\_file,
show  \# instantiating the figure objectgraph = figure(title=\"Bokeh
Line Graph\")  \# the points to be plottedx = \[1, 2, 3, 4, 5\]y = \[5,
4, 3, 2, 1\]  \# plotting the 1st line graphgraph.line(x, x,
legend\_label=\"Line 1\")  \# plotting the 2nd line graph with a\#
different colorgraph.line(y, x, legend\_label=\"Line
2\",           line\_color=\"green\")  \# displaying the
modelshow(graph)

Output:

![Bokeh tutorial annotations and
legends](https://media.geeksforgeeks.org/wp-content/uploads/20210208190521/Bokehtutorialannotationsandlegends.png)

In the above example, we have plotted two different lines with a legend
that simply states that which is line 1 and which is line 2. The color
in the legends is also differentiated by the color.

Refer to the below articles to get detailed information about the
annotations and legends

Bokeh -- Annotations and Legends

Customizing Legends
-------------------

Legends in Bokeh can be customized using the following properties.

PropertyDescriptionlegend.label\_text\_font change default label font to
specified font namelegend.label\_text\_font\_size font size in
pointslegend.location set the label at specified
location.legend.title set title for legend label legend.orientation set
to horizontal (default) or verticallegend.clicking\_policy specify what
should happen when legend is clicked

Example:

Python3
-------

\# importing the modulesfrom bokeh.plotting import figure, output\_file,
show  \# instantiating the figure objectgraph = figure(title=\"Bokeh
Line Graph\")  \# the points to be plottedx = \[1, 2, 3, 4, 5\]y = \[5,
4, 3, 2, 1\]  \# plotting the 1st line graphgraph.line(x, x,
legend\_label=\"Line 1\")  \# plotting the 2nd line graph with a\#
different colorgraph.line(y, x, legend\_label=\"Line
2\",           line\_color=\"green\")  graph.legend.title = \"Title of
the legend\"graph.legend.location
=\"top\_left\"graph.legend.label\_text\_font\_size = \"17pt\"  \#
displaying the modelshow(graph)

Output:

![bokeh tutorial customize
legend](https://media.geeksforgeeks.org/wp-content/uploads/20210210163252/bokehtutorialcustomizelegend.png)

Plotting Different Types of Plots
---------------------------------

Glyphs in Bokeh terminology means the basic building blocks of the Bokeh
plots such as lines, rectangles, squares, etc. Bokeh plots are created
using the bokeh.plotting interface which uses a default set of tools and
styles.

Line Plot
---------

Line charts are used to represent the relation between two data X and Y
on a different axis. A line plot can be created using the line() method
of the plotting module.

Syntax:

line(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# instantiating the figure object graph =
figure(title = \"Bokeh Line Graph\")   \# the points to be plotted x =
\[1, 2, 3, 4, 5\] y = \[5, 4, 3, 2, 1\]   \# plotting the line
graph graph.line(x, y)   \# displaying the model show(graph)

Output:

![bokeh tutorial line
plot](https://media.geeksforgeeks.org/wp-content/uploads/20210208192936/bokehtutoriallineplot.png)

Refer to the below articles to get detailed information about the line
plots.

Python Bokeh -- Plotting a Line Graph

Python Bokeh -- Plotting Multiple Lines on a Graph

Bar Plot
--------

Bar plot or Bar chart is a graph that represents the category of data
with rectangular bars with lengths and heights that is proportional to
the values which they represent. It can be of two types horizontal bars
and vertical bars. Each can be created using the hbar() and vbar()
functions of the plotting interface respectively.

Syntax:

hbar(parameters)

vbar(parameters)

Example 1: Creating horizontal bars.

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# instantiating the figure object graph =
figure(title = \"Bokeh Bar Graph\")   \# the points to be plotted x =
\[1, 2, 3, 4, 5\] y = \[1, 2, 3, 4, 5\]    \# height / thickness of the
plotheight = 0.5  \# plotting the bar graph graph.hbar(x, right = y,
height = height)   \# displaying the model show(graph)

Output:

![bokeh tutorial
hbar](https://media.geeksforgeeks.org/wp-content/uploads/20210208194150/bokehtutorialhbar.png)

Example 2: Creating the vertical bars

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# instantiating the figure object graph =
figure(title = \"Bokeh Bar Graph\")   \# the points to be plotted x =
\[1, 2, 3, 4, 5\] y = \[1, 2, 3, 4, 5\]    \# height / thickness of the
plotwidth = 0.5  \# plotting the bar graph graph.vbar(x, top = y, width
= width)   \# displaying the model show(graph)

Output:

![bokeh tutorial
vbar](https://media.geeksforgeeks.org/wp-content/uploads/20210208194408/bokehtutorialvbar.png)

Refer to the below articles to get detailed information about the bar
charts.

Python Bokeh -- Plotting Horizontal Bar Graphs

Python Bokeh -- Plotting Vertical Bar Graphs

Scatter Plot
------------

A scatter plot is a set of dotted points to represent individual pieces
of data in the horizontal and vertical axis. A graph in which the values
of two variables are plotted along X-axis and Y-axis, the pattern of the
resulting points reveals a correlation between them. It can be plotted
using the scatter() method of the plotting module.

Syntax:

    scatter(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show from bokeh.palettes import magma import
random         \# instantiating the figure object graph = figure(title =
\"Bokeh Scatter Graph\")   \# points to be plotted x = \[n for n in
range(256)\] y = \[random.random() + 1 for n in range(256)\]     \#
plotting the graph graph.scatter(x, y)   \# displaying the
model show(graph)

Output:

![bokeh tutorial scatter
plot](https://media.geeksforgeeks.org/wp-content/uploads/20210209180742/bokehtutorialscatterplot.png)

Refer to the below articles to get detailed information about the
scatter plots.

Python Bokeh -- Plotting a Scatter Plot on a Graph

Patch Plot
----------

Patch Plot shades a region of area to show a group having same
properties. It can be created using the patch() method of the plotting
module.

Syntax:

patch(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show from bokeh.palettes import magma import
random         \# instantiating the figure object graph = figure(title =
\"Bokeh Patch Plo\")   \# points to be plotted x = \[n for n in
range(256)\] y = \[random.random() + 1 for n in range(256)\]   \#
plotting the graph graph.patch(x, y)   \# displaying the
model show(graph)

Output:

![patch plot bokeh
tutorial](https://media.geeksforgeeks.org/wp-content/uploads/20210209182138/patchplotbokehtutorial.png)

Refer to the below articles to get detailed information about the Patch
Plot.

Python Bokeh -- Plotting Patches on a Graph

Area Plot
---------

Area plots are defined as the filled regions between two series that
share a common areas. Bokeh Figure class has two methods which are --
varea(), harea()

Syntax:

varea(x, y1, y2, \*\*kwargs)

harea(x1, x2, y, \*\*kwargs)

Example 1: Creating vertical area plot

Python
------

\# Implementation of bokeh functionimport numpy as np from
bokeh.plotting import figure, output\_file, show       x = \[1, 2, 3, 4,
5\] y1 = \[2, 4, 5, 2, 4\] y2 = \[1, 2, 2, 3, 6\]   p =
figure(plot\_width=300, plot\_height=300)   \# area plot p.varea(x=x,
y1=y1, y2=y2,fill\_color=\"green\")   show(p)

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/20200618231309/varea.JPG)

Example 2: Creating horizontal area plot

Python3
-------

\# Implementation of bokeh function       import numpy as np from
bokeh.plotting import figure, output\_file, show       y = \[1, 2, 3, 4,
5\] x1 = \[2, 4, 5, 2, 4\] x2 = \[1, 2, 2, 3, 6\]   p =
figure(plot\_width=300, plot\_height=300)   \# area plot p.harea(x1=x1,
x2=x2, y=y,fill\_color=\"green\")   show(p)

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/20200618231307/harea.JPG)

Refer to the below articles to get detailed information about the area
charts

Make an area plot in Python using Bokeh

Pie Chart
---------

Bokeh Does not provide a direct method to plot the Pie Chart. It can be
created using the wedge() method. In the wedge() function, the primary
parameters are the x and y coordinates of the wedge, the radius, the
start\_angle and the end\_angle of the wedge. In order to plot the
wedges in such a way that they look like a pie chart, the x, y, and
radius parameters of all the wedges will be the same. We will only
adjust the start\_angle and the end\_angle.

Syntax:

wedge(parameters)

Example: 

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show           \# instantiating the figure object graph =
figure(title = \"Bokeh Wedge Graph\")       \# the points to be
plotted x = 0y = 0  \# radius of the wedge radius = 15  \# start angle
of the wedge start\_angle = 1  \# end angle of the wedge end\_angle =
2  \# plotting the graph graph.wedge(x, y, radius =
radius,             start\_angle = start\_angle,             end\_angle
= end\_angle)       \# displaying the model show(graph) 

Output:

![Bokeh Tutorial Pie
chart](https://media.geeksforgeeks.org/wp-content/uploads/20200706011148/bokeh-wedge-default.png)

Refer to the below articles to get detailed information about the pie
charts.

Python Bokeh -- Plotting Wedges on a Graph

Python Bokeh -- Making a Pie Chart

Creating Different Shapes
-------------------------

The Figure class in Bokeh allows us create vectorised glyphs of
different shapes such as circle, rectangle, oval, polygon, etc. Let's
discuss them in detail.

Circle
------

Bokeh Figure class following methods to draw circle glyphs which are
given below:

circle() method is a used to add a circle glyph to the figure and needs
x and y coordinates of its center.

circle\_cross() method is a used to add a circle glyph with a '+' cross
through the center to the figure and needs x and y coordinates of its
center.

circle\_x() method is a used to add a circle glyph with a 'X' cross
through the center. to the figure and needs x and y coordinates of its
center.

Example:

Python3
-------

import numpy as np from bokeh.plotting import figure, output\_file,
show   \# creating the figure objectplot = figure(plot\_width = 300,
plot\_height = 300)   plot.circle(x = \[1, 2, 3\], y = \[3, 7, 5\], size
= 20)   show(plot) 

Output:

![bokeh tutorial
circle](https://media.geeksforgeeks.org/wp-content/uploads/20210209201208/bokehtutorialcircle.png)

Refer to the below articles to get detailed information about the circle
glyphs

Make an Circle Glyphs in Python using Bokeh

Oval
----

oval() method can be used to plot ovals on the graph.

Syntax:

oval(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show         \# instantiating the figure object graph =
figure(title = \"Bokeh Oval Graph\")       \# the points to be plotted x
= \[1, 2, 3, 4, 5\] y = \[i \* 2 for i in x\]   \# plotting the
graph graph.oval(x, y,         height = 0.5,         width = 1)       \#
displaying the model show(graph) 

Output:

![boekh tutorial
oval](https://media.geeksforgeeks.org/wp-content/uploads/20210209201718/boekhtutorialoval.png)

Refer o the below articles to get detailed information about the oval
glyphs.

Python Bokeh -- Plotting Ovals on a Graph

Triangle
--------

Triangle can be created using the triangle() method.

Syntax:

triangle(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show     \# instantiating the figure object graph =
figure(title = \"Bokeh Triangle Graph\")       \# the points to be
plotted x = 1y = 1  \# plotting the graph graph.triangle(x, y, size =
150)       \# displaying the model show(graph)

Output:

![](https://media.geeksforgeeks.org/wp-content/uploads/20210209202809/bokehtutorialtriangle.png)

Refer to the below article to get detailed information about the
triangles.

Python Bokeh -- Plotting Triangles on a Graph

Rectangle
---------

Just like circles and ovals rectangle can also be plotted in Bokeh. It
can be plotted using the rect() method.

Syntax:

rect(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show             \# instantiating the figure object graph
= figure(title = \"Bokeh Rectangle Graph\", match\_aspect = True)   \#
the points to be plotted x = 0y = 0width = 10height = 5  \# plotting the
graph graph.rect(x, y, width, height)       \# displaying the
model show(graph) 

Output:

![bokeh tutorial
rectanlge](https://media.geeksforgeeks.org/wp-content/uploads/20210209202331/bokehtutorialrectanlge.png)

Polygon
-------

Bokeh can also be used to plot multiple polygons on a graph. Plotting
multiple polygons on a graph can be done using the multi\_polygons()
method of the plotting module.

Syntax:

multi\_polygons(parameters)

Example:

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show         \# instantiating the figure object graph =
figure(title = \"Bokeh Multiple Polygons Graph\")       \# the points to
be plotted xs = \[\[\[\[1, 1, 3, 4\]\]\]\] ys = \[\[\[\[1, 3, 2
,1\]\]\]\]       \# plotting the graph graph.multi\_polygons(xs,
ys)       \# displaying the model show(graph) 

Output:

![bokeh tutorial
ploygon](https://media.geeksforgeeks.org/wp-content/uploads/20210209203219/bokehtutorialploygon.png)

Refer to the below articles to get detailed information about the
polygon glyphs.

Python Bokeh -- Plotting Multiple Polygons on a Graph

Plotting Multiple Plots
-----------------------

There are several layouts provided by the Bokeh in order to create
Multiple Plots. These layouts are:

Vertical Layout

Horizontal Layout

Grid Layout

Vertical Layouts
----------------

Vertical Layout set all the plots in the vertical fashion and can be
created using the column() method.

Python3
-------

from bokeh.io import output\_file, showfrom bokeh.layouts import
columnfrom bokeh.plotting import figure    x = \[1, 2, 3, 4, 5, 6\]y0 =
xy1 = \[i \* 2 for i in x\]y2 = \[i \*\* 2 for i in x\]  \# create a new
plots1 = figure(width=200, plot\_height=200)s1.circle(x, y0, size=10,
alpha=0.5)  \# create another ones2 = figure(width=200,
height=200)s2.triangle(x, y1, size=10, alpha=0.5)  \# create and
anothers3 = figure(width=200, height=200)s3.square(x, y2, size=10,
alpha=0.5)  \# put all the plots in a VBoxp = column(s1, s2, s3)  \#
show the resultsshow(p)

Output:

![bokeh tutorial
column](https://media.geeksforgeeks.org/wp-content/uploads/20210209205340/bokehtutorialcolumn.png)

Horizontal Layout 
------------------

Horizontal Layout set all the plots in the horizontal fashion. It can be
created using the row() method.

Example:

Python3
-------

from bokeh.io import output\_file, showfrom bokeh.layouts import rowfrom
bokeh.plotting import figure    x = \[1, 2, 3, 4, 5, 6\]y0 = xy1 = \[i
\* 2 for i in x\]y2 = \[i \*\* 2 for i in x\]  \# create a new plots1 =
figure(width=200, plot\_height=200)s1.circle(x, y0, size=10,
alpha=0.5)  \# create another ones2 = figure(width=200,
height=200)s2.triangle(x, y1, size=10, alpha=0.5)  \# create and
anothers3 = figure(width=200, height=200)s3.square(x, y2, size=10,
alpha=0.5)  \# put all the plots in a VBoxp = row(s1, s2, s3)  \# show
the resultsshow(p)

Output:

![Bokeh Tutorial
roe](https://media.geeksforgeeks.org/wp-content/uploads/20210209205822/BokehTutorialroe.png)

Grid Layout
-----------

gridplot() method can be used to arrange all the plots in the grid
fashion. we can also pass None to leave a space empty for a plot.

Example:

Python3
-------

from bokeh.io import output\_file, showfrom bokeh.layouts import
gridplotfrom bokeh.plotting import figure    x = \[1, 2, 3, 4, 5, 6\]y0
= xy1 = \[i \* 2 for i in x\]y2 = \[i \*\* 2 for i in x\]  \# create a
new plots1 = figure()s1.circle(x, y0, size=10, alpha=0.5)  \# create
another ones2 = figure()s2.triangle(x, y1, size=10, alpha=0.5)  \#
create and anothers3 = figure()s3.square(x, y2, size=10, alpha=0.5)  \#
put all the plots in a gridp = gridplot(\[\[s1, None\], \[s2, s3\]\],
plot\_width=200, plot\_height=200)  \# show the resultsshow(p)

Output:

![Bokeh tutorial
grid](https://media.geeksforgeeks.org/wp-content/uploads/20210209210323/Bokehtutorialgrid.png)

Interactive Data Visualization
------------------------------

One of the key feature of Bokeh which differentiate it from other
visualizing libraries is adding interaction to the Plot. Let's see
various interactions that can be added to the plot.

Configuring Plot Tools
----------------------

In all the above graphs you must have noticed a toolbar that appears
mostly at the right of the plot. Bokeh provides us the methods to handle
these tools. Tools can be classified into four categories.

Gestures: These tools handle the gestures such as pan movement. There
are three types of gestures:Pan/Drag ToolsClick/Tap ToolsScroll/Pinch
Tools

Pan/Drag Tools

Click/Tap Tools

Scroll/Pinch Tools

Actions: These tools handle when a button is pressed.

Inspectors: These tools report information or annotate the graph such as
 HoverTool.

Edit Tools: These are multi gestures tools that can add, delete glyphs
from the graph.

Adjusting the Position of the ToolBar
-------------------------------------

We can specify the position of the toolbar according to our own needs.
It can be done by passing the toolbar\_location parameter to the
figure() method. The possible value to this parameter is -- 

"above"

"below"

"left"

"right"

Example: 

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# instantiating the figure object graph =
figure(title = \"Bokeh ToolBar\", toolbar\_location=\"below\")   \# the
points to be plotted x = \[1, 2, 3, 4, 5\] y = \[1, 2, 3, 4, 5\]    \#
height / thickness of the plotwidth = 0.5  \# plotting the scatter
graph graph.scatter(x, y)   \# displaying the model show(graph)

Output:

![Bokeh Tutorial
toolbar](https://media.geeksforgeeks.org/wp-content/uploads/20210209215203/BokehTutorialtoolbar.png)

Interactive Legends
-------------------

In the section annotations and legends we have seen the list of all the
parameters of the legends, however, we have not discussed the
click\_policy parameter yet. This property makes the legend interactive.
There are two types of interactivity --

Hiding: Hides the Glyphs.

Muting: Hiding the glyph makes it vanish completely, on the other hand,
muting the glyph just de-emphasizes the glyph based on the parameters.

Example 1: Hiding the legend

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# file to save the
model output\_file(\"gfg.html\")           \# instantiating the figure
object graph = figure(title = \"Bokeh Hiding Glyphs\")   \# plotting the
graph graph.vbar(x = 1, top = 5,         width = 1, color =
\"violet\",         legend\_label = \"Violet Bar\") graph.vbar(x = 2,
top = 5,         width = 1, color = \"green\",         legend\_label =
\"Green Bar\") graph.vbar(x = 3, top = 5,         width = 1, color =
\"yellow\",         legend\_label = \"Yellow Bar\") graph.vbar(x = 4,
top = 5,         width = 1, color = \"red\",         legend\_label =
\"Red Bar\")   \# enable hiding of the glyphs graph.legend.click\_policy
= \"hide\"  \# displaying the model show(graph) 

Output:

![bokeh tutorial hiding
legend](https://media.geeksforgeeks.org/wp-content/uploads/20210210171603/bokehtutorialhidinglegend.gif)

Example 2: Muting the legend

Python3
-------

\# importing the modules from bokeh.plotting import figure,
output\_file, show   \# file to save the
model output\_file(\"gfg.html\")           \# instantiating the figure
object graph = figure(title = \"Bokeh Hiding Glyphs\")   \# plotting the
graph graph.vbar(x = 1, top = 5,         width = 1, color =
\"violet\",         legend\_label = \"Violet
Bar\",         muted\_alpha=0.2) graph.vbar(x = 2, top =
5,         width = 1, color = \"green\",         legend\_label = \"Green
Bar\",         muted\_alpha=0.2) graph.vbar(x = 3, top =
5,         width = 1, color = \"yellow\",         legend\_label =
\"Yellow Bar\",         muted\_alpha=0.2) graph.vbar(x = 4, top =
5,         width = 1, color = \"red\",         legend\_label = \"Red
Bar\",         muted\_alpha=0.2)   \# enable hiding of the
glyphs graph.legend.click\_policy = \"mute\"  \# displaying the
model show(graph) 

Output:

![bokeh tutorial muting
legend](https://media.geeksforgeeks.org/wp-content/uploads/20210210171452/mutinglegendbokeh.gif)

Adding Widgets to the Plot
--------------------------

Bokeh provides GUI features similar to HTML forms like buttons, slider,
checkbox, etc. These provide an interactive interface to the plot that
allows to change the parameters of the plot, modifying plot data, etc.
Let's see how to use and add some commonly used widgets. 

Buttons: This widget adds a simple button widget to the plot. We have to
pass a custom JavaScript function to the CustomJS() method of the models
class.

Syntax:

Button(label, icon, callback)

Example:

Python3
-------

from bokeh.io import showfrom bokeh.models import Button,
CustomJS  button =
Button(label=\"GFG\")button.js\_on\_click(CustomJS(  code=\"console.log(\'button:
click!\', this.toString())\"))  show(button)

Output: 

![bokeh tutorial
button](https://media.geeksforgeeks.org/wp-content/uploads/20210210175740/bokehtutorialbutton.png)

CheckboxGroup: Adds a standard check box to the plot. Similarly to
buttons we have to pass the custom JavaScript function to the CustomJS()
method of the models class.

Example:

Python3
-------

from bokeh.io import showfrom bokeh.models import CheckboxGroup,
CustomJS  L = \[\"First\", \"Second\", \"Third\"\]  \# the active
parameter sets checks the selected value \# by defaultcheckbox\_group =
CheckboxGroup(labels=L, active=\[0,
2\])  checkbox\_group.js\_on\_click(CustomJS(code=\"\"\"    console.log(\'checkbox\_group:
active=\' + this.active, this.toString())\"\"\"))  show(checkbox\_group)

Output:

![Bokeh tutorial check
box](https://media.geeksforgeeks.org/wp-content/uploads/20210210180650/bokehtutorialcheckbox.png)

RadioGroup: Adds a simple radio button and accepts a custom JavaScript
function.

Syntax:

RadioGroup(labels, active)

Example:

Python3
-------

from bokeh.io import showfrom bokeh.models import RadioGroup,
CustomJS  L = \[\"First\", \"Second\", \"Third\"\]  \# the active
parameter sets checks the selected value \# by defaultradio\_group =
RadioGroup(labels=L,
active=1)  radio\_group.js\_on\_click(CustomJS(code=\"\"\"    console.log(\'radio\_group:
active=\' + this.active, this.toString())\"\"\"))  show(radio\_group)

Output:

![Bokeh Tutorial radio
button](https://media.geeksforgeeks.org/wp-content/uploads/20210210181845/bokehtutorialradiobutton.png)

Sliders: Adds a slider to the plot. It also needs a custom JavaScript
function.

Syntax:

Slider(start, end, step, value)

Example:

Python3
-------

from bokeh.io import showfrom bokeh.models import CustomJS,
Slider  slider = Slider(start=1, end=20, value=1, step=2,
title=\"Slider\")  slider.js\_on\_change(\"value\",
CustomJS(code=\"\"\"    console.log(\'slider: value=\' + this.value,
this.toString())\"\"\"))  show(slider)

Output:

![bokeh tutorial
slider](https://media.geeksforgeeks.org/wp-content/uploads/20210210182505/bokehtutorialslider.gif)

DropDown: Adds a dropdown to the plot and like every other widget it
also needs a custom JavaScript function as callback.

Example:

Python3
-------

from bokeh.io import showfrom bokeh.models import CustomJS,
Dropdown  menu = \[(\"First\", \"First\"), (\"Second\", \"Second\"),
(\"Third\", \"Third\")\]  dropdown = Dropdown(label=\"Dropdown Menu\",
button\_type=\"success\",
menu=menu)  dropdown.js\_on\_event(\"menu\_item\_click\",
CustomJS(    code=\"console.log(\'dropdown: \' + this.item,
this.toString())\"))  show(dropdown)

Output:

![bokeh tutorial
dropdown](https://media.geeksforgeeks.org/wp-content/uploads/20210210190822/bokehtutorialdropdown.gif)

Tab Widget: Tab Widget adds tabs and each tab show a different plot.

Example:

Python3
-------

from bokeh.plotting import figure, output\_file, showfrom bokeh.models
import Panel, Tabsimport numpy as npimport math    fig1 =
figure(plot\_width=300, plot\_height=300)  x = \[1, 2, 3, 4, 5\]y = \[5,
4, 3, 2, 1\]  fig1.line(x, y, line\_color=\'green\')tab1 =
Panel(child=fig1, title=\"Tab 1\")  fig2 = figure(plot\_width=300,
plot\_height=300)  fig2.line(y, x, line\_color=\'red\')tab2 =
Panel(child=fig2, title=\"Tab 2\")  all\_tabs = Tabs(tabs=\[tab1,
tab2\])  show(all\_tabs)

Output:

![bokeh tutorial
tabs](https://media.geeksforgeeks.org/wp-content/uploads/20210210191552/bokehtutorialtabs.gif)

Creating Different Types of Glyphs
----------------------------------

Diamond Glyph

Dash Glyph

Cross Glyph

Diamond Glyph

Diamond Cross Glyph

Diamond Dot Glyph

Ray Glyph

Triangle Pins Glyph

Triangle with Dots Glyph

Inverted Triangle Glyph

Plus Glyph

Quadrilateral Glyph

Y Glyph

X Glyph

Oval Glyph

Hexagon Glyph

Hexagon Tiles Glyph

Hexagon Dots Glyph

Square with Cross Glyph

Square with Dots Glyph

Square with X's Glyph

Ellipse glyph

Annulus Glyph

Bezier Glyph

Asterisk Glyph

AnnularWedge Glyph

Step Glyph

Visualizing Different Types of Data
-----------------------------------

Python Bokeh -- Visualizing the Iris Dataset

Python Bokeh -- Visualizing Stock Data

Interactive visualization of data using Bokeh

