---
title: "Python Exercises, Practice Questions and Solutions
"
draft: false
menu:
sidebar:
name: "Python Exercises, Practice Questions and Solutions
"
parent: "Python"
weight: 148
---

Python Exercises, Practice Questions and Solutions
--------------------------------------------------



Python is a widely used general-purpose high-level language that can be
used for many purposes like creating GUI, web Scraping, web development,
etc. You might have seen various Python tutorials that explain the
concepts in detail but that might not be enough to get hold of this
language. The best way to learn is by practicing it more and more.

This Python exercise helps you learn Python using sets of detailed
programming Questions from basic to advance. It covers questions on core
Python concepts as well as applications of Python on various domains.

![](https://media.geeksforgeeks.org/wp-content/uploads/20210105234135/PythonPracticeExercisesQuestionsandSolutionsmin.png){width="1065"}

 

Python List Exercises
---------------------

Python program to interchange first and last elements in a list

Python program to swap two elements in a list

Python \| Ways to find length of list

Maximum of two numbers in Python

Minimum of two numbers in Python

\>\> More Programs on List

Python String Exercises
-----------------------

Python program to check whether the string is Symmetrical or Palindrome

Reverse words in a given String in Python

Ways to remove i'th character from string in Python

Find length of a string in python (4 ways)

Python program to print even length words in a string

\>\> More Programs on String

Python Tuple Exercises
----------------------

Python program to Find the size of a Tuple

Python -- Maximum and Minimum K elements in Tuple

Python -- Sum of tuple elements

Python -- Row-wise element Addition in Tuple Matrix

Create a list of tuples from given list having number and its cube in
each tuple

\>\> More Programs on Tuple

Python Dictionary Exercises
---------------------------

Python \| Sort Python Dictionaries by Key or Value

Handling missing keys in Python dictionaries

Python dictionary with keys having multiple inputs

Python program to find the sum of all items in a dictionary

Python program to find the size of a Dictionary

\>\> More Programs on Dictionary

Python Set Exercises
--------------------

Find the size of a Set in Python

Iterate over a set in Python

Python -- Maximum and Minimum in a Set

Python -- Remove items from Set

Python -- Check if two lists have atleast one element common

\>\> More Programs on Sets

Python Matrix Exercises
-----------------------

Python -- Assigning Subsequent Rows to Matrix first row elements

Adding and Subtracting Matrices in Python

Python -- Group similar elements into Matrix

Python -- Row-wise element Addition in Tuple Matrix

Create an n x n square matrix, where all the sub-matrix have the sum of
opposite corner elements as even

\>\> More Programs on Matrices

Python Functions Exercises
--------------------------

How to get list of parameters name from a function in Python?

How to Print Multiple Arguments in Python?

Python program to find the power of a number using recursion

Sorting objects of user defined class in Python

Functions that accept variable length key value pair as arguments

\>\> More Programs on Functions

Python Lambda Exercises
-----------------------

Lambda with if but without else in Python

Python \| Sorting string using order defined by another string

Python \| Find fibonacci series upto n using lambda

Python program to count Even and Odd numbers in a List

Python \| Find the Number Occurring Odd Number of Times using Lambda
expression and reduce function

\>\> More Programs on Lambda

Python Pattern printing Exercises
---------------------------------

Program to print half Diamond star pattern

Programs for printing pyramid patterns in Python

Program to print the diamond shape

Python \| Print an Inverted Star Pattern

Python Program to print digit pattern

\>\> More Programs on Python Pattern Printing

Python DateTime Exercises
-------------------------

Python program to get Current Time

Get Yesterday's date using Python

Python program to print current year, month and day

Python -- Convert day number to date in particular year

Get Current Time in different Timezone using Python

\>\> More Programs on DateTime

Python OOPS Exercises
---------------------

Python program to build flashcard using class in Python

Shuffle a deck of card with OOPS in Python

How to create an empty class in Python?

Student management system in Python

\>\> More Programs on Python OOPS

Python Regex Exercises
----------------------

Python program to find the type of IP Address using Regex

Python program to find Indices of Overlapping Substrings

Python program to extract Strings between HTML Tags

Python -- Check if String Contain Only Defined Characters using Regex

Python program to find files having a particular extension using RegEx

\>\> More Programs on Python Regex

Python LinkedList Exercises
---------------------------

Python program to Search an Element in a Circular Linked List

Pretty print Linked List in Python

Python \| Stack using Doubly Linked List

Python \| Queue using Doubly Linked List

Python program to find middle of a linked list using one traversal

\>\> More Programs on Linked Lists

Python Searching Exercises
--------------------------

Python Program for Linear Search

Python Program for Binary Search (Recursive and Iterative)

Python Program for Anagram Substring Search (Or Search for all
permutations)

\>\> More Programs on Python Searching

Python Sorting Exercises
------------------------

Python Program for Bubble Sort

Python Program for QuickSort

Python Program for Insertion Sort

Python Program for Selection Sort

Python Program for Heap Sort

\>\> More Programs on Python Sorting

Python DSA Exercises
--------------------

Python program to reverse a stack

Multithreaded Priority Queue in Python

Check whether the given string is Palindrome using Stack

Program to Calculate the Edge Cover of a Graph

Python Program for N Queen Problem

\>\> More Programs on Python DSA

Python File Handling Exercises
------------------------------

Read content from one file and write it into another file

Write a dictionary to a file in Python

How to check file size in Python?

Find the most repeated word in a text file

How to read specific lines from a File in Python?

\>\> More Programs on Python File Handling

Python CSV Exercises
--------------------

Update column value of CSV in Python

How to add a header to a CSV file in Python?

Get column names from CSV using Python

Writing data from a Python List to CSV row-wise

Convert multiple JSON files to CSV Python

\>\> More Programs on Python CSV

Python JSON Exercises
---------------------

Convert class object to JSON in Python

Convert JSON data Into a Custom Python Object

Flattening JSON objects in Python

Convert CSV to JSON using Python

\>\> More Programs on Python JSON

Python OS Module Exercises
--------------------------

How to get file creation and modification date or time in Python?

Menu Driven Python program for opening the required software Application

Python Script to change name of a file to its timestamp

Kill a Process by name using Python

Finding the largest file in a directory using Python

\>\> More Programs on OS Module

Python Tkinter Exercises
------------------------

Python \| Create a GUI Marksheet using Tkinter

Python \| ToDo GUI Application using Tkinter

Python \| GUI Calendar using Tkinter

File Explorer in Python using Tkinter

Visiting Card Scanner GUI Application using Python

\>\> More Programs on Python Tkinter

NumPy Exercises
---------------

How to create an empty and a full NumPy array?

Create a Numpy array filled with all zeros

Create a Numpy array filled with all ones

Replace NumPy array elements that doesn't satisfy the given condition

Get the maximum value from given matrix

\>\> More Programs on NumPy

Pandas Exercises
----------------

Make a Pandas DataFrame with two-dimensional list \| Python

How to iterate over rows in Pandas Dataframe

Create a pandas column using for loop

Create a Pandas Series from array

Pandas \| Basic of Time Series Manipulation

\>\> More Programs on Python Pandas

Python Web Scraping Exercises
-----------------------------

How to extract youtube data in Python?

How to Download All Images from a Web Page in Python?

Test the given page is found or not on the server Using Python

How to Extract Wikipedia Data in Python?

How to extract paragraph from a website and save it as a text file?

\>\> More Programs on Web Scraping

Python Selenium Exercises
-------------------------

Download File in Selenium Using Python

Bulk Posting on Facebook Pages using Selenium

Google Maps Selenium automation using Python

Count total number of Links In Webpage Using Selenium In Python

Extract Data From JustDial using Selenium

\>\> More Programs on Python Selenium

Python Projects
---------------

Number guessing game in Python

2048 Game in Python

Get Live Weather Desktop Notifications Using Python

8-bit game using pygame

Tic Tac Toe GUI In Python using PyGame

\>\> More Projects in Python
