---
title: "Python MySQL -- Join
"
draft: false
menu:
sidebar:
name: "Python MySQL -- Join
"
parent: "Python"
weight: 123
---

Python MySQL -- Join
--------------------



A connector is employed when we have to use mysql with other programming
languages. The work of mysql-connector is to provide access to MySQL
Driver to the required language. Thus, it generates a connection between
the programming language and the MySQL Server.

Python-MySQL-Connector
----------------------

This is a MySQL Connector that allows Python to access MySQL Driver and
implement SQL queries in its programming facility. Here we will try
implementing Join clause on our Database and will study the output
generated.

JOIN Clause Of SQL
------------------

Join allows you to combine two or more tables in SQL, based on related
column between them. Based on this application of join there are three
types of join:

![](https://media.geeksforgeeks.org/wp-content/uploads/20200314221726/JOIN.jpg)

INNER JOIN gives the records that are produced by matching columns. JOIN
and INNER JOIN both work the same. Syntax:

    SELECT column1, column2...
    FROM tablename
    JOIN tablename ON condition;

    SELECT column1, column2...
    FROM tablename
    INNER JOIN tablename ON condition;

LEFT JOIN gives those records from table 1 removing exclusive contents
of 2 Syntax:

    SELECT column1, column2...
    FROM tablename
    LEFT JOIN tablename ON condition;

RIGHT JOIN gives all records from table 2 after removing exclusive
records of 1. Syntax:

    SELECT column1, column2...
    FROM tablename
    RIGHT JOIN tablename ON condition;

The following programs will help you understand this better. DATABASE IN
USE: PROGRAM 1: Use of inner join 

![python-join-db1](https://media.geeksforgeeks.org/wp-content/uploads/20200316192130/python-join-db1.png)![python-join-db21](https://media.geeksforgeeks.org/wp-content/uploads/20200316193328/python-join-db21.png)

Python3
-------

import mysql.connector  \# Connecting to the databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor() \# STUDENT and
STudent are\# two different databasestatement =\"SELECT S.NAME from
Student S JOIN \\Student on S.Roll\_no =
Student.Roll\_no\" cs.execute(statement)result\_set = cs.fetchall() for
x in result\_set:    print(x)

OUTPUT: PROGRAM 2: use of LEFT JOIN 

![python-join-1](https://media.geeksforgeeks.org/wp-content/uploads/20200316194558/python-join-1.png)

Python3
-------

import mysql.connector  \# Connecting to the databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor() \# STUDENT and
STudent are\# two different databasestatement =\"SELECT S.Name from
STUDENT S\\ LEFT JOIN Student s ON S.Roll\_no =
s.Roll\_no\" cs.execute(statement)result\_set = cs.fetchall() for x in
result\_set:    print(x)

OUTPUT: PROGRAM 3 : use of RIGHT JOIN 

![python-join-2](https://media.geeksforgeeks.org/wp-content/uploads/20200316194754/python-join-2.png)

Python3
-------

import mysql.connector  \# Connecting to the databasemydb =
mysql.connector.connect(  host =\'localhost\',  database
=\'College\',  user =\'root\',)  cs = mydb.cursor() \# STUDENT and
STudent are\# two different databasestatement =\"SELECT S.Name from
STUDENT S RIGHT \\JOIN Student s ON S.Roll\_no =
s.Roll\_no\" cs.execute(statement)result\_set = cs.fetchall() for x in
result\_set:    print(x)

OUTPUT:

![python-join-3](https://media.geeksforgeeks.org/wp-content/uploads/20200316194904/python-join-3.png)
