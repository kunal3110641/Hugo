---
title: "Global keyword in Python
"
draft: false
menu:
sidebar:
name: "Global keyword in Python
"
parent: "Python"
weight: 47
---

Global keyword in Python
------------------------



In this article, we will cover the global keyword, the basic rules for
global keywords in Python, the difference between the local, and global
variables, and examples of global keywords in Python.

What is the purpose of global keywords in python?
-------------------------------------------------

A global keyword is a keyword that allows a user to modify a variable
outside the current scope. It is used to create global variables in
Python from a non-global scope, i.e. inside a function. Global keyword
is used inside a function only when we want to do assignments or when we
want to change a variable. Global is not needed for printing and
accessing.

Rules of global keyword:

If a variable is assigned a value anywhere within the function's body,
it's assumed to be a local unless explicitly declared as global.

Variables that are only referenced inside a function are implicitly
global.

We use a global keyword to use a global variable inside a function.

There is no need to use global keywords outside a function.

Use of global keyword in Python: To access a global variable inside a
function, there is no need to use a global keyword. 

Global keyword in the python example
------------------------------------

Example 1: Accessing global Variable From Inside a Function
-----------------------------------------------------------

Python3
-------

\# global variablea = 15b = 10 \# function to perform additiondef
add():    c = a + b    print(c)  \# calling a functionadd()

Output:

    25

If we need to assign a new value to a global variable, then we can do
that by declaring the variable as global.

Example 2: Modifying Global Variable From Inside the Function
-------------------------------------------------------------

Python3
-------

a = 15  \# function to change a global valuedef change():    \#
increment value of a by 5    b = a + 5    a = b    print(a)  change()

Output:

    UnboundLocalError: local variable 'a' referenced before assignment

This output is an error because we are trying to assign a value to a
variable in an outer scope. This can be done with the use of a global
variable.

Example 3: Changing Global Variable From Inside a Function using global
-----------------------------------------------------------------------

Python3
-------

x = 15  def change():    \# using a global keyword    global x     \#
increment value of a by 5    x = x + 5    print(\"Value of x inside a
function :\", x)  change()print(\"Value of x outside a function :\", x)

Output:

    Value of x inside a function : 20
    Value of x outside a function : 20

In the above example, we first define x as a global keyword inside the
function change(). The value of x is then incremented by 5, i.e. x=x+5
and hence we get the output as 20. As we can see by changing the value
inside the function change(), the change is also reflected in the value
outside the global variable.

Modifying global Mutable Objects
--------------------------------

Example 1: Modifying list elements without using global keyword.
----------------------------------------------------------------

Here, we can modify list elements defined in global scope without using
global keyword. Because we are not modifying the object associated with
the variable arr, but we are modifying the items the list contains.
Since lists are mutable data structures, thus we can modify its
contents.

Python3
-------

arr = \[10, 20, 30\]  def fun():    for i in
range(len(arr)):        arr\[i\] += 10  print(\"\'arr\' list before
executing fun():\", arr)fun()print(\"\'arr\' list after executing
fun():\", arr)

Output:

    'arr' list before executing fun(): [10, 20, 30]
    'arr' list after executing fun(): [20, 30, 40]

Example 2: Modifying list variable using global keyword.
--------------------------------------------------------

Here we are trying to assign a new list to the global variable. Thus, we
need to use the global keyword as a new object is created. Here, if we
don't use the global keyword, then a new local variable arr will be
created with the new list elements. But the global variable arr will be
unchanged. 

Python3
-------

arr = \[10, 20, 30\]  def fun():    global arr    arr = \[20, 30,
40\]  print(\"\'arr\' list before executing fun():\",
arr)fun()print(\"\'arr\' list after executing fun():\", arr)

Output:

    'arr' list before executing fun(): [10, 20, 30]
    'arr' list after executing fun(): [20, 30, 40]

Global variables across Python modules 
---------------------------------------

The best way to share global variables across different modules within
the same program is to create a special module (often named config or
cfg). Import the config module in all modules of your application; the
module then becomes available as a global name. There is only one
instance of each module, and so any changes made to the module object
get reflected everywhere. For Example, sharing global variables across
modules.

Code 1: Create a config.py file to store global variables
---------------------------------------------------------

Python3
-------

x = 0y = 0z = \"none\"

Code 2: Create a modify.py file to modify global variables
----------------------------------------------------------

Python3
-------

import configconfig.x = 1config.y = 2config.z = \"geeksforgeeks\"

Here we have modified the value of x, y, and z. These variables were
defined in the module config.py, hence we have to import config module,
and can use config.variable\_name to access these variables.

Create a main.py file to modify global variables
------------------------------------------------

Python3
-------

import configimport modifyprint(config.x)print(config.y)print(config.z)

Output:

    1
    2
    geeksforgeeks

Global in Nested functions
--------------------------

In order to use global inside a nested function, we have to declare a
variable with a global keyword inside a nested function

Python3
-------

\# Python program showing a use of\# global in nested function def
add():    x = 15    def change():        global x        x =
20    print(\"Before making changing: \", x)    print(\"Making
change\")    change()    print(\"After making change: \",
x) add()print(\"value of x\", x)

Output:

    Before making changing:  15
    Making change
    After making change:  15
    value of x 20

In the above example Before and after making change(), the variable x
takes the value of local variable i.e x = 15. Outside the add()
function, the variable x will take the value defined in the change()
function, i.e x = 20. Because we have used global keyword in x to create
a global variable inside the change() function (local scope).
