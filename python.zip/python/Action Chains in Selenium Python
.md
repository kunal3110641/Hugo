---
title: "Action Chains in Selenium Python
"
draft: false
menu:
sidebar:
name: "Action Chains in Selenium Python
"
parent: "Python"
weight: 141
---

Action Chains in Selenium Python
--------------------------------



Selenium's Python Module is built to perform automated testing with
Python. ActionChains are a way to automate low-level interactions such
as mouse movements, mouse button actions, keypress, and context menu
interactions. This is useful for doing more complex actions like hover
over and drag and drop. Action chain methods are used by advanced
scripts where we need to drag an element, click an element, This article
revolves around how to manipulate DOM using Action Chains in Selenium.
We have covered all the methods with examples int detail.

ActionChains are implemented with the help of a action chain object
which stores the actions in a queue and when perform() is called,
performs the queued operations.

How to create an Action Chain Object ?
--------------------------------------

To create object of Action Chain, import ACtion chain class from docs
and pass driver as the key argument. After this one can use this object
to perform all the operations of action chains.

\# import webdriverfrom selenium import webdriver   \# import Action
chains from selenium.webdriver.common.action\_chains import
ActionChains   \# create webdriver objectdriver =
webdriver.Firefox()   \# create action chain objectaction =
ActionChains(driver)  

How to use Action Chains in Selenium ?
--------------------------------------

After one has created an object of Action chain, open a webpage, and
perform various other methods using below syntax and examples. Action
chains can be used in a chain pattern as below --

menu = driver.find\_element\_by\_css\_selector(\".nav\")hidden\_submenu
= driver.find\_element\_by\_css\_selector(\".nav \#
submenu1\")  ActionChains(driver).move\_to\_element(menu).click(hidden\_submenu).perform()

Or actions can be queued up one by one, then performed.:

menu = driver.find\_element\_by\_css\_selector(\".nav\")hidden\_submenu
= driver.find\_element\_by\_css\_selector(\".nav \# submenu1\")  actions
=
ActionChains(driver)actions.move\_to\_element(menu)actions.click(hidden\_submenu)actions.perform()

Project Example --
------------------

Let's try to implement action chains using
https://www.geeksforgeeks.org/ and play around with various methods of
Selenium Python.

\# import webdriverfrom selenium import webdriver   \# import Action
chains from selenium.webdriver.common.action\_chains import
ActionChains   \# create webdriver objectdriver =
webdriver.Firefox()   \# get
geeksforgeeks.orgdriver.get(\"https://www.geeksforgeeks.org/\")   \# get
element element = driver.find\_element\_by\_link\_text(\"Courses\")   \#
create action chain objectaction = ActionChains(driver)   \# click the
itemaction.click(on\_element = element)   \# perform the
operationaction.perform()

Above code, first opens https://www.geeksforgeeks.org/ and then clicks
on courses button in the header, which then redirects the browser to
https://practice.geeksforgeeks.org/ automatically.Output --First driver
opens https://www.geeksforgeeks.org/,

![action-chain-Selenium-Python](https://media.geeksforgeeks.org/wp-content/uploads/20200512084303/driver-methods-Selenium-Python.png)

then redirects to https://practice.geeksforgeeks.org/

![click-element-method-Selenium-Python](https://media.geeksforgeeks.org/wp-content/uploads/20200420010502/click-element-method-Selenium-Python.png)

Action Chain Methods in Selenium Python
---------------------------------------

One can perform a huge number of operations using Action chains such as
click, right-click, etc. Here is a list of important methods used in
Action chains.

MethodDescriptionclickClicks an element.click\_and\_holdHolds down the
left mouse button on an element.context\_clickPerforms a context-click
(right click) on an element.double\_clickDouble-clicks an
element.drag\_and\_dropHolds down the left mouse button on the source
element, then moves to the target element and releases the mouse
button.drag\_and\_drop\_by\_offsetHolds down the left mouse button on
the source element, then moves to the target offset and releases the
mouse button.key\_downSends a key press only, without releasing
it.key\_upReleases a modifier key.move\_by\_offsetMoving the mouse to an
offset from current mouse position.move\_to\_elementMoving the mouse to
the middle of an element.move\_to\_element\_with\_offsetMove the mouse
by an offset of the specified element, Offsets are relative to the
top-left corner of the element.performPerforms all stored
actions.pausePause all inputs for the specified duration in
secondsreleaseReleasing a held mouse button on an
element.reset\_actionsClears actions that are already stored locally and
on the remote endsend\_keysSends keys to current focused element.
