---
title: "Python If Else
"
draft: false
menu:
sidebar:
name: "Python If Else
"
parent: "Python"
weight: 33
---

Python If Else
--------------



There comes situations in real life when we need to make some decisions
and based on these decisions, we decide what should we do next. Similar
situations arise in programming also where we need to make some
decisions and based on these decisions we will execute the next block of
code. Decision-making statements in programming languages decide the
direction(Control Flow) of the flow of program execution. 

Types of Control Flow in Python
-------------------------------

In Python programming language, the type of control flow statements are
as follows:

The if statement

The if-else statement

The nested-if statement

The if-elif-else ladder

if statement
------------

The if statement is the most simple decision-making statement. It is
used to decide whether a certain statement or block of statements will
be executed or not.

Syntax: 

    if condition:
       # Statements to execute if
       # condition is true

Here, the condition after evaluation will be either true or false. if
the statement accepts boolean values -- if the value is true then it
will execute the block of statements below it otherwise not.

As we know, python uses indentation to identify a block. So the block
under an if statement will be identified as shown in the below
example:  

    if condition:
       statement1
    statement2

    # Here if the condition is true, if block 
    # will consider only statement1 to be inside 
    # its block.

Flowchart of Python if statement
--------------------------------

![Flowchart of Python if
statement](https://media.geeksforgeeks.org/wp-content/uploads/if-statement.jpg)

Flowchart of Python if statement

Example of Python if Statement
------------------------------

As the condition present in the if statement is false. So, the block
below the if statement is executed.

Python3
-------

\# python program to illustrate If statement  i = 10  if (i \>
15):    print(\"10 is less than 15\")print(\"I am Not in if\")

Output: 

    I am Not in if

if-else statement
-----------------

The if statement alone tells us that if a condition is true it will
execute a block of statements and if the condition is false it won't.
But if we want to do something else if the condition is false, we can
use the else statement with if statement to execute a block of code when
the if condition is false. 

Syntax: 

    if (condition):
        # Executes this block if
        # condition is true
    else:
        # Executes this block if
        # condition is false

Flowchart of Python if-else statement
-------------------------------------

![Flowchart of Python is-else
statement](https://media.geeksforgeeks.org/wp-content/uploads/if-else.jpg)

Flowchart of Python is-else statement

Example of Python if-else statement
-----------------------------------

The block of code following the else statement is executed as the
condition present in the if statement is false after calling the
statement which is not in the block(without spaces).

Python3
-------

\# python program to illustrate If else statement\#!/usr/bin/python  i =
20if (i \< 15):    print(\"i is smaller than 15\")    print(\"i\'m in if
Block\")else:    print(\"i is greater than 15\")    print(\"i\'m in else
Block\")print(\"i\'m not in if and not in else Block\")

Output: 

    i is greater than 15
    i'm in else Block
    i'm not in if and not in else Block

Example of Python if else statement in a list comprehension
-----------------------------------------------------------

Python3
-------

\# Explicit functiondef digitSum(n):    dsum = 0    for ele in
str(n):        dsum += int(ele)    return dsum    \# Initializing
listList = \[367, 111, 562, 945, 6726, 873\]  \# Using the function on
odd elements of the listnewList = \[digitSum(i) for i in List if i &
1\]  \# Displaying new listprint(newList)

    [16, 3, 18, 18]

nested-if statement
-------------------

A nested if is an if statement that is the target of another if
statement. Nested if statements mean an if statement inside another if
statement. Yes, Python allows us to nest if statements within if
statements. i.e, we can place an if statement inside another if
statement.

Syntax: 

    if (condition1):
       # Executes when condition1 is true
       if (condition2): 
          # Executes when condition2 is true
       # if Block is end here
    # if Block is end here

Flowchart of Python Nested if Statement
---------------------------------------

![Flowchart of Python Nested if
statement](https://media.geeksforgeeks.org/wp-content/cdn-uploads/20200710163548/Nested_if.jpg)

Flowchart of Python Nested if statement

Example of Python Nested if statement
-------------------------------------

Python3
-------

\# python program to illustrate nested If statement\#!/usr/bin/pythoni =
10if (i == 10):        \#  First if statement    if (i \<
15):        print(\"i is smaller than 15\")              \# Nested - if
statement    \# Will only be executed if statement above    \# it is
true    if (i \< 12):        print(\"i is smaller than 12
too\")    else:        print(\"i is greater than 15\")

Output: 

    i is smaller than 15
    i is smaller than 12 too

if-elif-else ladder
-------------------

Here, a user can decide among multiple options. The if statements are
executed from the top down. As soon as one of the conditions controlling
the if is true, the statement associated with that if is executed, and
the rest of the ladder is bypassed. If none of the conditions is true,
then the final else statement will be executed.

Syntax: 

    if (condition):
        statement
    elif (condition):
        statement
    .
    .
    else:
        statement

Flowchart of Python if-elif-else ladder
---------------------------------------

![](https://media.geeksforgeeks.org/wp-content/uploads/if-elseif-ladder.jpg)

Flowchart of if-elif-else ladder

Example of Python if-elif-else ladder
-------------------------------------

Python3
-------

\# Python program to illustrate if-elif-else ladder\#!/usr/bin/python  i
= 20if (i == 10):    print(\"i is 10\")elif (i == 15):    print(\"i is
15\")elif (i == 20):    print(\"i is 20\")else:    print(\"i is not
present\")

Output: 

    i is 20

Short Hand if statement
-----------------------

Whenever there is only a single statement to be executed inside the if
block then shorthand if can be used. The statement can be put on the
same line as the if statement. 

Syntax: 

    if condition: statement

Example of Python if shorthand
------------------------------

Python3
-------

\# Python program to illustrate short hand ifi = 10if i \< 15: print(\"i
is less than 15\")

Output:

    i is less than 15

Short Hand if-else statement
----------------------------

This can be used to write the if-else statements in a single line where
only one statement is needed in both if and else block. 

Syntax:

    statement_when_True if condition else statement_when_False

Example of Python if else shorthand 
------------------------------------

Python3
-------

\# Python program to illustrate short hand if-elsei = 10print(True) if i
\< 15 else print(False)

Output: 

    True
