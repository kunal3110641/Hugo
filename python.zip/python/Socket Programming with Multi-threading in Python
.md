---
title: "Socket Programming with Multi-threading in Python
"
draft: false
menu:
sidebar:
name: "Socket Programming with Multi-threading in Python
"
parent: "Python"
weight: 94
---

Socket Programming with Multi-threading in Python
-------------------------------------------------



Prerequisite : Socket Programming in Python, Multi-threading in
PythonSocket Programming-\> It helps us to connect a client to a server.
Client is message sender and receiver and server is just a listener that
works on data sent by client.What is a Thread? A thread is a
light-weight process that does not require much memory overhead, they
are cheaper than processes.What is Multi-threading Socket
Programming? port on your computerMultithreading is a process of
executing multiple threads simultaneously in a single
process.Multi-threading Modules : A \_thread module & threading module
is used for multi-threading in python, these modules help in
synchronization and provide a lock to a thread in use.  

    from _thread import *
    import threading

A lock object is created by-\>  

    print_lock = threading.Lock()

A lock has two states, "locked" or "unlocked". It has two basic methods
acquire() and release(). When the state is unlocked
print\_lock.acquire() is used to change state to locked and
print\_lock.release() is used to change state to unlock.The function
thread.start\_new\_thread() is used to start a new thread and return its
identifier. The first argument is the function to call and its second
argument is a tuple containing the positional list of arguments.Let's
study client-server multithreading socket programming by code- Note:-The
code works with python3. Multi-threaded Server Code  

Python3
-------

\# import socket programming libraryimport socket \# import thread
modulefrom \_thread import \*import threading print\_lock =
threading.Lock() \# thread functiondef threaded(c):    while
True:         \# data received from client        data =
c.recv(1024)        if not
data:            print(\'Bye\')                         \# lock released
on exit            print\_lock.release()            break         \#
reverse the given string from client        data =
data\[::-1\]         \# send back reversed string to
client        c.send(data)     \# connection closed    c.close()  def
Main():    host = \"\"     \# reserve a port on your computer    \# in
our case it is 12345 but it    \# can be anything    port = 12345    s =
socket.socket(socket.AF\_INET, socket.SOCK\_STREAM)    s.bind((host,
port))    print(\"socket binded to port\", port)     \# put the socket
into listening mode    s.listen(5)    print(\"socket is
listening\")     \# a forever loop until client wants to exit    while
True:         \# establish connection with client        c, addr =
s.accept()         \# lock acquired by
client        print\_lock.acquire()        print(\'Connected to :\',
addr\[0\], \':\', addr\[1\])         \# Start a new thread and return
its identifier        start\_new\_thread(threaded,
(c,))    s.close()  if \_\_name\_\_ == \'\_\_main\_\_\':    Main()

    Console Window:
    socket binded to port 12345
    socket is listening
    Connected to : 127.0.0.1 : 11600
    Bye

Client Code  

Python
------

\# Import socket moduleimport socket  def Main():    \# local host IP
\'127.0.0.1\'    host = \'127.0.0.1\'     \# Define the port on which
you want to connect    port = 12345     s =
socket.socket(socket.AF\_INET,socket.SOCK\_STREAM)     \# connect to
server on local computer    s.connect((host,port))     \# message you
send to server    message = \"shaurya says geeksforgeeks\"    while
True:         \# message sent to
server        s.send(message.encode(\'ascii\'))         \# message
received from server        data = s.recv(1024)         \# print the
received message        \# here it would be a reverse of sent
message        print(\'Received from the server
:\',str(data.decode(\'ascii\')))         \# ask the client whether he
wants to continue        ans = input(\'\\nDo you want to continue(y/n)
:\')        if ans ==
\'y\':            continue        else:            break    \# close the
connection    s.close() if \_\_name\_\_ == \'\_\_main\_\_\':    Main()

    Console Window:
    Received from the server : skeegrofskeeg syas ayruahs

    Do you want to continue(y/n) :y
    Received from the server : skeegrofskeeg syas ayruahs

    Do you want to continue(y/n) :n

    Process finished with exit code 0


